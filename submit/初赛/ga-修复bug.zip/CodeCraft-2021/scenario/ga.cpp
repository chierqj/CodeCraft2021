#include "ga.h"

#include <algorithm>
#include <cassert>
#include <queue>
#include <unordered_map>
#include <unordered_set>

#include "request.h"
#include "tools.h"

void Ga::select_servers() {
    auto sce = Scenario::GetInstance();
    const auto &requests = sce->GetRequests();
    m_select_servers.clear();

    for (auto &reqs : requests) {
        for (auto &req : reqs) {
            if (req->GetType() == REQ_TYPE::DEL) continue;

            const auto &vir = req->GetVirtual();
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());

            vector<pair<int, Server *>> vct;
            for (auto &svr : m_servers) {
                int node = -1;
                if (!sce->match_purchase(svr, vir, node)) continue;
                double val = 0;
                const auto &svr_nodes = svr->GetNodes();
                if (vir->GetNodeCount() == 2) {
                    val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
                    val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
                } else {
                    int pid = node;
                    val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
                }

                vct.push_back({(int)(val * 100), svr});
            }
            sort(vct.begin(), vct.end(),
                 [&](const pair<int, Server *> &p1, const pair<int, Server *> &p2) { return p1.first < p2.first; });

            Server *select_svr = nullptr;
            int select_val = 0;
            for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
                const auto &svr = vct[i].second;

                int val = svr->GetHardwareCost() + svr->GetEnergyCost() * (vir->GetDelTime() - vir->GetAddTime());
                if (select_svr == nullptr || val < select_val) {
                    select_svr = svr;
                    select_val = val;
                }
            }

            m_select_servers.insert(select_svr);
        }
    }

    // vector<Server *> tmp(m_servers.begin(), m_servers.end());

    // sort(tmp.begin(), tmp.end(), [&](const Server *svr1, const Server *svr2) {
    //     int val1 = svr1->GetHardwareCost() + svr1->GetEnergyCost();
    //     int val2 = svr2->GetHardwareCost() + svr2->GetEnergyCost();
    //     return val1 < val2;
    // });

    // for (int i = 0; i < (int)tmp.size() * 0.3; ++i) {
    //     m_select_servers.insert(tmp[i]);
    // }

    // cout << "select_svr: " << m_select_servers.size() << "\n";
}

void Ga::Execute() {
    this->select_servers();
    const auto &sce = Scenario::GetInstance();
    int plan_id = 0;

    // unordered_map<int, vector<pair<string, int>>> chier;
    unordered_map<int, Server *> chier_svr;

    for (const auto &svr : m_select_servers) {
        m_index.clear();
        for (size_t i = 0; i < m_virtuals.size(); ++i) m_index.push_back(i);

        int last_size = m_index.size();

        while (!m_index.empty()) {
            this->init(svr);
            for (int epoch = 0; epoch < EPOCH; ++epoch) {
                this->cross(svr);
                this->select();
                if (m_popu.front().fitness < 0.1) break;
            }

            const auto &best = m_popu.front();

            if (best.fitness >= 0.1) break;

            vector<int> tmp_index;
            vector<pair<int, int>> suc_index;
            Server *new_svr = new Server(svr);
            for (size_t j = 0; j < best.code.size(); ++j) {
                if (best.code[j] == 0) {
                    tmp_index.push_back(m_index[j]);
                    continue;
                }
                int node = -1;
                Virtual *vir = m_virtuals[m_index[j]];
                if (sce->match_purchase(new_svr, vir, node)) {
                    new_svr->add_virtual(vir, node, 0);
                    suc_index.push_back({m_index[j], node});
                } else {
                    tmp_index.push_back(m_index[j]);
                }
            }
            delete new_svr;

            for (auto &idx : suc_index) {
                Virtual *vir = m_virtuals[idx.first];
                // m_planid_virlist[plan_id].insert(vir->GetName());
                m_planid_virlist[plan_id].push_back({vir->GetName(), idx.second});
                m_svr_vir_table[vir->GetName()].push_back(plan_node{plan_id, (int)suc_index.size(), idx.second, svr});
            }
            chier_svr[plan_id] = svr;
            ++plan_id;
            m_index = tmp_index;

            if ((int)m_index.size() == last_size) break;
            last_size = m_index.size();
        }
    }

    // unordered_map<string, Virtual *> ump;
    // for (auto &vir : m_virtuals) ump[vir->GetName()] = vir;

    // for (auto &it : chier) {
    //     chier_svr[it.first]->debug();
    //     cout << "plan_id: " << it.first << ", bind\n";
    //     for (auto &vir : it.second) {
    //         cout << "node: " << vir.second << ", ";
    //         ump[vir.first]->debug();
    //     }
    // }
    // cout << "------------------------------------------------\n";
    // cout << "预先分配个数: " << m_svr_vir_table.size() << "\n";
    // for (auto &it : m_svr_vir_table) {
    //     cout << "-------------------------------------\n";
    //     ump[it.first]->debug();
    //     for (auto &plan : it.second) {
    //         plan.debug();
    //     }
    // }
}

void Ga::calfitness(Unit &u, const Server *svr) {
    const auto &sce = Scenario::GetInstance();
    Server *new_svr = new Server(svr);

    for (size_t i = 0; i < u.code.size(); ++i) {
        if (u.code[i] == 0) continue;
        int node = -1;
        if (sce->match_purchase(new_svr, m_virtuals[m_index[i]], node)) {
            new_svr->add_virtual(m_virtuals[m_index[i]], node, 0);
        }
    }

    u.cpuA = (double)(new_svr->GetNodes()[0].cpu) / (double)(new_svr->GetNodes()[0].read_cpu + 1.0);
    u.memA = (double)(new_svr->GetNodes()[0].memory) / (double)(new_svr->GetNodes()[0].read_memory + 1.0);
    u.cpuB = (double)(new_svr->GetNodes()[1].cpu) / (double)(new_svr->GetNodes()[1].read_cpu + 1.0);
    u.memB = (double)(new_svr->GetNodes()[1].memory) / (double)(new_svr->GetNodes()[1].read_memory + 1.0);
    u.fitness = u.cpuA + u.memA + u.cpuB + u.memB;

    delete new_svr;
}

void Ga::init(const Server *svr) {
    int dep_block = 10;
    m_popu.clear();

    for (int i = 0; i < POPU_SIZE / dep_block; ++i) {
        int rd = Tools::RandomInt(0, (int)m_index.size() - 1);
        for (int dep = 1; dep <= dep_block; ++dep) {
            Unit u;
            u.code = vector<bitset<1>>(m_index.size(), 0);
            for (int j = rd; j < (int)m_index.size(); j += dep) {
                u.code[j] = 1;
            }
            m_popu.push_back(u);
        }
    }
    for (int i = 0; i < POPU_SIZE - (int)m_popu.size(); ++i) {
        Unit u;
        u.code = vector<bitset<1>>(m_virtuals.size(), 0);
        for (int j = 0; j < (int)m_virtuals.size(); ++j) {
            u.code[j] = Tools::RandomInt(0, 1);
        }
        m_popu.push_back(u);
    }
    for (auto &it : m_popu) {
        this->calfitness(it, svr);
    }
    assert((int)m_popu.size() == POPU_SIZE);
}

void Ga::cross(Server *svr) {
    for (int i = 0; i < POPU_SIZE; ++i) {
        double rd = Tools::RandomDouble(0, 1);
        if (rd > CROSS_RATE) continue;

        int l = Tools::RandomInt(0, POPU_SIZE - 1);
        int r = Tools::RandomInt(0, POPU_SIZE - 1);

        int p1 = Tools::RandomInt(0, (int)m_index.size() - 1);
        int p2 = Tools::RandomInt(0, (int)m_index.size() - 1);

        Unit nu1 = Unit(m_popu[l]), nu2 = Unit(m_popu[r]);
        for (int j = p1; j <= p2; ++j) {
            nu1.code[j] = m_popu[r].code[j];
            nu2.code[j] = m_popu[l].code[j];
        }

        this->mutation(nu1);
        this->mutation(nu2);

        this->calfitness(nu1, svr);
        this->calfitness(nu2, svr);

        m_popu.push_back(nu1);
        m_popu.push_back(nu2);
    }
}

void Ga::mutation(Unit &u) {
    double rd = Tools::RandomDouble(0, 1);
    if (rd > MUTATION_RATE) return;
    int p = Tools::RandomInt(0, (int)m_index.size() - 1);
    assert(p >= 0 && p <= (int)u.code.size());
    u.code[p] ^= 1;
}

void Ga::select() {
    struct Node {
        int idx;
        double val;
        bool operator<(const Node &r) const { return val < r.val; }
    };

    priority_queue<Node> pq;
    double sum_fitness = 0.00001;

    for (int i = 0; i < (int)m_popu.size(); ++i) {
        sum_fitness += m_popu[i].fitness;
        if ((int)pq.size() < TOPK) {
            pq.push(Node{i, m_popu[i].fitness});
            continue;
        }
        if (m_popu[i].fitness < pq.top().val) {
            pq.pop();
            pq.push(Node{i, m_popu[i].fitness});
        }
    }
    vector<Unit> sons;

    while (!pq.empty()) {
        sons.push_back(m_popu[pq.top().idx]);
        pq.pop();
    }

    vector<double> select_rate;
    double rate = 0.0;
    for (auto &it : m_popu) {
        rate += it.fitness / sum_fitness;
        select_rate.push_back(rate);
    }
    select_rate.back() = 1.0;

    for (int i = 0; i < POPU_SIZE - TOPK; ++i) {
        double rd = Tools::RandomDouble(0, 1);
        auto pos = lower_bound(select_rate.begin(), select_rate.end(), rd) - select_rate.begin();
        assert(pos >= 0 && pos <= (int)m_popu.size());
        sons.push_back(m_popu[pos]);
    }

    m_popu = sons;
}