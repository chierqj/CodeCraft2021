#include "virtual.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

void Virtual::debug() {
    cout << "虚拟机: ([" << name << ", ";
    cout << id << "], ";
    cout << m_cpu << ", ";
    cout << m_memory << ", ";
    cout << m_node_count << ", ";
    cout << (local_node == 0 ? "A" : (local_node == 1 ? "B" : "-1")) << ")\n";
}

string Virtual::to_string() {
    string msg = "虚拟机: (";
    msg += name + ", ";
    msg += std::to_string(m_cpu) + ", ";
    msg += std::to_string(m_memory) + ", ";
    msg += std::to_string(m_node_count) + ")";
    return msg;
}

void Virtual::del_server() {
    m_svr->del_virtual(this, local_node);
    m_svr = nullptr;
}

void Virtual::add_server(Server *svr, int node) {
    m_svr = svr;
    local_node = node;
}