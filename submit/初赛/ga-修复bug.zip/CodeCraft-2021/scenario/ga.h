#ifndef SCENARIO_GA_H
#define SCENARIO_GA_H

#include <algorithm>
#include <bitset>
#include <cassert>
#include <cstdio>
#include <iostream>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "ga.h"
#include "scenario.h"
#include "server.h"
#include "tools.h"
#include "virtual.h"

#define EPOCH (100)
#define POPU_SIZE (500)
#define TOPK (10)
#define CROSS_RATE (0.8)
#define MUTATION_RATE (0.2)
using namespace std;

struct Unit {
    Unit() {}
    Unit(Unit *u) {
        code = u->code;
        cpuA = 0;
        memA = 0;
        cpuB = 0;
        memB = 0;
        fitness = 0;
    };
    void debug() {
        printf("[cpuA: %.3f, memA: %.3f] [cpuB: %.3f, memB: %.3f] [fitness: %.3f]\n", cpuA, memA, cpuB, memB, fitness);
    }

    vector<bitset<1>> code;
    double cpuA, memA, cpuB, memB;
    double fitness;
};

struct plan_node {
    int id;
    int suc_count;
    int node;
    Server *svr;
    void debug() const {
        printf("plan_id: %d, suc_count: %d, node: %d", id, suc_count, node);
        svr->debug();
    }
};

class Scenario;

class Ga {
   public:
    Ga(const vector<Server *> &servers, const vector<Virtual *> &virtuals) : m_servers(servers), m_virtuals(virtuals) {}
    void Execute();
    inline unordered_map<string, vector<plan_node>> &GetSvrVirTable() { return m_svr_vir_table; }
    inline unordered_map<int, vector<pair<string, int>>> &GetPlanId2VirList() { return m_planid_virlist; }

   private:
    void select_servers();
    void init(const Server *svr);
    void calfitness(Unit &u, const Server *svr);
    void cross(Server *svr);
    void mutation(Unit &u);
    void select();

   private:
    const vector<Server *> &m_servers;
    const vector<Virtual *> &m_virtuals;

    unordered_set<Server *> m_select_servers;
    vector<Unit> m_popu;
    unordered_map<string, vector<plan_node>> m_svr_vir_table;  // vir->[(方案id,cnt,svr),]
    vector<int> m_index;
    unordered_map<int, vector<pair<string, int>>> m_planid_virlist;  // 方案id对应的virlist
};

#endif