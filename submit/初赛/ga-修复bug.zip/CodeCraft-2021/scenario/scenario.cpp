#include "scenario.h"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "ga.h"

using namespace std;
Scenario* Scenario::Instance = nullptr;

Scenario* Scenario::GetInstance() {
    if (Instance == nullptr) {
        Instance = new Scenario();
    }
    return Instance;
}

void Scenario::debug() {}

void Scenario::Execute() {
    this->read_data();
    this->solve();
}

std::vector<std::string> Split(std::string str, std::string pattern) {
    std::string::size_type pos;
    std::vector<std::string> result;
    str += pattern;  //扩展字符串以方便操作
    size_t size = str.size();
    for (size_t i = 0; i < size; i++) {
        pos = str.find(pattern, i);
        if (pos < size) {
            std::string s = str.substr(i, pos - i);
            result.push_back(s);
            i = pos + pattern.size() - 1;
        }
    }
    return result;
}

void Scenario::read_data() {
    string line;
    getline(cin, line);
    int n = std::stoi(line);
    m_TolSvr = n;
    for (int i = 0; i < n; ++i) {
        getline(cin, line);
        line = line.substr(1, line.size() - 2);
        auto s = Split(line, ", ");
        Server* server = new Server(s[0], std::stoi(s[1]), std::stoi(s[2]), std::stoi(s[3]), std::stoi(s[4]));
        m_servers.push_back(server);
    }
    getline(cin, line);
    int m = std::stoi(line);
    m_TolVir = m;

    for (int i = 0; i < m; ++i) {
        getline(cin, line);
        line = line.substr(1, line.size() - 2);
        auto s = Split(line, ", ");
        Virtual* vir = new Virtual(s[0], std::stoi(s[1]), std::stoi(s[2]), std::stoi(s[3]) + 1);
        m_virtuals.push_back(vir);
        m_hash_virtual[s[0]] = vir;
    }
    getline(cin, line);
    int t = std::stoi(line);
    m_TolDay = t;

    unordered_map<int, Virtual*> vir_pool;

    for (int i = 0; i < t; ++i) {
        getline(cin, line);
        int r = std::stoi(line);
        vector<Request*> reqs;
        for (int j = 0; j < r; ++j) {
            getline(cin, line);
            line = line.substr(1, line.size() - 2);
            auto s = Split(line, ", ");
            if (s.size() == 3) {
                Virtual* new_vir = new Virtual(m_hash_virtual[s[1]]);
                new_vir->SetID(std::stoi(s[2]));
                vir_pool[std::stoi(s[2])] = new_vir;
                new_vir->SetAddTime(i);
                new_vir->SetDelTime(m_TolDay);
                Request* req = new Request("ADD", s[1], std::stoi(s[2]), new_vir);
                reqs.push_back(req);
            } else {
                Virtual* new_vir = vir_pool[std::stoi(s[1])];
                new_vir->SetDelTime(i);
                Request* req = new Request("DEL", std::stoi(s[1]), new_vir);
                reqs.push_back(req);
            }
        }
        m_requests.push_back(reqs);
    }
}

void Scenario::do_migration(int day_index) {
    migration_result.clear();
    migration_result.push_back("(migration, 0)");

    int migra_count = m_VirtualPoolSize * 5 / 1000;

    for (auto& it : m_group_svr_pool) {
        if (migra_count <= 0) break;

        for (auto& svr_to : it.second) {
            if (migra_count <= 0) break;
            const auto& planid_virlist = m_ga->GetPlanId2VirList()[svr_to->GetPlanID()];

            for (auto& it : planid_virlist) {
                if (migra_count <= 0) break;
                if (svr_to->GetVisVirList().find(it.first) != svr_to->GetVisVirList().end()) continue;
                auto& create_vir_list = m_created_virlist[it.first];

                sort(create_vir_list.begin(), create_vir_list.end(), [&](const Virtual* vm1, const Virtual* vm2) {
                    int cpu1 = 0, mem1 = 0, cpu2 = 0, mem2 = 0;
                    if (vm1->GetServer() != nullptr) {
                        cpu1 = vm1->GetServer()->GetNodes()[0].cpu + vm1->GetServer()->GetNodes()[1].cpu;
                        mem1 = vm1->GetServer()->GetNodes()[0].memory + vm1->GetServer()->GetNodes()[1].memory;
                    }
                    if (vm2->GetServer() != nullptr) {
                        cpu2 = vm2->GetServer()->GetNodes()[0].cpu + vm2->GetServer()->GetNodes()[1].cpu;
                        mem2 = vm2->GetServer()->GetNodes()[0].memory + vm2->GetServer()->GetNodes()[1].memory;
                    }
                    return cpu1 + mem1 > cpu2 + mem2;
                });

                for (auto& vir : create_vir_list) {
                    if (migra_count <= 0) break;
                    if (vir->GetServer() == nullptr) continue;

                    vir->del_server();
                    svr_to->add_virtual(vir, it.second, 0);
                    vir->add_server(svr_to, it.second);
                    if (it.second == -1) {
                        string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(svr_to->GetID()) + ")";
                        migration_result.push_back(s);
                    } else {
                        string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(svr_to->GetID()) + ", " +
                                   (it.second == 0 ? "A" : "B") + ")";
                        migration_result.push_back(s);
                    }
                    --migra_count;
                    break;
                }
            }
        }
    }

    migration_result[0] = "(migration, " + std::to_string(migration_result.size() - 1) + ")";
    return;
}

bool Scenario::match_purchase(Server* svr, Virtual* vir, int& local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem) {
            local_node = 0;
            return true;
            ok1 = true;
        }
        if (svr_nodes[1].cpu >= vir_cpu && svr_nodes[1].memory >= vir_mem) {
            local_node = 1;
            return true;
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)(svr_nodes[0].cpu) / double(svr_nodes[0].memory) - vir_value);
            double valB = fabs((double)(svr_nodes[1].cpu) / double(svr_nodes[1].memory) - vir_value);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem && svr_nodes[1].cpu >= vir_cpu &&
            svr_nodes[1].memory >= vir_mem) {
            local_node = -1;
            return true;
        }
    }
    return false;
}

void Scenario::do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

bool Scenario::loop1(Virtual* vir, int day) {
    auto& plan_nodes = m_ga->GetSvrVirTable()[vir->GetName()];
    for (const auto& plan : plan_nodes) {
        auto& svr_list = m_group_svr_pool[plan.svr->GetName()];
        for (auto& svr : svr_list) {
            if (svr->GetPlanID() != plan.id) continue;
            if (svr->GetVisVirList().find(vir->GetName()) != svr->GetVisVirList().end()) continue;

            int node = -1;
            if (!this->match_purchase(svr, vir, node)) {
                svr->debug();
                vir->debug();
                assert(false);
                continue;
            }

            this->do_match(svr, vir, day, plan.node);
            return true;
        }
    }
    return false;
}

Server* Scenario::loop2(Virtual* vir, int day) {
    auto& plan_nodes = m_ga->GetSvrVirTable()[vir->GetName()];
    // cout << "loop2: ----------------------------------------\n";
    // vir->debug();
    for (const auto& plan : plan_nodes) {
        // plan.debug();
        const auto& svr_list = m_group_svr_pool[plan.svr->GetName()];
        if (svr_list.empty()) {
            Server* new_svr = new Server(plan.svr);
            new_svr->SetPlanID(plan.id);
            // cout << "empty\n";
            // new_svr->debug();
            this->do_match(new_svr, vir, day, plan.node);
            // new_svr->debug();
            m_group_svr_pool[plan.svr->GetName()].push_back(new_svr);
            return new_svr;
        }

        Server* select_svr = nullptr;
        for (auto& svr : svr_list) {
            if (svr->GetPlanID() != plan.id) continue;
            const auto& bind_vir_list = svr->GetVisVirList();
            if ((int)bind_vir_list.size() >= plan.suc_count) {
                select_svr = svr;
                break;
            }
        }

        if (select_svr != nullptr) {
            Server* new_svr = new Server(select_svr);
            new_svr->SetPlanID(plan.id);
            // cout << "buy\n";
            // new_svr->debug();
            this->do_match(new_svr, vir, day, plan.node);
            // new_svr->debug();
            m_group_svr_pool[plan.svr->GetName()].push_back(new_svr);
            return new_svr;
        }
    }
    return nullptr;
}

Server* Scenario::loop3(Virtual* vir, int day) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    // old
    for (const auto& svr : m_public_svr_pool) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;

        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0, local_node = -1;

    for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
        const auto& svr = vct[i].svr;
        int val = 0;
        if (vir->GetNodeCount() == 2) {
            val = svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory;
            val += svr->GetNodes()[1].cpu + svr->GetNodes()[1].memory;
        } else {
            int pid = vct[i].node_idx;
            val = svr->GetNodes()[pid].cpu + svr->GetNodes()[pid].memory;
        }

        if (vir->GetDelTime() > svr->GetDelTime()) {
            val += 0.4 * (double)(vir->GetDelTime() - svr->GetDelTime()) * svr->GetEnergyCost();
        }

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node_idx;
        }
    }

    if (select_svr != nullptr) {
        this->do_match(select_svr, vir, day, local_node);
        return nullptr;
    }

    // buy
    select_svr = nullptr;
    select_value = 0;
    local_node = -1;
    vct.clear();

    for (const auto& svr : m_servers) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;
        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), node, svr});
    }

    sort(vct.begin(), vct.end());
    int delta_day = vir->GetDelTime() - day;
    for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
        const auto& svr = vct[i].svr;
        int val = svr->GetHardwareCost() + svr->GetEnergyCost() * delta_day;
        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node_idx;
        }
    }
    Server* new_svr = new Server(select_svr);
    this->do_match(new_svr, vir, day, local_node);
    m_public_svr_pool.push_back(new_svr);
    return new_svr;
}

void Scenario::solve() {
    m_ga = new Ga(m_servers, m_virtuals);
    m_ga->Execute();

    int global_index = 0;
    for (int day = 0; day < (int)m_requests.size(); ++day) {
        unordered_map<string, vector<Server*>> tmp;
        this->do_migration(day);

        for (auto& req : m_requests[day]) {
            if (req->GetType() == REQ_TYPE::ADD) {
                m_created_virlist[req->GetVirtual()->GetName()].push_back(req->GetVirtual());
                ++m_VirtualPoolSize;

                if (this->loop1(req->GetVirtual(), day)) continue;

                Server* select_svr = nullptr;
                select_svr = this->loop2(req->GetVirtual(), day);
                if (select_svr != nullptr) {
                    tmp[select_svr->GetName()].push_back(select_svr);
                    continue;
                }
                select_svr = this->loop3(req->GetVirtual(), day);
                if (select_svr != nullptr) {
                    tmp[select_svr->GetName()].push_back(select_svr);
                }

            } else {
                auto vir = req->GetVirtual();
                vir->del_server();
                --m_VirtualPoolSize;
            }
        }

        cout << "(purchase, " << tmp.size() << ")\n";
        for (auto& it : tmp) {
            for (auto& svr : it.second) {
                svr->SetID(global_index++);
            }
            cout << "(" << it.first << ", " << it.second.size() << ")\n";
        }

        for (auto& it : migration_result) cout << it << "\n";

        for (auto& req : m_requests[day]) {
            if (req->GetType() == REQ_TYPE::DEL) continue;
            const auto& vir = req->GetVirtual();
            if (vir->GetNodeCount() == 2) {
                cout << "(" << vir->GetServer()->GetID() << ")\n";
            } else {
                cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
            }
        }
    }
}