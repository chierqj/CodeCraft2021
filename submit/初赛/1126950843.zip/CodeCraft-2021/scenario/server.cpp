#include "server.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;

void Server::debug() const {
    cout << "(服务器: " << name << ", ";
    cout << m_nodes[0].to_string() << ", ";
    cout << m_nodes[1].to_string() << ", ";
    cout << m_hardware_cost << ", ";
    cout << m_energy_cost << "\n";
}

string Server::to_string() {
    string msg = "服务器: (";
    // msg += name + ", ";
    // msg += std::to_string(m_cpu) + ", ";
    // msg += std::to_string(m_memory) + ", ";
    // msg += std::to_string(m_hardware_cost) + ", ";
    // msg += std::to_string(m_energy_cost) + ")";
    return msg;
}