#ifndef SCENARIO_REQUEST_H
#define SCENARIO_REQUEST_H

#include <algorithm>
#include <cstring>
#include <iostream>
#include <vector>

#include "virtual.h"
using namespace std;

enum REQ_TYPE { ADD, DEL };

class Request {
   public:
    Request(string type, int vir_id, Virtual *vir) : type(REQ_TYPE::DEL), vir_id(vir_id), m_vir(vir) {}
    Request(string type, string vir_name, int vir_id, Virtual *vir)
        : type(REQ_TYPE::ADD), vir_name(vir_name), vir_id(vir_id), m_vir(vir) {}

    void debug();
    string to_string();

   public:
    inline const REQ_TYPE &GetType() const { return type; }
    inline const string &GetVirTualName() const { return vir_name; }
    inline const int &GetVirTualID() const { return vir_id; }
    inline Virtual *GetVirtual() { return m_vir; }
    inline void SetVirtual(Virtual *_vir) { m_vir = _vir; }

   private:
    REQ_TYPE type;
    string vir_name;
    int vir_id;
    Virtual *m_vir;  // 请求绑定的虚拟机，每次都new; Add和del是同一个指针
};

#endif