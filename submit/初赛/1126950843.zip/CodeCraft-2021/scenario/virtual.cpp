#include "virtual.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

void Virtual::debug() {
    cout << "虚拟机: (" << name << ", ";
    cout << m_cpu << ", ";
    cout << m_memory << ", ";
    cout << m_node_count << ", ";
    cout << local_node << ")\n";
}

string Virtual::to_string() {
    string msg = "虚拟机: (";
    msg += name + ", ";
    msg += std::to_string(m_cpu) + ", ";
    msg += std::to_string(m_memory) + ", ";
    msg += std::to_string(m_node_count) + ")";
    return msg;
}

void Virtual::release_server() {
    const auto &svr_nodes = m_svr->GetNodes();

    if (m_node_count == 1) {
        m_svr->SetNodeByID({svr_nodes[local_node].cpu + m_cpu, svr_nodes[local_node].memory + m_memory}, local_node);
    } else {
        m_svr->SetNodeByID({svr_nodes[0].cpu + (m_cpu >> 1), svr_nodes[0].memory + (m_memory >> 1)}, 0);
        m_svr->SetNodeByID({svr_nodes[1].cpu + (m_cpu >> 1), svr_nodes[1].memory + (m_memory >> 1)}, 1);
    }
}