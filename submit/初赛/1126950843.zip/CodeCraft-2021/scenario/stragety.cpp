#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "scenario.h"

using namespace std;

bool match(Server* svr, Virtual* vir, int& local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();
    // vir->SetLocalNode(-1);

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem) {
            ok1 = true;
        }
        if (svr_nodes[1].cpu >= vir_cpu && svr_nodes[1].memory >= vir_mem) {
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)(svr_nodes[0].cpu) / double(svr_nodes[0].memory) - vir_value);
            double valB = fabs((double)(svr_nodes[1].cpu) / double(svr_nodes[1].memory) - vir_value);
            // vir->SetLocalNode(valA < valB ? 0 : 1);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            // vir->SetLocalNode(ok1 ? 0 : 1);
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem && svr_nodes[1].cpu >= vir_cpu &&
            svr_nodes[1].memory >= vir_mem) {
            return true;
        }
    }
    return false;
}

void do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();

    if (vir->GetNodeCount() == 1) {
        int pid = local_node;
        svr->SetNodeByID({svr_nodes[pid].cpu - vir_cpu, svr_nodes[pid].memory - vir_mem}, pid);
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        svr->SetNodeByID({svr_nodes[0].cpu - vir_cpu, svr_nodes[0].memory - vir_mem}, 0);
        svr->SetNodeByID({svr_nodes[1].cpu - vir_cpu, svr_nodes[1].memory - vir_mem}, 1);
    }
    if (svr->GetAddTime() == -1) svr->SetAddTime(day_idx);
    svr->SetDelTime(max(svr->GetDelTime(), vir->GetDelTime()));
    vir->SetServer(svr);
    vir->SetLocalNode(local_node);
}

Server* get_old_server(const vector<Server*>& svr_pool, Virtual* vir, int delta_day, int& cost, int& local_node) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : svr_pool) {
        int node = 0;
        if (!match(svr, vir, node)) continue;

        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
        const auto& svr = vct[i].svr;
        int val = 0;
        if (vir->GetNodeCount() == 2) {
            val = svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory;
            val += svr->GetNodes()[1].cpu + svr->GetNodes()[1].memory;
        } else {
            int pid = vct[i].node_idx;
            val = svr->GetNodes()[pid].cpu + svr->GetNodes()[pid].memory;
        }

        if (vir->GetDelTime() > svr->GetDelTime()) {
            val += 0.3 * (double)(vir->GetDelTime() - svr->GetDelTime()) * svr->GetEnergyCost();
        }

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            // vir->SetLocalNode(vct[i].node_idx);
            local_node = vct[i].node_idx;
            if (vir->GetDelTime() > svr->GetDelTime()) {
                cost = (vir->GetDelTime() - svr->GetDelTime()) * svr->GetEnergyCost();
            }
        }
    }
    return select_svr;
}

Server* get_new_server(const vector<Server*>& svr_pool, Virtual* vir, int delta_day, int& cost, int& local_node) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : svr_pool) {
        int node = 0;
        if (!match(svr, vir, node)) continue;
        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
        const auto& svr = vct[i].svr;
        int val = svr->GetHardwareCost() + svr->GetEnergyCost() * delta_day;
        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            cost = val;
            local_node = vct[i].node_idx;
        }
    }

    return select_svr;
}

void Scenario::solve() {
    vector<Server*> svr_pool;

    int global_index = 0, day_index = -1;
    for (auto& reqs : m_requests) {
        day_index++;
        unordered_map<string, vector<Server*>> tmp;

        for (auto& req : reqs) {
            if (req->GetType() == REQ_TYPE::ADD) {
                int delta_day = req->GetVirtual()->GetDelTime() - day_index;
                int cost1 = 0, cost2 = 0;
                int node1 = 0, node2 = 0;
                auto select_svr1 = get_old_server(svr_pool, req->GetVirtual(), delta_day, cost1, node1);
                auto select_svr2 = get_new_server(m_servers, req->GetVirtual(), delta_day, cost2, node2);
                // if (select_svr1 == nullptr) {
                //     Server* new_svr = new Server(select_svr2);
                //     do_match(new_svr, req->GetVirtual(), day_index, node2);
                //     svr_pool.push_back(new_svr);
                //     tmp[new_svr->GetName()].push_back(new_svr);
                //     req->GetVirtual()->SetLocalNode(node2);
                // } else {
                //     if (cost1 <= cost2) {
                //         do_match(select_svr1, req->GetVirtual(), day_index, node1);
                //         req->GetVirtual()->SetLocalNode(node1);
                //     } else {
                //         Server* new_svr = new Server(select_svr2);
                //         do_match(new_svr, req->GetVirtual(), day_index, node2);
                //         svr_pool.push_back(new_svr);
                //         tmp[new_svr->GetName()].push_back(new_svr);
                //     }
                // }
                if (select_svr1 != nullptr) {
                    do_match(select_svr1, req->GetVirtual(), day_index, node1);
                } else {
                    Server* new_svr = new Server(select_svr2);
                    do_match(new_svr, req->GetVirtual(), day_index, node2);
                    svr_pool.push_back(new_svr);
                    tmp[new_svr->GetName()].push_back(new_svr);
                }
            } else {
                auto vir = req->GetVirtual();
                vir->release_server();
            }
        }

        cout << "(purchase, " << tmp.size() << ")\n";
        for (auto& it : tmp) {
            for (auto& svr : it.second) {
                svr->SetID(global_index++);
            }
            cout << "(" << it.first << ", " << it.second.size() << ")\n";
        }
        cout << "(migration, 0)\n";
        for (auto& req : reqs) {
            if (req->GetType() == REQ_TYPE::DEL) continue;
            const auto& vir = req->GetVirtual();
            if (vir->GetNodeCount() == 2) {
                cout << "(" << vir->GetServer()->GetID() << ")\n";
            } else {
                cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
            }
        }
    }
}