#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "scenario.h"

using namespace std;

bool Scenario::match_purchase(Server* svr, Virtual* vir, int& local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem) {
            ok1 = true;
        }
        if (svr_nodes[1].cpu >= vir_cpu && svr_nodes[1].memory >= vir_mem) {
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)(svr_nodes[0].cpu) / double(svr_nodes[0].memory) - vir_value);
            double valB = fabs((double)(svr_nodes[1].cpu) / double(svr_nodes[1].memory) - vir_value);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem && svr_nodes[1].cpu >= vir_cpu &&
            svr_nodes[1].memory >= vir_mem) {
            return true;
        }
    }
    return false;
}

void do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

Server* Scenario::get_old_server(const vector<Server*>& svr_pool, Virtual* vir, int delta_day, int& cost,
                                 int& local_node) {
    // Server* select_svr = nullptr;
    // int select_value = 0;

    // for (const auto& svr : svr_pool) {
    //     int node = 0;
    //     if (!this->match_purchase(svr, vir, node)) continue;

    //     int val = 0;
    //     if (vir->GetNodeCount() == 2) {
    //         val = svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory;
    //         val += svr->GetNodes()[1].cpu + svr->GetNodes()[1].memory;
    //     } else {
    //         val = svr->GetNodes()[node].cpu + svr->GetNodes()[node].memory;
    //     }

    //     if (vir->GetDelTime() > svr->GetDelTime()) {
    //         val += 0.2 * (vir->GetDelTime() - svr->GetDelTime()) * svr->GetEnergyCost();
    //     }

    //     if (select_svr == nullptr || val < select_value) {
    //         select_svr = svr;
    //         select_value = val;
    //         local_node = node;
    //         if (vir->GetDelTime() > svr->GetDelTime()) {
    //             cost = (vir->GetDelTime() - svr->GetDelTime()) * svr->GetEnergyCost();
    //         }
    //     }
    // }

    // return select_svr;
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : svr_pool) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;

        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
        const auto& svr = vct[i].svr;
        int val = 0;
        if (vir->GetNodeCount() == 2) {
            val = svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory;
            val += svr->GetNodes()[1].cpu + svr->GetNodes()[1].memory;
        } else {
            int pid = vct[i].node_idx;
            val = svr->GetNodes()[pid].cpu + svr->GetNodes()[pid].memory;
        }

        if (vir->GetDelTime() > svr->GetDelTime()) {
            val += 0.4 * (double)(vir->GetDelTime() - svr->GetDelTime()) * svr->GetEnergyCost();
        }

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node_idx;
            if (vir->GetDelTime() > svr->GetDelTime()) {
                cost = (vir->GetDelTime() - svr->GetDelTime()) * svr->GetEnergyCost();
            }
        }
    }
    return select_svr;
}

Server* Scenario::get_new_server(const vector<Server*>& svr_pool, Virtual* vir, int delta_day, int& cost,
                                 int& local_node) {
    // Server* select_svr = nullptr;
    // int select_value = 0;
    // for (const auto& svr : svr_pool) {
    //     int node = 0;
    //     if (!this->match_purchase(svr, vir, node)) continue;

    //     const auto& svr_nodes = svr->GetNodes();
    //     int val = svr_nodes[0].cpu + svr_nodes[0].memory;

    //     if (select_svr == nullptr || val < select_value) {
    //         select_svr = svr;
    //         select_value = val;
    //         cost = svr->GetHardwareCost() + svr->GetEnergyCost() * delta_day;
    //         local_node = node;
    //     }
    // }
    // return select_svr;
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : svr_pool) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;
        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
        const auto& svr = vct[i].svr;
        int val = svr->GetHardwareCost() + svr->GetEnergyCost() * delta_day;
        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            cost = val;
            local_node = vct[i].node_idx;
        }
    }

    return select_svr;
}

void Scenario::solve() {
    int global_index = 0;
    for (int day = 0; day < (int)m_requests.size(); ++day) {
        unordered_map<string, vector<Server*>> tmp;
        this->do_migration();
        for (auto& req : m_requests[day]) {
            req->GetVirtual()->SetGroupID(
                this->get_group_id(req->GetVirtual()->GetCPU(), req->GetVirtual()->GetMemory()));

            if (req->GetType() == REQ_TYPE::ADD) {
                ++m_VirtualPoolSize;
                int delta_day = req->GetVirtual()->GetDelTime() - day;
                int cost1 = 0, cost2 = 0;
                int node1 = 0, node2 = 0;
                auto select_svr1 = get_old_server(svr_pool[req->GetVirtual()->GetGroupID()].buyed, req->GetVirtual(),
                                                  delta_day, cost1, node1);
                if (select_svr1 != nullptr) {
                    do_match(select_svr1, req->GetVirtual(), day, node1);
                    continue;
                }
                auto select_svr2 = get_new_server(svr_pool[req->GetVirtual()->GetGroupID()].shop, req->GetVirtual(),
                                                  delta_day, cost2, node2);
                Server* new_svr = new Server(select_svr2);
                do_match(new_svr, req->GetVirtual(), day, node2);
                svr_pool[req->GetVirtual()->GetGroupID()].buyed.push_back(new_svr);
                tmp[new_svr->GetName()].push_back(new_svr);
            } else {
                auto vir = req->GetVirtual();
                vir->del_server();
                --m_VirtualPoolSize;
            }
        }

        cout << "(purchase, " << tmp.size() << ")\n";
        for (auto& it : tmp) {
            for (auto& svr : it.second) {
                svr->SetID(global_index++);
            }
            cout << "(" << it.first << ", " << it.second.size() << ")\n";
        }

        for (auto& it : migration_result) cout << it << "\n";

        for (auto& req : m_requests[day]) {
            if (req->GetType() == REQ_TYPE::DEL) continue;
            const auto& vir = req->GetVirtual();
            if (vir->GetNodeCount() == 2) {
                cout << "(" << vir->GetServer()->GetID() << ")\n";
            } else {
                cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
            }
        }
    }
}