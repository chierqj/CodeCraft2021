#include <cmath>

#include "scenario.h"
#define PI 3.14
int cal_degree(int x, int y) {
    double val = (double)y / (double)(sqrt(x * x + y * y));
    int ans = acos(val) * 180.0 / PI;
    return ans;
}

int Scenario::get_group_id(int x, int y) {
    int d = cal_degree(x, y) * GROUP_COUNT / 90;
    int ans = (d >= GROUP_COUNT ? GROUP_COUNT - 1 : d);
    return ans;
}

void Scenario::group_server() {
    for (int i = 0; i < GROUP_COUNT; ++i) {
        svr_pool.push_back(GroupSvr(i));
    }
    for (auto& svr : m_servers) {
        int cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
        int mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;
        int p = this->get_group_id(cpu, mem);
        svr_pool[p].shop.push_back(svr);
    }

    vector<int> order;
    for (int i = 1; i <= GROUP_COUNT; ++i) {
        order.push_back(i);
        order.push_back(-i);
    }

    for (int i = 0; i < GROUP_COUNT; ++i) {
        if (!svr_pool[i].shop.empty()) continue;
        for (auto& v : order) {
            int p = i + v;
            if (p < 0 || p >= GROUP_COUNT) continue;
            if (!svr_pool[p].shop.empty()) {
                svr_pool[i].shop = svr_pool[p].shop;
                break;
            }
        }
    }
}
