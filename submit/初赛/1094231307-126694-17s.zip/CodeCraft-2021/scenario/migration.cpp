#include <algorithm>
#include <cassert>

#include "scenario.h"

double Scenario::get_used_rate(Server *svr, Virtual *vir, int local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();

    double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu - vir_cpu;
    double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory - vir_mem;
    double read_cpu = svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu;
    double read_mem = svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory;

    return (1.0 - cpu / read_cpu) + (1.0 - mem / read_mem);
}

void Scenario::do_migration(int day) {
    migration_result.clear();
    migration_result.push_back("(migration, 0)");
    int migra_count = m_VirtualPoolSize * 5 / 1000;
    if (migra_count <= 0) return;

    vector<pair<double, Server *>> svr_from_list, svr_to_list;
    for (auto &svr : m_buyed_svr_pool) {
        if (svr->GetVirList().empty()) continue;
        double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
        double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;
        double read_cpu = svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu;
        double read_mem = svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory;
        // 计算利用率
        double rate = (1.0 - cpu / read_cpu) + (1.0 - mem / read_mem);
        double m = 1.2;
        // if (rate < m) svr_from_list.push_back({rate, svr});
        // if (rate >= m) svr_to_list.push_back({rate, svr});
        if (rate <= 1.8) svr_from_list.push_back({rate, svr});
        if (rate >= 0.4 && rate <= 1.9) svr_to_list.push_back({rate, svr});
    }
    // cout << "迁移数目: " << migra_count << ", svr_from: " << svr_from_list.size() << ", svr_to: " <<
    // svr_to_list.size() << "\n";

    sort(svr_from_list.begin(), svr_from_list.end());
    sort(svr_to_list.begin(), svr_to_list.end());
    reverse(svr_to_list.begin(), svr_to_list.end());

    for (auto &svr_from : svr_from_list) {
        if (migra_count <= 0) break;
        vector<Virtual *> vir_list(svr_from.second->GetVirList().begin(), svr_from.second->GetVirList().end());
        for (auto &vir : vir_list) {
            if (migra_count <= 0) break;
            Server *select_svr = nullptr;
            double select_val = 0;
            int select_node = -1;

            for (auto &svr_to : svr_to_list) {
                // if (svr_to.first <= svr_from.first) break;
                if (vir->GetServer()->GetID() == svr_to.second->GetID()) continue;
                int node = -1;
                if (!this->match_purchase(svr_to.second, vir, node)) continue;
                double rate = this->get_used_rate(svr_to.second, vir, node);
                if (select_svr == nullptr || rate > select_val) {
                    select_svr = svr_to.second;
                    select_val = rate;
                    select_node = node;
                }
            }
            if (select_svr == nullptr) continue;

            vir->del_server();
            select_svr->add_virtual(vir, select_node, 0);
            vir->add_server(select_svr, select_node);
            if (select_node == -1) {
                string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(select_svr->GetID()) + ")";
                migration_result.push_back(s);
            } else {
                string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(select_svr->GetID()) + ", " +
                           (select_node == 0 ? "A" : "B") + ")";
                migration_result.push_back(s);
            }
            --migra_count;
        }
    }

    migration_result[0] = "(migration, " + std::to_string(migration_result.size() - 1) + ")";
    return;
}
