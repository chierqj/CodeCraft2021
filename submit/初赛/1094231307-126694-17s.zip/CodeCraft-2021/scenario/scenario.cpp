#include "scenario.h"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <unordered_set>
#include <vector>

using namespace std;
Scenario *Scenario::Instance = nullptr;

Scenario *Scenario::GetInstance() {
    if (Instance == nullptr) {
        Instance = new Scenario();
    }
    return Instance;
}

void Scenario::debug() {}

std::vector<std::string> Split(std::string str, std::string pattern) {
    std::string::size_type pos;
    std::vector<std::string> result;
    str += pattern;  //扩展字符串以方便操作
    size_t size = str.size();
    for (size_t i = 0; i < size; i++) {
        pos = str.find(pattern, i);
        if (pos < size) {
            std::string s = str.substr(i, pos - i);
            result.push_back(s);
            i = pos + pattern.size() - 1;
        }
    }
    return result;
}

void Scenario::read_data() {
    string line;
    getline(cin, line);
    int n = std::stoi(line);
    m_TolSvr = n;
    for (int i = 0; i < n; ++i) {
        getline(cin, line);
        line = line.substr(1, line.size() - 2);
        auto s = Split(line, ", ");
        Server *server = new Server(s[0], std::stoi(s[1]), std::stoi(s[2]), std::stoi(s[3]), std::stoi(s[4]));
        m_servers.push_back(server);
    }
    getline(cin, line);
    int m = std::stoi(line);
    m_TolVir = m;

    for (int i = 0; i < m; ++i) {
        getline(cin, line);
        line = line.substr(1, line.size() - 2);
        auto s = Split(line, ", ");
        Virtual *vir = new Virtual(s[0], std::stoi(s[1]), std::stoi(s[2]), std::stoi(s[3]) + 1);
        m_virtuals.push_back(vir);
        m_hash_virtual[s[0]] = vir;
    }
    getline(cin, line);
    int t = std::stoi(line);
    m_TolDay = t;

    unordered_map<int, Virtual *> vir_pool;

    for (int i = 0; i < t; ++i) {
        getline(cin, line);
        int r = std::stoi(line);
        vector<Request *> reqs;
        for (int j = 0; j < r; ++j) {
            getline(cin, line);
            line = line.substr(1, line.size() - 2);
            auto s = Split(line, ", ");
            if (s.size() == 3) {
                Virtual *new_vir = new Virtual(m_hash_virtual[s[1]]);
                new_vir->SetID(std::stoi(s[2]));
                vir_pool[std::stoi(s[2])] = new_vir;
                new_vir->SetAddTime(i);
                new_vir->SetDelTime(m_TolDay);
                Request *req = new Request("ADD", s[1], std::stoi(s[2]), new_vir);
                reqs.push_back(req);
            } else {
                Virtual *new_vir = vir_pool[std::stoi(s[1])];
                new_vir->SetDelTime(i);
                Request *req = new Request("DEL", std::stoi(s[1]), new_vir);
                reqs.push_back(req);
            }
        }
        m_requests.push_back(reqs);
    }
}

void Scenario::select_svr_list() {
    m_select_svr_list.clear();

    unordered_set<Server *> svr_set;
    for (auto &reqs : m_requests) {
        for (auto &req : reqs) {
            if (req->GetType() == REQ_TYPE::DEL) continue;

            const auto &vir = req->GetVirtual();
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());

            vector<pair<int, Server *>> vct;
            for (auto &svr : m_servers) {
                int node = -1;
                if (!this->match_purchase(svr, vir, node)) continue;
                double val = 0;
                const auto &svr_nodes = svr->GetNodes();
                if (vir->GetNodeCount() == 2) {
                    val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
                    val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
                } else {
                    int pid = node;
                    val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
                }
                vct.push_back({(int)(val * 100), svr});
            }
            sort(vct.begin(), vct.end(),
                 [&](const pair<int, Server *> &p1, const pair<int, Server *> &p2) { return p1.first < p2.first; });

            Server *select_svr = nullptr;
            int select_val = 0;
            for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
                const auto &svr = vct[i].second;

                int val = svr->GetHardwareCost() + svr->GetEnergyCost() * (vir->GetDelTime() - vir->GetAddTime());
                if (select_svr == nullptr || val < select_val) {
                    select_svr = svr;
                    select_val = val;
                }
            }

            svr_set.insert(select_svr);
        }
    }

    m_select_svr_list.insert(m_select_svr_list.end(), svr_set.begin(), svr_set.end());
}

void Scenario::analysis_data() {
    for (auto &reqs : m_requests) {
        for (auto &req : reqs) {
            req->debug();
        }
    }
}

void Scenario::Execute() {
    this->read_data();
    // this->analysis_data();
    this->select_svr_list();
    this->solve();
}
