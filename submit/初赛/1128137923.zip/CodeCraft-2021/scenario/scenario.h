#ifndef SCENARIO_SCENARIO_H
#define SCENARIO_SCENARIO_H

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "request.h"
#include "server.h"
#include "virtual.h"
using namespace std;

class Scenario {
   public:
    static Scenario *GetInstance();
    void Execute();
    void debug();

   private:
    Scenario(){};
    Scenario(const Scenario &) = delete;
    Scenario &operator=(const Scenario &) = delete;

    void read_data();
    void solve();

   private:
    static Scenario *Instance;
    vector<Server *> m_servers;
    vector<Virtual *> m_virtuals;
    vector<vector<Request *>> m_requests;
    int m_TolDay = 0;  // 总天数
    int m_TolSvr = 0;  // 总服务器数目
    int m_TolVir = 0;  // 总虚拟机数目
};

#endif  // SCENARIO_SCENARIO_H