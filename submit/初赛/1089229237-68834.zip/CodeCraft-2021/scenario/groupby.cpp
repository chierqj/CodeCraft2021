#include <cmath>

#include "scenario.h"
#define PI 3.14
int cal_degree(int x, int y) {
    double val = (double)y / (double)(sqrt(x * x + y * y));
    int ans = acos(val) * 180.0 / PI;
    return ans;
}

int Scenario::get_group_id(int x, int y) {
    int d = cal_degree(x, y) * GROUP_COUNT / 90;
    int ans = (d >= GROUP_COUNT ? GROUP_COUNT - 1 : d);
    return ans;
}

void Scenario::group_server() {
    for (int i = 0; i < GROUP_COUNT; ++i) {
        svr_pool.push_back(GroupSvr(i));
    }
    for (auto &svr : m_servers) {
        int cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
        int mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;
        int p = this->get_group_id(cpu, mem);
        svr_pool[p].shop.push_back(svr);
    }

    vector<int> order;
    for (int i = 1; i <= GROUP_COUNT; ++i) {
        order.push_back(i);
        order.push_back(-i);
    }

    for (int i = 0; i < GROUP_COUNT; ++i) {
        if (!svr_pool[i].shop.empty()) continue;
        for (auto &v : order) {
            int p = i + v;
            if (p < 0 || p >= GROUP_COUNT) continue;
            if (!svr_pool[p].shop.empty()) {
                svr_pool[i].shop = svr_pool[p].shop;
                break;
            }
        }
    }

    for (auto &it : svr_pool) {
        sort(it.shop.begin(), it.shop.end(), [&](const Server *svr1, const Server *svr2) {
            double cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu;
            double mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory;
            double cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu;
            double mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory;
            double s1 = (double)(svr1->GetEnergyCost() + svr1->GetHardwareCost()) / (cpu1 + mem1);
            double s2 = (double)(svr2->GetEnergyCost() + svr2->GetHardwareCost()) / (cpu2 + mem2);
            return s1 < s2;
        });
    }
}
