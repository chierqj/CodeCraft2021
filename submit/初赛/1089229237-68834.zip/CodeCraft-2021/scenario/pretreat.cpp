#include "scenario.h"

void Scenario::pretreat() {
    unordered_map<string, int> ump;
    for (auto &reqs : m_requests) {
        for (auto &req : reqs) {
            ump[req->GetVirtual()->GetName()]++;
        }
    }
    vector<pair<int, Virtual *>> vct;
    for (auto &it : ump) {
        vct.push_back({it.second, m_hash_virtual[it.first]});
    }
    sort(vct.begin(), vct.end());
    cout << "ump.size(): " << ump.size() << "\n";
    for (auto &it : vct) {
        cout << "count: " << it.first << ", " << it.second->to_string() << "\n";
    }
}