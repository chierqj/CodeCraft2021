#include "scenario.h"

// string action_migration(Virtual *vir, Server *from, Server *to) {
//     vir->del_server();
//     from->GetVirList().erase(vir);

//     if (vir->GetNodeCount() == 1) {
//         auto &nodes = to->GetNodes();
//         if (nodes[0].cpu >= vir->GetCPU() && nodes[0].memory >= vir->GetMemory()) {
//         }
//     }
// }

void Scenario::do_migration() {
    migration_result.clear();
    // migration_result.push_back("(migration, 0)");
    // return;

    int migra_count = m_VirtualPoolSize * 5 / 1000;
    if (migra_count <= 0) {
        migration_result.push_back("(migration, 0)");
        return;
    }

    vector<Server *> svr_list;

    for (auto &group : svr_pool) {
        svr_list.insert(svr_list.end(), group.buyed.begin(), group.buyed.end());
    }

    sort(svr_list.begin(), svr_list.end(), [&](const Server *svr1, const Server *svr2) {
        int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu;
        int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory;
        int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu;
        int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory;
        return cpu1 + mem1 < cpu2 + mem2;
    });

    int sz = svr_list.size();
    vector<string> ans;

    for (int i = sz - 1; i > 0; --i) {
        if (migra_count <= 0) break;
        auto svr_from = svr_list[i];
        const auto vir_list = svr_from->GetVirList();
        for (auto *vir : vir_list) {
            if (migra_count <= 0) break;
            for (int j = 0; j < i; ++j) {
                if (migra_count <= 0) break;
                int node = -1;
                const auto svr_to = svr_list[j];
                if (!this->match_purchase(svr_to, vir, node)) continue;
                vir->del_server();
                svr_to->add_virtual(vir, node, 0);
                vir->add_server(svr_to, node);
                if (node == -1) {
                    string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(svr_to->GetID()) + ")";
                    ans.push_back(s);
                } else {
                    string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(svr_to->GetID()) + ", " +
                               (node == 0 ? "A" : "B") + ")";
                    ans.push_back(s);
                }
                --migra_count;
                break;
            }
        }
    }
    migration_result.push_back("(migration, " + std::to_string(ans.size()) + ")");
    migration_result.insert(migration_result.end(), ans.begin(), ans.end());
    return;
}