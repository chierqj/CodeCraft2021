#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "scenario.h"

using namespace std;

bool Scenario::match_purchase(Server* svr, Virtual* vir, int& local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();
    int cpu1 = svr_nodes[0].cpu;
    int mem1 = svr_nodes[0].memory;
    int cpu2 = svr_nodes[1].cpu;
    int mem2 = svr_nodes[1].memory;

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem) {
            ok1 = true;
        }
        if (cpu2 >= vir_cpu && mem2 >= vir_mem) {
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)cpu1 / (double)mem1 - vir_value);
            double valB = fabs((double)cpu2 / (double)mem2 - vir_value);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem && cpu2 >= vir_cpu && mem2 >= vir_mem) {
            return true;
        }
    }
    return false;
}

void do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

Server* Scenario::get_old_server(Virtual* vir, int day, int& local_node) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : m_buyed_svr_pool) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;

        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 1000), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    // for (int i = 0; i < (int)vct.size() * 0.45; ++i) {
    for (int i = 0; i < (int)vct.size(); ++i) {
        if (i != 0) {
            double tmp_val = (double)vct[i].val / (vir_value * 1000);
            if (tmp_val > 0.3) break;
        }
        const auto& svr = vct[i].svr;
        int val = 0;
        int max_time = 0;
        for (auto& it : svr->GetVirList()) max_time = max(max_time, it->GetDelTime());

        if (vir->GetNodeCount() == 2) {
            val = svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory / 2;
            val += svr->GetNodes()[1].cpu + svr->GetNodes()[1].memory / 2;
        } else {
            int pid = vct[i].node_idx;
            val = svr->GetNodes()[pid].cpu + svr->GetNodes()[pid].memory / 2;
        }

        if (vir->GetDelTime() > max_time) {
            val += (vir->GetDelTime() - max_time) * svr->GetEnergyCost();
        }

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node_idx;
        }
    }

    return select_svr;
}

Server* Scenario::get_new_server(Virtual* vir, int day, int& local_node) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : m_select_svr_list) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;
        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;
    int delta_day = vir->GetDelTime() - day;

    for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
        const auto& svr = vct[i].svr;
        int val = (svr->GetHardwareCost() / 5 + svr->GetEnergyCost() * delta_day) /
                  (svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory / 2);
        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node_idx;
        }
    }

    return select_svr;
}

void Scenario::solve() {
    int global_index = 0;
    for (int day = 0; day < (int)m_requests.size(); ++day) {
        m_migration_count = m_VirtualPoolSize * 5 / 1000;
        this->do_migration(day);

        unordered_map<string, vector<Server*>> tmp;

        vector<Request*> tmp_req_list;
        vector<vector<Request*>> vct_block;
        auto type = m_requests[day].front()->GetType();
        for (auto& req : m_requests[day]) {
            if (req->GetType() == type) {
                tmp_req_list.push_back(req);
                continue;
            }
            vct_block.push_back(tmp_req_list);
            type = req->GetType();
            tmp_req_list.clear();
            tmp_req_list.push_back(req);
        }
        vct_block.push_back(tmp_req_list);

        for (auto& block : vct_block) {
            if (block.front()->GetType() == REQ_TYPE::ADD) {
                sort(block.begin(), block.end(), [&](const Request* req1, const Request* req2) {
                    double cpu1 = req1->GetVirtual()->GetCPU(), mem1 = req1->GetVirtual()->GetMemory();
                    double cpu2 = req2->GetVirtual()->GetCPU(), mem2 = req2->GetVirtual()->GetMemory();
                    int del_time1 = req1->GetVirtual()->GetDelTime(), del_time2 = req2->GetVirtual()->GetDelTime();
                    if (del_time1 == del_time2) {
                        double val1 = cpu1 / mem1 - 1.0;
                        double val2 = cpu2 / mem2 - 1.0;
                        return val1 > val2;
                    }
                    return del_time1 > del_time2;
                });
            }
        }

        for (auto& block : vct_block) {
            vector<Request*> left;
            for (auto& req : block) {
                if (req->GetType() == REQ_TYPE::ADD) {
                    ++m_VirtualPoolSize;
                    Server* select_svr;
                    int node = -1;

                    select_svr = get_old_server(req->GetVirtual(), day, node);
                    if (select_svr != nullptr) {
                        do_match(select_svr, req->GetVirtual(), day, node);
                        continue;
                    }
                    left.push_back(req);

                    select_svr = get_new_server(req->GetVirtual(), day, node);
                    Server* new_svr = new Server(select_svr);
                    do_match(new_svr, req->GetVirtual(), day, node);
                    m_assigned_vir_pool.push_back(req->GetVirtual());
                    m_buyed_svr_pool.push_back(new_svr);
                    tmp[new_svr->GetName()].push_back(new_svr);
                } else {
                    auto vir = req->GetVirtual();
                    vir->del_server();
                    --m_VirtualPoolSize;
                }
            }
        }

        cout << "(purchase, " << tmp.size() << ")\n";
        for (auto& it : tmp) {
            for (auto& svr : it.second) {
                svr->SetID(global_index++);
            }
            cout << "(" << it.first << ", " << it.second.size() << ")\n";
        }

        cout << "(migration, " << migration_result.size() << ")\n";
        for (auto& it : migration_result) {
            int vir_id = std::get<0>(it);
            Server* svr_to = std::get<1>(it);
            int node = std::get<2>(it);
            if (node == -1) {
                cout << "(" << vir_id << ", " << std::to_string(svr_to->GetID()) << ")\n";
            } else {
                cout << "(" << vir_id << ", " << std::to_string(svr_to->GetID()) << ", " << (node == 0 ? "A" : "B")
                     << ")\n";
            }
        }

        for (auto& req : m_requests[day]) {
            if (req->GetType() == REQ_TYPE::DEL) continue;
            const auto& vir = req->GetVirtual();
            if (vir->GetNodeCount() == 2) {
                cout << "(" << vir->GetServer()->GetID() << ")\n";
            } else {
                cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
            }
        }
    }
}