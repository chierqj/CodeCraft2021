#ifndef SCENARIO_SCENARIO_H
#define SCENARIO_SCENARIO_H

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "request.h"
#include "server.h"
#include "virtual.h"
using namespace std;

struct GroupSvr {
    GroupSvr() {}
    GroupSvr(Server *svr) : shope_server(svr) {}
    Server *shope_server;    // server类型
    vector<Server *> buyed;  // 已经购买
};

class Scenario {
   public:
    static Scenario *GetInstance();
    void Execute();
    void debug();
    void do_migration(int day_index);
    bool match_purchase(Server *svr, Virtual *vir, int &local_node);
    void do_match(Server *svr, Virtual *vir, int day_idx, int local_node);

   private:
    Scenario(){};
    Scenario(const Scenario &) = delete;
    Scenario &operator=(const Scenario &) = delete;

    // 预处理数据
    void read_data();

    // 策略
    void solve();
    Server *get_best_server(Virtual *vir, int delta_day);

   private:
    static Scenario *Instance;
    vector<Server *> m_servers;
    vector<Virtual *> m_virtuals;
    unordered_map<string, Virtual *> m_hash_virtual;
    vector<vector<Request *>> m_requests;

    const int GROUP_COUNT = 1;                             // 分组数目
    int m_TolDay = 0;                                      // 总天数
    int m_TolSvr = 0;                                      // 总服务器数目
    int m_TolVir = 0;                                      // 总虚拟机数目
    int m_VirtualPoolSize = 0;                             // 当前已经虚拟机的总数
    unordered_map<string, vector<GroupSvr *>> m_svr_pool;  // 每种虚拟机对应的svr_pool
    vector<string> migration_result;                       // 迁移结果
};

#endif  // SCENARIO_SCENARIO_H