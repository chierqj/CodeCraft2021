#include "ga.h"

#include <algorithm>
#include <cassert>
#include <queue>
#include <unordered_map>
#include <unordered_set>

#include "tools.h"

void Ga::Execute() {
    double max_fitness = 0;

    unordered_set<int> tol_vir_count;

    for (const auto &svr : m_servers) {
        this->init(svr);
        for (int i = 0; i < EPOCH; ++i) {
            this->cross(svr);
            this->select();
            if (m_popu[TOPK - 1]->fitness <= 0.1) break;
        }
        unordered_set<int> vis;
        for (int i = 0; i < TOPK; ++i) {
            Server *new_svr = new Server(svr);
            auto sce = Scenario::GetInstance();
            auto &best = m_popu[i];
            max_fitness = max(max_fitness, best->fitness);
            for (int i = 0; i < (int)best->code.size(); ++i) {
                if (best->code[i] == 0) continue;
                int node = -1;
                if (sce->match_purchase(new_svr, m_virtuals[i], node)) {
                    sce->do_match(new_svr, m_virtuals[i], 0, node);
                    vis.insert(i);
                    tol_vir_count.insert(i);
                }
            }
        }

        for (auto &it : vis) {
            m_svr_vir_table[m_virtuals[it]->GetName()].push_back(svr);
        }
    }

    for (int i = 0; i < (int)m_virtuals.size(); ++i) {
        if (tol_vir_count.find(i) == tol_vir_count.end()) {
            m_svr_vir_table[m_virtuals[i]->GetName()].push_back(m_servers[0]);
            tol_vir_count.insert(i);
        }
    }

    // cout << "安排虚拟机种类数: " << tol_vir_count.size() << ", 最大fitness: " << max_fitness << "\n";
    // for (auto &it : m_svr_vir_table) {
    //     cout << it.first << ": " << it.second.size() << "\n";
    // }
}

void Ga::calfitness(Unit *u, Server *svr) {
    auto sce = Scenario::GetInstance();
    Server *new_svr = new Server(svr);
    for (int i = 0; i < (int)u->code.size(); ++i) {
        if (u->code[i] == 0) continue;
        int node = -1;
        if (sce->match_purchase(new_svr, m_virtuals[i], node)) {
            sce->do_match(new_svr, m_virtuals[i], 0, node);
        }
    }
    u->cpuA = (double)(new_svr->GetNodes()[0].cpu) / (double)(new_svr->GetNodes()[0].read_cpu);
    u->memA = (double)(new_svr->GetNodes()[0].memory) / (double)(new_svr->GetNodes()[0].read_memory);
    u->cpuB = (double)(new_svr->GetNodes()[1].cpu) / (double)(new_svr->GetNodes()[1].read_cpu);
    u->memB = (double)(new_svr->GetNodes()[1].memory) / (double)(new_svr->GetNodes()[1].read_memory);
    u->fitness = u->cpuA + u->memA + u->cpuB + u->memB;
}

void Ga::init(Server *svr) {
    int dep_block = 10;
    m_popu.clear();
    for (int i = 0; i < POPU_SIZE / dep_block; ++i) {
        int rd = Tools::RandomInt(0, (int)m_virtuals.size() - 1);
        for (int dep = 1; dep <= dep_block; ++dep) {
            Unit *u = new Unit();
            u->code = vector<bitset<1>>(m_virtuals.size(), 0);
            for (int j = rd; j < (int)m_virtuals.size(); j += dep) {
                u->code[j] = 1;
            }
            m_popu.push_back(u);
        }
    }
    for (int i = 0; i < POPU_SIZE - (int)m_popu.size(); ++i) {
        Unit *u = new Unit();
        u->code = vector<bitset<1>>(m_virtuals.size(), 0);
        for (int j = 0; j < (int)m_virtuals.size(); ++j) {
            u->code[j] = Tools::RandomInt(0, 1);
        }
        m_popu.push_back(u);
    }
    for (auto &it : m_popu) {
        this->calfitness(it, svr);
    }
    assert((int)m_popu.size() == POPU_SIZE);
}

void Ga::cross(Server *svr) {
    for (int i = 0; i < POPU_SIZE; ++i) {
        double rd = Tools::RandomDouble(0, 1);
        if (rd > CROSS_RATE) continue;

        int l = Tools::RandomInt(0, POPU_SIZE - 1);
        int r = l;
        while (l == r) r = Tools::RandomInt(0, POPU_SIZE - 1);

        int p1 = Tools::RandomInt(0, (int)(m_virtuals.size() - 1));
        int p2 = p1;
        while (p1 == p2) p2 = Tools::RandomInt(0, (int)(m_virtuals.size() - 1));

        Unit *nu1 = new Unit(m_popu[l]), *nu2 = new Unit(m_popu[r]);
        for (int j = p1; j <= p2; ++j) {
            nu1->code[j] = m_popu[r]->code[j];
            nu2->code[j] = m_popu[l]->code[j];
        }

        this->mutation(nu1);
        this->mutation(nu2);

        this->calfitness(nu1, svr);
        this->calfitness(nu2, svr);

        m_popu.push_back(nu1);
        m_popu.push_back(nu2);
    }
}

void Ga::mutation(Unit *u) {
    double rd = Tools::RandomDouble(0, 1);
    if (rd > MUTATION_RATE) return;
    int p = Tools::RandomInt(0, (int)(m_virtuals.size() - 1));
    u->code[p] ^= 1;
}

void Ga::select() {
    struct Node {
        Unit *u;
        bool operator<(const Node &r) const { return u->fitness < r.u->fitness; }
    };
    priority_queue<Node> pq;
    double sum_fitness = 0.0;

    for (auto &it : m_popu) {
        sum_fitness += it->fitness;
        if ((int)pq.size() < TOPK) {
            pq.push(Node{it});
            continue;
        }
        if (it->fitness < pq.top().u->fitness) {
            pq.pop();
            pq.push(Node{it});
        }
    }

    vector<double> select_rate;
    double rate = 0.0;
    for (auto &it : m_popu) {
        rate += it->fitness / sum_fitness;
        select_rate.push_back(rate);
    }
    select_rate.back() = 1.0;

    vector<Unit *> sons;
    while (!pq.empty()) {
        sons.push_back(pq.top().u);
        pq.pop();
    }
    reverse(sons.begin(), sons.end());

    for (int i = 0; i < POPU_SIZE - TOPK; ++i) {
        double rd = Tools::RandomDouble(0, 1);
        auto pos = lower_bound(select_rate.begin(), select_rate.end(), rd) - select_rate.begin();
        sons.push_back(m_popu[pos]);
    }

    m_popu = sons;
}