#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "ga.h"
#include "scenario.h"

using namespace std;

bool Scenario::match_purchase(Server* svr, Virtual* vir, int& local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem) {
            local_node = 0;
            return true;
            ok1 = true;
        }
        if (svr_nodes[1].cpu >= vir_cpu && svr_nodes[1].memory >= vir_mem) {
            local_node = 1;
            return true;
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)(svr_nodes[0].cpu) / double(svr_nodes[0].memory) - vir_value);
            double valB = fabs((double)(svr_nodes[1].cpu) / double(svr_nodes[1].memory) - vir_value);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem && svr_nodes[1].cpu >= vir_cpu &&
            svr_nodes[1].memory >= vir_mem) {
            return true;
        }
    }
    return false;
}

void Scenario::do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

Server* Scenario::get_best_server(Virtual* vir, int day) {
    const auto& svr_list = m_svr_pool[vir->GetName()];
    assert(!svr_list.empty());
    // int delta_day = vir->GetDelTime() - day;

    for (auto& group : svr_list) {
        // 优先在已购列表部署
        for (auto& svr : group->buyed) {
            // svr已经相同类型
            // if (svr->GetVisVirList().find(vir->GetName()) != svr->GetVisVirList().end()) continue;
            int node = -1;
            if (!this->match_purchase(svr, vir, node)) continue;
            this->do_match(svr, vir, day, node);
            return nullptr;
        }
    }

    // 商城买新的
    int node = -1;
    static unordered_map<string, int> index;
    if (index.find(vir->GetName()) == index.end()) index[vir->GetName()] = 0;

    int sz = m_svr_pool[vir->GetName()].size();
    auto& group = m_svr_pool[vir->GetName()][index[vir->GetName()]];
    index[vir->GetName()] = (index[vir->GetName()] + 1) % sz;

    if (this->match_purchase(group->shope_server, vir, node)) {
        Server* new_svr = new Server(group->shope_server);
        do_match(new_svr, vir, day, node);
        group->buyed.push_back(new_svr);
        return new_svr;
    } else {
        assert(false);
        return nullptr;
    }
}

void Scenario::solve() {
    Ga* ga = new Ga(m_servers, m_virtuals);
    ga->Execute();

    const auto& svr_vir_table = ga->GetSvrVirTable();

    for (auto& it : svr_vir_table) {
        for (auto& svr : it.second) {
            m_svr_pool[it.first].push_back(new GroupSvr(svr));
        }
        sort(m_svr_pool[it.first].begin(), m_svr_pool[it.first].end(), [&](const GroupSvr* svr1, const GroupSvr* svr2) {
            return svr1->shope_server->GetHardwareCost() < svr2->shope_server->GetHardwareCost();
        });
    }

    int global_index = 0;
    for (int day = 0; day < (int)m_requests.size(); ++day) {
        unordered_map<string, vector<Server*>> tmp;
        this->do_migration(day);

        for (auto& req : m_requests[day]) {
            if (req->GetType() == REQ_TYPE::ADD) {
                ++m_VirtualPoolSize;

                auto select_svr = this->get_best_server(req->GetVirtual(), day);
                if (select_svr != nullptr) {
                    tmp[select_svr->GetName()].push_back(select_svr);
                }
                // if (!if_buy) {
                //     do_match(select_svr, req->GetVirtual(), day, node);
                // } else {
                //     Server* new_svr = new Server(select_svr);
                //     do_match(new_svr, req->GetVirtual(), day, node);
                //     tmp[new_svr->GetName()].push_back(new_svr);
                // }
            } else {
                auto vir = req->GetVirtual();
                vir->del_server();
                --m_VirtualPoolSize;
            }
        }

        cout << "(purchase, " << tmp.size() << ")\n";
        for (auto& it : tmp) {
            for (auto& svr : it.second) {
                svr->SetID(global_index++);
            }
            cout << "(" << it.first << ", " << it.second.size() << ")\n";
        }

        for (auto& it : migration_result) cout << it << "\n";

        for (auto& req : m_requests[day]) {
            if (req->GetType() == REQ_TYPE::DEL) continue;
            const auto& vir = req->GetVirtual();
            if (vir->GetNodeCount() == 2) {
                cout << "(" << vir->GetServer()->GetID() << ")\n";
            } else {
                cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
            }
        }
    }
}