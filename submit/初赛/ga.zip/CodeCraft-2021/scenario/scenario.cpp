#include "scenario.h"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "ga.h"

using namespace std;
Scenario* Scenario::Instance = nullptr;

Scenario* Scenario::GetInstance() {
    if (Instance == nullptr) {
        Instance = new Scenario();
    }
    return Instance;
}

void Scenario::debug() {}

void Scenario::Execute() {
    this->read_data();
    this->solve();
}

std::vector<std::string> Split(std::string str, std::string pattern) {
    std::string::size_type pos;
    std::vector<std::string> result;
    str += pattern;  //扩展字符串以方便操作
    size_t size = str.size();
    for (size_t i = 0; i < size; i++) {
        pos = str.find(pattern, i);
        if (pos < size) {
            std::string s = str.substr(i, pos - i);
            result.push_back(s);
            i = pos + pattern.size() - 1;
        }
    }
    return result;
}

void Scenario::read_data() {
    string line;
    getline(cin, line);
    int n = std::stoi(line);
    m_TolSvr = n;
    for (int i = 0; i < n; ++i) {
        getline(cin, line);
        line = line.substr(1, line.size() - 2);
        auto s = Split(line, ", ");
        Server* server = new Server(s[0], std::stoi(s[1]), std::stoi(s[2]), std::stoi(s[3]), std::stoi(s[4]));
        m_servers.push_back(server);
    }
    getline(cin, line);
    int m = std::stoi(line);
    m_TolVir = m;

    for (int i = 0; i < m; ++i) {
        getline(cin, line);
        line = line.substr(1, line.size() - 2);
        auto s = Split(line, ", ");
        Virtual* vir = new Virtual(s[0], std::stoi(s[1]), std::stoi(s[2]), std::stoi(s[3]) + 1);
        m_virtuals.push_back(vir);
        m_hash_virtual[s[0]] = vir;
    }
    getline(cin, line);
    int t = std::stoi(line);
    m_TolDay = t;

    unordered_map<int, Virtual*> vir_pool;

    for (int i = 0; i < t; ++i) {
        getline(cin, line);
        int r = std::stoi(line);
        vector<Request*> reqs;
        for (int j = 0; j < r; ++j) {
            getline(cin, line);
            line = line.substr(1, line.size() - 2);
            auto s = Split(line, ", ");
            if (s.size() == 3) {
                Virtual* new_vir = new Virtual(m_hash_virtual[s[1]]);
                new_vir->SetID(std::stoi(s[2]));
                vir_pool[std::stoi(s[2])] = new_vir;
                new_vir->SetAddTime(i);
                new_vir->SetDelTime(m_TolDay);
                Request* req = new Request("ADD", s[1], std::stoi(s[2]), new_vir);
                reqs.push_back(req);
            } else {
                Virtual* new_vir = vir_pool[std::stoi(s[1])];
                new_vir->SetDelTime(i);
                Request* req = new Request("DEL", std::stoi(s[1]), new_vir);
                reqs.push_back(req);
            }
        }
        m_requests.push_back(reqs);
    }
}
