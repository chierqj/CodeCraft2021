#include "scenario.h"

void Scenario::do_migration(int day_index) {
    migration_result.clear();
    migration_result.push_back("(migration, 0)");
    return;

    // auto &reqs = m_requests[day_index];
    // migration_result.clear();
    // migration_result.push_back("(migration, 0)");
    // int migra_count = m_VirtualPoolSize * 5 / 1000;

    // for (auto &group : svr_pool) {
    //     // vector<Server *> svr_list;
    //     // svr_list.insert(svr_list.end(), group.buyed.begin(), group.buyed.end());
    //     sort(group.buyed.begin(), group.buyed.end(), [&](const Server *svr1, const Server *svr2) {
    //         int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu;
    //         int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory;
    //         int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu;
    //         int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory;
    //         return cpu1 + mem1 / 2 > cpu2 + mem2 / 2;
    //     });
    //     int sz = group.buyed.size();
    //     for (int i = 0; i < sz - 1; ++i) {
    //         if (migra_count <= 0) break;
    //         auto svr_from = group.buyed[i];
    //         const auto &from_node = svr_from->GetNodes();
    //         double rate1 = min((double)from_node[0].cpu / (double)(from_node[0].read_cpu),
    //                            (double)from_node[0].memory / (double)(from_node[0].read_memory));
    //         double rate2 = min((double)from_node[1].cpu / (double)(from_node[1].read_cpu),
    //                            (double)from_node[1].memory / (double)(from_node[1].read_memory));
    //         if (rate1 + rate2 <= 0.05) {
    //             continue;
    //         }

    //         const auto vir_list = svr_from->GetVirList();

    //         for (auto &vir : vir_list) {
    //             if (migra_count <= 0) break;
    //             for (int j = sz - 1; j > i; --j) {
    //                 if (migra_count <= 0) break;
    //                 int node = -1;
    //                 const auto svr_to = group.buyed[j];
    //                 if (!this->match_purchase(svr_to, vir, node)) continue;
    //                 vir->del_server();
    //                 svr_to->add_virtual(vir, node, 0);
    //                 vir->add_server(svr_to, node);
    //                 if (node == -1) {
    //                     string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(svr_to->GetID()) + ")";
    //                     migration_result.push_back(s);
    //                 } else {
    //                     string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(svr_to->GetID()) + ", "
    //                     +
    //                                (node == 0 ? "A" : "B") + ")";
    //                     migration_result.push_back(s);
    //                 }
    //                 --migra_count;
    //                 break;
    //             }
    //         }
    //     }
    // }

    // migration_result[0] = "(migration, " + std::to_string(migration_result.size() - 1) + ")";
    // return;
}