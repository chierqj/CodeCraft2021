#ifndef SCENARIO_GA_H
#define SCENARIO_GA_H

#include <bitset>
#include <cstdio>
#include <iostream>
#include <vector>

#include "scenario.h"
#include "server.h"
#include "virtual.h"
using namespace std;

struct Unit {
    vector<bitset<1>> code;
    double cpuA, memA, cpuB, memB;
    double fitness;

    Unit() {}
    Unit(Unit *u) {
        code = u->code;
        cpuA = 0;
        memA = 0;
        cpuB = 0;
        memB = 0;
        fitness = 0;
    };
    void debug() {
        printf("[cpuA: %.3f, memA: %.3f] [cpuB: %.3f, memB: %.3f] [fitness: %.3f]\n", cpuA, memA, cpuB, memB, fitness);
    }
};

class Scenario;

class Ga {
   public:
    Ga(const vector<Server *> &servers, const vector<Virtual *> &virtuals) : m_servers(servers), m_virtuals(virtuals) {}
    void Execute();
    const unordered_map<string, vector<Server *>> &GetSvrVirTable() { return m_svr_vir_table; }

   private:
    void init(Server *svr);
    void calfitness(Unit *u, Server *svr);
    void cross(Server *svr);
    void mutation(Unit *u);
    void select();

   private:
    const vector<Server *> &m_servers;
    const vector<Virtual *> &m_virtuals;

    const int EPOCH = 100;
    const int POPU_SIZE = 500;
    const int TOPK = 10;
    const double CROSS_RATE = 0.80;
    const double MUTATION_RATE = 0.2;

    vector<Unit *> m_popu;
    unordered_map<string, vector<Server *>> m_svr_vir_table;
};

#endif