#include "request.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <vector>

void Request::debug() {
    // log_debug("请求: (%s, %s, %d)", (type == REQ_TYPE::ADD ? "ADD" : "DEL"), vir_name.c_str(), vir_id);
}

string Request::to_string() {
    string msg = "请求: (";
    msg += (type == REQ_TYPE::ADD ? "ADD" : "DEL");
    msg += ", ";
    msg += vir_name + ", ";
    msg += std::to_string(vir_id) + ")";
    return msg;
}