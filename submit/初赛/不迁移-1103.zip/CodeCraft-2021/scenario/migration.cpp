#include <algorithm>
#include <cassert>

#include "scenario.h"

double Scenario::get_used_rate(Server *svr, Virtual *vir, int local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();

    double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu - vir_cpu;
    double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory - vir_mem;
    double read_cpu = svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu;
    double read_mem = svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory;

    // return cpu + mem / 2;
    return (1.0 - cpu / read_cpu) + (1.0 - mem / read_mem);
}

// void Scenario::do_migration(int day) {
//     migration_result.clear();
//     int migra_count = m_migration_count;
//     return;
//     if (migra_count <= 0) return;

//     vector<Virtual *> vir_list;
//     for (auto &svr : m_buyed_svr_pool) {
//         const auto &nodes = svr->GetNodes();
//         double cpu1 = nodes[0].cpu - nodes[0].del_cpu, cpu2 = nodes[1].cpu - nodes[1].del_cpu;
//         double mem1 = nodes[0].memory - nodes[0].del_memory, mem2 = nodes[1].memory - nodes[1].del_memory;
//         double rate1 = min(cpu1 / (double)nodes[0].read_cpu, mem1 / (double)nodes[0].read_memory);
//         double rate2 = min(cpu2 / (double)nodes[1].read_cpu, mem2 / (double)nodes[1].read_memory);
//         if (rate1 + rate2 <= 0.15) {
//             continue;
//         }
//         const auto vir_tmp = svr->GetVirList();
//         vir_list.insert(vir_list.end(), vir_tmp.begin(), vir_tmp.end());
//     }

//     sort(m_buyed_svr_pool.begin(), m_buyed_svr_pool.end(), [&](const Server *svr1, const Server *svr2) {
//         int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu - svr1->GetNodes()[0].del_cpu -
//                    svr1->GetNodes()[1].del_cpu;
//         int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory - svr1->GetNodes()[0].del_memory -
//                    svr1->GetNodes()[1].del_memory;
//         int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu - svr2->GetNodes()[0].del_cpu -
//                    svr2->GetNodes()[1].del_cpu;
//         int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory - svr2->GetNodes()[0].del_memory -
//                    svr2->GetNodes()[1].del_memory;
//         return cpu1 + mem1 / 2 < cpu2 + mem2 / 2;
//     });
//     sort(vir_list.begin(), vir_list.end(), [&](const Virtual *vir1, const Virtual *vir2) {
//         auto svr1 = vir1->GetServer();
//         auto svr2 = vir2->GetServer();
//         int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu - svr1->GetNodes()[0].del_cpu -
//                    svr1->GetNodes()[1].del_cpu;
//         int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory - svr1->GetNodes()[0].del_memory -
//                    svr1->GetNodes()[1].del_memory;
//         int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu - svr2->GetNodes()[0].del_cpu -
//                    svr2->GetNodes()[1].del_cpu;
//         int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory - svr2->GetNodes()[0].del_memory -
//                    svr2->GetNodes()[1].del_memory;
//         return cpu1 + mem1 / 2 > cpu2 + mem2 / 2;
//     });

//     for (auto &vir : vir_list) {
//         if (vir->GetAddTime() == day || vir->GetDelTime() == day) continue;
//         if (migra_count <= 0) break;
//         for (auto &svr_to : m_buyed_svr_pool) {
//             if (vir->GetServer()->GetID() == svr_to->GetID()) break;
//             int node = -1;
//             if (!this->match_purchase(svr_to, vir, node)) continue;
//             vir->del_server();
//             svr_to->add_virtual(vir, node, 0);
//             vir->add_server(svr_to, node);
//             migration_result.push_back({vir->GetID(), svr_to, node});
//             --migra_count;
//             break;
//         }
//     }

//     return;
// }

void Scenario::do_migration(int day) {
    migration_result.clear();
    return;
    int migra_count = m_migration_count;
    if (migra_count <= 0) return;

    sort(m_buyed_svr_pool.begin(), m_buyed_svr_pool.end(), [&](const Server *svr1, const Server *svr2) {
        int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu - svr1->GetNodes()[0].del_cpu -
                   svr1->GetNodes()[1].del_cpu;
        int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory - svr1->GetNodes()[0].del_memory -
                   svr1->GetNodes()[1].del_memory;
        int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu - svr2->GetNodes()[0].del_cpu -
                   svr2->GetNodes()[1].del_cpu;
        int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory - svr2->GetNodes()[0].del_memory -
                   svr2->GetNodes()[1].del_memory;
        // return cpu1 + mem1 / 2 > cpu2 + mem2 / 2;
        return cpu1 + mem1 < cpu2 + mem2;
    });

    int sz = m_buyed_svr_pool.size();
    for (int i = 0; i < sz; ++i) {
        const auto &svr_from = m_buyed_svr_pool[i];
        vector<Virtual *> vir_list(svr_from->GetVirList().begin(), svr_from->GetVirList().end());
        for (auto &vir : vir_list) {
            if (vir->GetAddTime() == day || vir->GetDelTime() == day) continue;
            for (int j = sz - 1; j > i; --j) {
                const auto &svr_to = m_buyed_svr_pool[j];
                int node = -1;
                if (!this->match_purchase(svr_to, vir, node)) continue;
                vir->del_server();
                svr_to->add_virtual(vir, node, 0);
                vir->add_server(svr_to, node);
                migration_result.push_back({vir->GetID(), svr_to, node});
                --migra_count;
                if (migra_count <= 0) return;
            }
        }
    }

    return;
}
