#include <algorithm>
#include <cassert>

#include "scenario.h"

double Scenario::get_used_rate(Server *svr, Virtual *vir, int local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();

    double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu - vir_cpu;
    double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory - vir_mem;
    double read_cpu = svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu;
    double read_mem = svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory;

    return 1.0 - (cpu + mem) / (read_cpu + read_mem);
}

void Scenario::do_migration(int day) {
    migration_result.clear();
    int migra_count = m_VirtualPoolSize * 5 / 1000;
    if (migra_count <= 0) return;

    vector<Virtual *> vir_list;
    for (auto &svr : m_buyed_svr_pool) {
        const auto vir_tmp = svr->GetVirList();
        vir_list.insert(vir_list.end(), vir_tmp.begin(), vir_tmp.end());
    }

    sort(vir_list.begin(), vir_list.end(), [&](const Virtual *vir1, const Virtual *vir2) {
        auto svr1 = vir1->GetServer();
        auto svr2 = vir2->GetServer();
        int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu;
        int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory;
        int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu;
        int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory;
        return cpu1 + mem1 / 2 > cpu2 + mem2 / 2;
    });

    sort(m_buyed_svr_pool.begin(), m_buyed_svr_pool.end(), [&](const Server *svr1, const Server *svr2) {
        int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu;
        int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory;
        int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu;
        int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory;
        return cpu1 + mem1 / 2 < cpu2 + mem2 / 2;
    });

    unordered_map<int, int> idx;
    for (int i = 0; i < (int)m_buyed_svr_pool.size(); ++i) {
        idx[m_buyed_svr_pool[i]->GetID()] = i;
    }

    auto get_svr = [&](Virtual *vir) -> Server * {
        for (auto &svr : m_buyed_svr_pool) {
            if (svr->GetID() == vir->GetServer()->GetID()) return nullptr;
            int node = -1;
            if (this->match_purchase(svr, vir, node)) {
                return svr;
            }
        }
        return nullptr;
    };

    Server *select_svr = nullptr;
    for (auto &vir : vir_list) {
        if (migra_count <= 0) return;
        int p = idx[vir->GetServer()->GetID()];
        if (p <= 0) continue;
        const auto &big_svr = m_buyed_svr_pool[p - 1];
        int big_cpu = big_svr->GetNodes()[0].cpu + big_svr->GetNodes()[1].cpu;
        int big_mem = big_svr->GetNodes()[0].memory + big_svr->GetNodes()[1].memory;

        int chier_cpu = vir->GetCPU(), chier_mem = vir->GetMemory();
        if (big_cpu + big_mem / 2 < chier_cpu + chier_mem / 2) continue;

        int node = -1;
        if (select_svr == nullptr || select_svr->GetID() == vir->GetServer()->GetID() ||
            !this->match_purchase(select_svr, vir, node)) {
            select_svr = get_svr(vir);
        }
        if (select_svr == nullptr) continue;
        node = -1;
        if (!this->match_purchase(select_svr, vir, node)) continue;

        vir->del_server();
        select_svr->add_virtual(vir, node, day);
        vir->add_server(select_svr, node);
        migration_result.push_back({vir->GetID(), select_svr, node});
        --migra_count;

        // for (auto &svr_to : m_buyed_svr_pool) {
        //     if (vir->GetServer()->GetID() == svr_to->GetID()) continue;
        //     int node = -1;
        //     if (!this->match_purchase(svr_to, vir, node)) continue;
        //     int cpu = svr_to->GetNodes()[0].cpu + svr_to->GetNodes()[1].cpu;
        //     int mem = svr_to->GetNodes()[0].memory + svr_to->GetNodes()[1].memory;
        //     int val = cpu + mem / 2;

        //     if (select_svr == nullptr || val < select_val) {
        //         select_svr = svr_to;
        //         select_val = val;
        //         select_node = node;
        //     }
        // }

        // if (select_svr != nullptr) {
        //     vir->del_server();
        //     select_svr->add_virtual(vir, select_node, 0);
        //     vir->add_server(select_svr, select_node);
        //     migration_result.push_back({vir->GetID(), select_svr, select_node});
        //     --migra_count;
        // }
    }
    return;
}
