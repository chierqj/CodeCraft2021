#ifndef SCENARIO_SCENARIO_H
#define SCENARIO_SCENARIO_H

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "request.h"
#include "server.h"
#include "virtual.h"
using namespace std;

struct GroupSvr {
    GroupSvr() {}
    GroupSvr(int _id) { id = _id; }
    void debug() {
        cout << "******* 编号: " << id << " *******\n";
        cout << "* 已购列表: \n";
        for (auto &it : buyed) it->debug();
        cout << "* 商城列表: \n";
        for (auto &it : shop) it->debug();
    }

    int id;                  // 组编号
    vector<Server *> buyed;  // 已经购买
    vector<Server *> shop;   // 商城
};

class Scenario {
   public:
    static Scenario *GetInstance();
    void Execute();
    void debug();

   private:
    Scenario(){};
    Scenario(const Scenario &) = delete;
    Scenario &operator=(const Scenario &) = delete;

    void read_data();
    void analysis_data();
    void select_svr_list();
    void solve();
    double get_used_rate(Server *svr, Virtual *vir, int local_node);
    void do_migration(int day);
    bool match_purchase(Server *svr, Virtual *vir, int &local_node);
    Server *get_old_server(Virtual *vir, int day, int &local_node);
    Server *get_new_server(Virtual *vir, int day, int &local_node);

   private:
    static Scenario *Instance;
    vector<Server *> m_servers;
    vector<Virtual *> m_virtuals;
    unordered_map<string, Virtual *> m_hash_virtual;
    vector<vector<Request *>> m_requests;

    const int GROUP_COUNT = 1;  // 分组数目
    int m_TolDay = 0;           // 总天数
    int m_TolSvr = 0;           // 总服务器数目
    int m_TolVir = 0;           // 总虚拟机数目
    int m_VirtualPoolSize = 0;  // 当前已经虚拟机的总数
    int m_migration_count = 0;  // 当前可迁移数目

    vector<tuple<int, Server *, int>> migration_result;  // vir->svr_to->localnode
    vector<Server *> m_select_svr_list;                  // 根据请求选出来的
    vector<Server *> m_buyed_svr_pool;                   // 已经购买的svr
    vector<Virtual *> m_assigned_vir_pool;               // 已经部署的vir
    vector<Server *> m_special_svr_pool;                 // 特殊的pool

    // for data analysis
    unordered_map<string, unordered_set<Server *>> m_reset_svr_list;
};

#endif  // SCENARIO_SCENARIO_H