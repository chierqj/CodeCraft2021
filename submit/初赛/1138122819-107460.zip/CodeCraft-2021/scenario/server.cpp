#include "server.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;

void Server::debug() const {
    cout << "(服务器: " << name << ", A:";
    cout << m_nodes[0].to_string() << ", B:";
    cout << m_nodes[1].to_string() << ", ";
    cout << m_hardware_cost << ", ";
    cout << m_energy_cost << "\n";
}

string Server::to_string() {
    string msg = "服务器: (";
    // msg += name + ", ";
    // msg += std::to_string(m_cpu) + ", ";
    // msg += std::to_string(m_memory) + ", ";
    // msg += std::to_string(m_hardware_cost) + ", ";
    // msg += std::to_string(m_energy_cost) + ")";
    return msg;
}

void Server::add_virtual(Virtual* vir, int node, int day_idx) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    if (vir->GetNodeCount() == 1) {
        this->SetNodeByID({m_nodes[node].cpu - vir_cpu, m_nodes[node].memory - vir_mem}, node);
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        this->SetNodeByID({m_nodes[0].cpu - vir_cpu, m_nodes[0].memory - vir_mem}, 0);
        this->SetNodeByID({m_nodes[1].cpu - vir_cpu, m_nodes[1].memory - vir_mem}, 1);
    }
    if (this->GetAddTime() == -1) this->SetAddTime(day_idx);
    this->SetDelTime(max(this->GetDelTime(), vir->GetDelTime()));
    vir_list.insert(vir);
}

void Server::del_virtual(Virtual* vir, int node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    if (vir->GetNodeCount() == 1) {
        this->SetNodeByID({m_nodes[node].cpu + vir_cpu, m_nodes[node].memory + vir_mem}, node);
    } else {
        this->SetNodeByID({m_nodes[0].cpu + (vir_cpu >> 1), m_nodes[0].memory + (vir_mem >> 1)}, 0);
        this->SetNodeByID({m_nodes[1].cpu + (vir_cpu >> 1), m_nodes[1].memory + (vir_mem >> 1)}, 1);
    }
    vir_list.erase(vir);
}