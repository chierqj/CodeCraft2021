#include "simulation.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "scenario/scenario.h"
using namespace std;

void Simulation::RunFrameWork() {
    auto sce = Scenario::GetInstance();
    sce->Execute();
}