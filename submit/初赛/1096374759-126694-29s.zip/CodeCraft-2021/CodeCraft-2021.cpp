#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "simulation/simulation.h"

using namespace std;

int main(int argc, char **argv) {
    Simulation *sim = new Simulation();
    sim->RunFrameWork();
    return 0;
}