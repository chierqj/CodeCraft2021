#include "virtual.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

void Virtual::debug() {
    cout << "虚拟机: (" << name << ", ";
    cout << "cpu: " << m_cpu << ", ";
    cout << "mem: " << m_memory << ", ";
    cout << "node_count: " << m_node_count << ", ";
    cout << "local_node: " << local_node << ", ";
    cout << "add_time: " << add_time << ", ";
    cout << "del_time: " << add_time << ")\n";
}

string Virtual::to_string() {
    string msg = "虚拟机: (" + name + ", ";
    msg += "cpu: " + std::to_string(m_cpu) + ", ";
    msg += "mem: " + std::to_string(m_memory) + ", ";
    msg += "node_count: " + std::to_string(m_node_count) + ", ";
    msg += "local_node: " + std::to_string(local_node) + ", ";
    msg += "add_time: " + std::to_string(add_time) + ", ";
    msg += "del_time: " + std::to_string(del_time) + ")";
    return msg;
}

void Virtual::del_server() {
    m_svr->del_virtual(this, local_node);
    m_svr = nullptr;
}

void Virtual::add_server(Server *svr, int node) {
    m_svr = svr;
    local_node = node;
}