#include <algorithm>
#include <cassert>

#include "scenario.h"

void Scenario::do_migration(int day) {
    migration_result.clear();
    migration_result.push_back("(migration, 0)");
    int migra_count = m_VirtualPoolSize * 5 / 1000;

    sort(m_buyed_svr_pool.begin(), m_buyed_svr_pool.end(), [&](const Server *svr1, const Server *svr2) {
        int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu;
        int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory;
        int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu;
        int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory;
        return cpu1 + mem1 / 2 < cpu2 + mem2 / 2;
    });
    vector<Virtual *> vir_list;
    for (auto &svr : m_buyed_svr_pool) {
        const auto vir_tmp = svr->GetVirList();
        vir_list.insert(vir_list.end(), vir_tmp.begin(), vir_tmp.end());
    }

    sort(vir_list.begin(), vir_list.end(), [&](const Virtual *vir1, const Virtual *vir2) {
        int cpu1 = vir1->GetServer()->GetNodes()[0].cpu + vir1->GetServer()->GetNodes()[1].cpu;
        int mem1 = vir1->GetServer()->GetNodes()[0].memory + vir1->GetServer()->GetNodes()[1].memory;
        int cpu2 = vir2->GetServer()->GetNodes()[0].cpu + vir2->GetServer()->GetNodes()[1].cpu;
        int mem2 = vir2->GetServer()->GetNodes()[0].memory + vir2->GetServer()->GetNodes()[1].memory;
        return cpu1 + mem1 / 2 > cpu2 + mem2 / 2;
    });

    for (auto &vir : vir_list) {
        if (migra_count <= 0) break;
        for (auto &svr : m_buyed_svr_pool) {
            if (svr->GetID() == vir->GetServer()->GetID()) continue;
            if (migra_count <= 0) break;
            int node = -1;
            if (!this->match_purchase(svr, vir, node)) continue;
            vir->del_server();
            svr->add_virtual(vir, node, 0);
            vir->add_server(svr, node);

            if (node == -1) {
                string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(svr->GetID()) + ")";
                migration_result.push_back(s);
            } else {
                string s = "(" + std::to_string(vir->GetID()) + ", " + std::to_string(svr->GetID()) + ", " +
                           (node == 0 ? "A" : "B") + ")";
                migration_result.push_back(s);
            }
            --migra_count;
            break;
        }
    }

    migration_result[0] = "(migration, " + std::to_string(migration_result.size() - 1) + ")";
    return;
}
