#ifndef SCENARIO_SCENARIO_H
#define SCENARIO_SCENARIO_H

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "request.h"
#include "server.h"
#include "virtual.h"
using namespace std;

struct GroupSvr {
    GroupSvr() {}
    GroupSvr(int _id) { id = _id; }
    void debug() {
        cout << "******* 编号: " << id << " *******\n";
        cout << "* 已购列表: \n";
        for (auto &it : buyed) it->debug();
        cout << "* 商城列表: \n";
        for (auto &it : shop) it->debug();
    }

    int id;                  // 组编号
    vector<Server *> buyed;  // 已经购买
    vector<Server *> shop;   // 商城
};

class Scenario {
   public:
    static Scenario *GetInstance();
    void Execute();
    void debug();

   private:
    Scenario(){};
    Scenario(const Scenario &) = delete;
    Scenario &operator=(const Scenario &) = delete;

    void read_data();
    int get_group_id(int x, int y);
    void group_server();
    void solve();
    void do_migration();
    bool match_purchase(Server *svr, Virtual *vir, int &local_node);
    Server *get_old_server(const vector<Server *> &svr_pool, Virtual *vir, int delta_day, int &cost, int &local_node);
    Server *get_new_server(const vector<Server *> &svr_pool, Virtual *vir, int delta_day, int &cost, int &local_node);

   private:
    static Scenario *Instance;
    vector<Server *> m_servers;
    vector<Virtual *> m_virtuals;
    vector<vector<Request *>> m_requests;

    const int GROUP_COUNT = 1;
    int m_TolDay = 0;                 // 总天数
    int m_TolSvr = 0;                 // 总服务器数目
    int m_TolVir = 0;                 // 总虚拟机数目
    int m_VirtualPoolSize = 0;        // 当前已经虚拟机的总数
    vector<GroupSvr> svr_pool;        // 分组后的服务器列表
    vector<string> migration_result;  // 迁移结果
};

#endif  // SCENARIO_SCENARIO_H