#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "scenario.h"

using namespace std;

bool match(Server* svr, Virtual* vir) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();
    vir->SetLocalNode(-1);

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem) {
            ok1 = true;
        }
        if (svr_nodes[1].cpu >= vir_cpu && svr_nodes[1].memory >= vir_mem) {
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)(svr_nodes[0].cpu) / double(svr_nodes[0].memory) - vir_value);
            double valB = fabs((double)(svr_nodes[1].cpu) / double(svr_nodes[1].memory) - vir_value);
            vir->SetLocalNode(valA < valB ? 0 : 1);
            return true;
        }
        if (ok1 || ok2) {
            vir->SetLocalNode(ok1 ? 0 : 1);
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem && svr_nodes[1].cpu >= vir_cpu &&
            svr_nodes[1].memory >= vir_mem) {
            return true;
        }
    }
    return false;
}

void do_match(Server* svr, Virtual* vir, int day_idx) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();

    if (vir->GetNodeCount() == 1) {
        int pid = vir->GetLocalNode();
        svr->SetNodeByID({svr_nodes[pid].cpu - vir_cpu, svr_nodes[pid].memory - vir_mem}, pid);
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        svr->SetNodeByID({svr_nodes[0].cpu - vir_cpu, svr_nodes[0].memory - vir_mem}, 0);
        svr->SetNodeByID({svr_nodes[1].cpu - vir_cpu, svr_nodes[1].memory - vir_mem}, 1);
    }
    if (svr->GetAddTime() == -1) svr->SetAddTime(day_idx);
    svr->SetDelTime(max(svr->GetDelTime(), vir->GetDelTime()));
    vir->SetServer(svr);
}

Server* get_old_server(const vector<Server*>& svr_pool, Virtual* vir, int delta_day) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : svr_pool) {
        if (!match(svr, vir)) continue;

        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = vir->GetLocalNode();
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), vir->GetLocalNode(), svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.3; ++i) {
        const auto& svr = vct[i].svr;
        int val = 0;
        if (vir->GetLocalNode() == -1) {
            val = svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory;
            val += svr->GetNodes()[1].cpu + svr->GetNodes()[1].memory;
        } else {
            int pid = vir->GetLocalNode();
            val = svr->GetNodes()[pid].cpu + svr->GetNodes()[pid].memory;
        }

        if (vir->GetDelTime() > svr->GetDelTime()) {
            val += 0.3 * (double)(vir->GetDelTime() - svr->GetDelTime()) * svr->GetEnergyCost();
        }

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            vir->SetLocalNode(vct[i].node_idx);
        }
    }
    return select_svr;
}

Server* get_new_server(const vector<Server*>& svr_pool, Virtual* vir, int delta_day) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : svr_pool) {
        if (!match(svr, vir)) continue;
        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = vir->GetLocalNode();
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), vir->GetLocalNode(), svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.2; ++i) {
        const auto& svr = vct[i].svr;
        int val = svr->GetHardwareCost() + svr->GetEnergyCost() * delta_day;
        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            vir->SetLocalNode(vct[i].node_idx);
        }
    }

    return select_svr;
}

void Scenario::solve() {
    vector<Server*> svr_pool;

    int global_index = 0, day_index = -1;
    for (auto& reqs : m_requests) {
        day_index++;
        unordered_map<string, vector<Server*>> tmp;

        for (auto& req : reqs) {
            if (req->GetType() == REQ_TYPE::ADD) {
                int delta_day = req->GetVirtual()->GetDelTime() - day_index;

                auto select_svr = get_old_server(svr_pool, req->GetVirtual(), delta_day);
                if (select_svr != nullptr) {
                    do_match(select_svr, req->GetVirtual(), day_index);
                } else {
                    select_svr = get_new_server(m_servers, req->GetVirtual(), delta_day);
                    Server* new_svr = new Server(select_svr);
                    do_match(new_svr, req->GetVirtual(), day_index);
                    svr_pool.push_back(new_svr);
                    tmp[new_svr->GetName()].push_back(new_svr);
                }
            } else {
                auto vir = req->GetVirtual();
                vir->release_server();
            }
        }

        cout << "(purchase, " << tmp.size() << ")\n";
        for (auto& it : tmp) {
            for (auto& svr : it.second) {
                svr->SetID(global_index++);
            }
            cout << "(" << it.first << ", " << it.second.size() << ")\n";
        }
        cout << "(migration, 0)\n";
        for (auto& req : reqs) {
            if (req->GetType() == REQ_TYPE::DEL) continue;
            const auto& vir = req->GetVirtual();
            if (vir->GetNodeCount() == 2) {
                cout << "(" << vir->GetServer()->GetID() << ")\n";
            } else {
                cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
            }
        }
    }
}