#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "scenario.h"

using namespace std;

bool Scenario::match_purchase(Server* svr, Virtual* vir, int& local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem) {
            ok1 = true;
        }
        if (svr_nodes[1].cpu >= vir_cpu && svr_nodes[1].memory >= vir_mem) {
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)(svr_nodes[0].cpu) / double(svr_nodes[0].memory) - vir_value);
            double valB = fabs((double)(svr_nodes[1].cpu) / double(svr_nodes[1].memory) - vir_value);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (svr_nodes[0].cpu >= vir_cpu && svr_nodes[0].memory >= vir_mem && svr_nodes[1].cpu >= vir_cpu &&
            svr_nodes[1].memory >= vir_mem) {
            return true;
        }
    }
    return false;
}

void do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

Server* Scenario::get_old_server(Virtual* vir, int delta_day, int& local_node) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : m_buyed_svr_pool) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;

        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 1000), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.45; ++i) {
        const auto& svr = vct[i].svr;
        int val = 0;
        int max_time = 0;
        for (auto& it : svr->GetVirList()) max_time = max(max_time, it->GetDelTime());

        if (vir->GetNodeCount() == 2) {
            val = svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory / 2;
            val += svr->GetNodes()[1].cpu + svr->GetNodes()[1].memory / 2;
        } else {
            int pid = vct[i].node_idx;
            val = svr->GetNodes()[pid].cpu + svr->GetNodes()[pid].memory / 2;
        }

        if (vir->GetDelTime() > max_time) {
            val += (vir->GetDelTime() - max_time) * svr->GetEnergyCost();
        }

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node_idx;
        }
    }
    return select_svr;
}

Server* Scenario::get_new_server(Virtual* vir, int delta_day, int& local_node) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    vector<Node> vct;

    for (const auto& svr : m_select_svr_list) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;
        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs((double)svr_nodes[0].cpu / (double)svr_nodes[0].memory - vir_value);
            val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 1000), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.5; ++i) {
        const auto& svr = vct[i].svr;
        int val = svr->GetHardwareCost() / 5 + svr->GetEnergyCost() * delta_day;
        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node_idx;
        }
    }

    return select_svr;
}

void Scenario::solve() {
    int global_index = 0;
    for (int day = 0; day < (int)m_requests.size(); ++day) {
        unordered_map<string, vector<Server*>> tmp;
        this->do_migration(day);

        vector<Request*> tmp_req_list;
        vector<vector<Request*>> vct_block;
        auto type = m_requests[day].front()->GetType();
        for (auto& req : m_requests[day]) {
            if (req->GetType() == type) {
                tmp_req_list.push_back(req);
                continue;
            }
            vct_block.push_back(tmp_req_list);
            type = req->GetType();
            tmp_req_list.clear();
            tmp_req_list.push_back(req);
        }
        vct_block.push_back(tmp_req_list);

        vector<Request*> new_req_list;
        for (auto& block : vct_block) {
            if (block.front()->GetType() == REQ_TYPE::ADD) {
                sort(block.begin(), block.end(), [&](const Request* req1, const Request* req2) {
                    if (req1->GetVirtual()->GetDelTime() == req2->GetVirtual()->GetDelTime()) {
                        double val1 =
                            fabs((double)req1->GetVirtual()->GetCPU() / (double)req1->GetVirtual()->GetMemory() - 1.0);
                        double val2 =
                            fabs((double)req2->GetVirtual()->GetCPU() / (double)req2->GetVirtual()->GetMemory() - 1.0);
                        return val1 < val2;
                    }
                    return req1->GetVirtual()->GetDelTime() > req2->GetVirtual()->GetDelTime();
                });
            }
            new_req_list.insert(new_req_list.end(), block.begin(), block.end());
        }

        for (auto& req : new_req_list) {
            if (req->GetType() == REQ_TYPE::ADD) {
                ++m_VirtualPoolSize;

                Server* select_svr;
                int node = -1;
                int delta_day = req->GetVirtual()->GetDelTime() - day;

                select_svr = get_old_server(req->GetVirtual(), delta_day, node);
                if (select_svr != nullptr) {
                    do_match(select_svr, req->GetVirtual(), day, node);
                    continue;
                }
                select_svr = get_new_server(req->GetVirtual(), delta_day, node);
                Server* new_svr = new Server(select_svr);
                do_match(new_svr, req->GetVirtual(), day, node);
                m_assigned_vir_pool.push_back(req->GetVirtual());
                m_buyed_svr_pool.push_back(new_svr);
                tmp[new_svr->GetName()].push_back(new_svr);
            } else {
                auto vir = req->GetVirtual();
                vir->del_server();
                --m_VirtualPoolSize;
            }
        }

        cout << "(purchase, " << tmp.size() << ")\n";
        for (auto& it : tmp) {
            for (auto& svr : it.second) {
                svr->SetID(global_index++);
            }
            cout << "(" << it.first << ", " << it.second.size() << ")\n";
        }

        for (auto& it : migration_result) cout << it << "\n";

        for (auto& req : m_requests[day]) {
            if (req->GetType() == REQ_TYPE::DEL) continue;
            const auto& vir = req->GetVirtual();
            if (vir->GetNodeCount() == 2) {
                cout << "(" << vir->GetServer()->GetID() << ")\n";
            } else {
                cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
            }
        }
    }
}