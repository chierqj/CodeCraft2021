#include "greedy.h"
#include "scenario/log.h"
#include "scenario/tools.h"

int Greedy::get_daily_cost_price() {
    int ans = 0;
    for (auto& svr : m_buyed_svr_pool) {
        if (svr->GetVirList().empty()) continue;
        int cv = svr->GetHardwareCost();
        int ev = svr->GetEnergyCost();
        int days = svr->get_deltime() - m_today_idx;

        int cost = ev * days;
        if (svr->GetBuyTime() == m_today_idx) cost += cv;
        ans += cost;
    }
    return ans;
}

void Greedy::offer_price(const vector<Request*>& input_requests) {
    this->save_state(m_today_idx);
    m_requests.insert(m_requests.end(), input_requests.begin(), input_requests.end());
    this->solve();

    unordered_map<Server*, int> svr_cost_map;
    for (auto& svr : m_buyed_svr_pool) {
        if (svr->GetVirList().empty()) continue;
        int cv = svr->GetHardwareCost();
        int ev = svr->GetEnergyCost();
        int days = svr->get_deltime() - m_today_idx + 1;
        int cost = ev * days;
        if (svr->GetBuyTime() == m_today_idx) cost += cv;
        int proto_cpu = svr->GetProtoCpu(), proto_ram = svr->GetProtoRam();
        svr_cost_map[svr] = cost / (2 * proto_cpu + proto_ram);
    }

    m_requests.clear();

    vector<Request*> add_req;
    unordered_set<Request*> m_give_up_set;
    int need_count = 0, suc_count = 0;
    for (auto& req : input_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        add_req.push_back(req);

        auto vir = req->GetVirtual();
        int cpu = vir->GetCpu(), ram = vir->GetRam();
        int user_price = vir->GetUserPrice();
        int vm_cost = user_price / (2 * cpu + ram);
        int svr_cost = svr_cost_map[vir->GetServer()];

        int offer_price = 0;
        if (vm_cost < svr_cost) {
            offer_price = -1;
        } else {
            offer_price = ((vm_cost * 0.8 + svr_cost) / 2) * (2 * cpu + ram);
        }

        if (offer_price <= 0 || offer_price > user_price) offer_price = -1;
        if (offer_price == -1) m_give_up_set.insert(req);

        printf("%d\n", offer_price);

        if (offer_price != -1) need_count++;

        // log_info("--- svr_cost: %d, vm_offer_price: %d", svr_cost, offer_price);
        // vir->debug();
        // vir->GetServer()->debug();
    }

    this->recover_state(m_today_idx);

    for (auto& req : add_req) {
        int suc, enemy_price;
        m_getline("(%d, %d)", &suc, &enemy_price);
        m_enemy_offer_price += enemy_price;
        m_tol_user_price += req->GetVirtual()->GetUserPrice();
        if (suc == 1 && m_give_up_set.find(req) == m_give_up_set.end()) {
            m_global_obtain_vm_pool.insert(req->GetVirtual()->GetID());
            suc_count++;
        }
    }

    for (auto& req : input_requests) {
        if (m_global_obtain_vm_pool.find(req->GetVirtual()->GetID()) == m_global_obtain_vm_pool.end()) {
            continue;
        }
        m_requests.push_back(req);
    }
    log_info("need_count: %d, suc_count: %d", need_count, suc_count);
}
