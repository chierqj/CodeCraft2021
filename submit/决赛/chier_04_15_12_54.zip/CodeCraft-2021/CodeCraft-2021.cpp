#include <algorithm>
#include <cstring>
#include <ctime>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "scenario/log.h"
#include "simulation/simulation.h"

using namespace std;

int main(int argc, char **argv) {
#ifdef LOCAL_DEBUG
    FILE *fp = fopen("../../data/Finall/CodeCraft2021.log", "w");
    log_set_fp(fp);
#endif

    Simulation *sim = new Simulation();
    sim->RunFrameWork();

    return 0;
}