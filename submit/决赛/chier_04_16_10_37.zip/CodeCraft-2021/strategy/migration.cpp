#include <algorithm>
#include <cassert>
#include <climits>
#include <cmath>
#include <map>
#include <set>

#include "greedy.h"

double Greedy::get_used_rate(Server* svr, Virtual* vir, int node) {
    int vir_cpu = vir->GetCpu(), vir_mem = vir->GetRam();

    double inv_cpu = svr->GetInvCPU(), inv_mem = svr->GetInvMem();
    int cpu_a = svr->GetCpuA(), mem_a = svr->GetRamA();
    int cpu_b = svr->GetCpuB(), mem_b = svr->GetRamB();

    double cpu = (node == -1 ? (cpu_a + cpu_b) : node == 0 ? cpu_a : cpu_b) - vir_cpu;
    double mem = (node == -1 ? (mem_a + mem_b) : node == 0 ? mem_a : mem_b) - vir_mem;
    double x = cpu * inv_cpu, y = mem * inv_mem;
    return (x * x + y * y) * sqrt(svr->GetEnergyCost());
}

void Greedy::do_migration_1(vector<Server*>& tol_svr_list) {
    if (m_migra_count <= 0) return;

    map<int, unordered_set<Server*>> hash_svr_list;
    auto action_move = [&](Virtual* vir, Server* svr_to, int node) {
        hash_svr_list[vir->GetServer()->GetWeightedRest()].erase(vir->GetServer());
        if (hash_svr_list[vir->GetServer()->GetWeightedRest()].empty()) {
            hash_svr_list.erase(vir->GetServer()->GetWeightedRest());
        }
        hash_svr_list[svr_to->GetWeightedRest()].erase(svr_to);
        if (hash_svr_list[svr_to->GetWeightedRest()].empty()) {
            hash_svr_list.erase(svr_to->GetWeightedRest());
        }

        vir->del_server();
        svr_to->add_virtual(vir, node, m_today_idx);
        vir->add_server(svr_to, node);

        hash_svr_list[svr_to->GetWeightedRest()].insert(svr_to);
    };

    for (auto& svr : tol_svr_list) {
        if (svr->GetVirList().empty()) continue;
        hash_svr_list[svr->GetWeightedRest()].insert(svr);
    }

    vector<Virtual*> vir_list;
    int max_migra_count = 3 * m_migra_count;
    tol_svr_list.clear();
    for (auto it = hash_svr_list.rbegin(); it != hash_svr_list.rend(); it++) {
        for (auto svr : it->second) {
            tol_svr_list.push_back(svr);
            vir_list.insert(vir_list.end(), svr->GetVirList().begin(), svr->GetVirList().end());
        }
        if ((int)vir_list.size() >= max_migra_count) break;
    }

    stable_sort(vir_list.begin(), vir_list.end(), [&](const Virtual* vir1, const Virtual* vir2) {
        return vir1->GetWeightedRest() > vir2->GetWeightedRest();
    });

    unordered_set<Server*> vis_svr_from_set;  // svr_from只迁移一台出去
    unordered_set<Server*> vis_svr_to_set;    // svr_to别往出迁移

    for (auto& vir : vir_list) {
        if (m_migra_count <= 0) return;
        // if (vis_svr_from_set.find(vir->GetServer()) != vis_svr_from_set.end()) continue;
        if (vis_svr_to_set.find(vir->GetServer()) != vis_svr_to_set.end()) continue;

        Server* select_svr = nullptr;
        double select_value = vir->GetScore();
        int select_node = -1;
        int select_env = 0;

        auto iter = hash_svr_list.lower_bound(vir->GetWeightedRest());
        for (; iter != hash_svr_list.end(); ++iter) {
            const auto& svr_to_list = iter->second;
            for (auto svr_to : svr_to_list) {
                if (svr_to == vir->GetServer()) continue;
                if (svr_to->GetVirList().empty()) continue;

                vector<int> suc_node;
                if (vir->DoubleDeploy() && this->match_double_node(svr_to, vir)) suc_node = {-1};
                if (!vir->DoubleDeploy() && this->match_node_a(svr_to, vir)) suc_node.push_back(0);
                if (!vir->DoubleDeploy() && this->match_node_b(svr_to, vir)) suc_node.push_back(1);
                for (auto& node : suc_node) {
                    double val = this->get_used_rate(svr_to, vir, node);
                    if (select_svr == nullptr || val < select_value ||
                        (val == select_value && svr_to->GetEnergyCost() < select_env)) {
                        select_svr = svr_to;
                        select_value = val;
                        select_node = node;
                        select_env = svr_to->GetEnergyCost();
                    }
                }
            }
        }
        if (select_svr != nullptr) {
            vis_svr_from_set.insert(vir->GetServer());
            vis_svr_to_set.insert(select_svr);
            action_move(vir, select_svr, select_node);
            migration_result.push_back({vir->GetID(), select_svr, select_node});
            --m_migra_count;
        }
    }
}

void Greedy::do_migration() {
    migration_result.clear();
    if (m_migra_count <= 0) return;

    vector<Server*> svr_pool;
    for (auto& svr : m_buyed_svr_pool) {
        if (svr->GetVirList().empty()) continue;
        svr_pool.push_back(svr);
    }

    while (true) {
        int count = m_migra_count;
        this->do_migration_1(svr_pool);
        if (count == m_migra_count || m_migra_count <= 0) return;
    }
}
