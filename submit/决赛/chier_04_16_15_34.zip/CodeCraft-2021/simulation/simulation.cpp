#include "simulation.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "strategy/greedy.h"
#include "tools.h"
using namespace std;

void Simulation::read_data() {
    int svr_n = 0;
    m_getline("%d", &svr_n);
    for (int i = 0; i < svr_n; ++i) {
        char c_name[32];
        int cpu, ram, hardware_cost, energy_cost;
        m_getline("(%[^,], %d, %d, %d, %d)", c_name, &cpu, &ram, &hardware_cost, &energy_cost);
        Server *svr = new Server(string(c_name), cpu, ram, hardware_cost, energy_cost, i);
        m_servers.push_back(svr);
    }
    int vm_n = 0;
    unordered_map<string, Virtual *> hash_virtual;
    m_getline("%d\n", &vm_n);
    for (int i = 0; i < vm_n; ++i) {
        char c_name[32];
        int cpu, ram, double_deploy;
        m_getline("(%[^,], %d, %d, %d)", c_name, &cpu, &ram, &double_deploy);
        Virtual *vir = new Virtual(string(c_name), cpu, ram, double_deploy, i);
        m_virtuals.push_back(vir);
        hash_virtual[vir->GetName()] = vir;
    }
    int t, k;
    m_getline("%d %d\n", &t, &k);

    unordered_map<int, Virtual *> vir_pool;
    auto input_daily_req = [&](int day) {
        int req_n = 0;
        m_getline("%d", &req_n);
        vector<Request *> vct_req;
        for (int i = 0; i < req_n; ++i) {
            string line;
            getline(cin, line);
            int id;
            if (sscanf(line.c_str(), "(del, %d)", &id)) {
                Virtual *vir = vir_pool[id];
                Request *req = new Request(REQ_TYPE::DEL, vir);
                vct_req.push_back(req);
            } else {
                char c_name[32];
                int duration_time, user_price;
                sscanf(line.c_str(), "(add, %[^,], %d, %d, %d)", c_name, &id, &duration_time, &user_price);
                Virtual *vir = new Virtual(hash_virtual[string(c_name)]);
                vir->SetID(id);
                vir->SetCreateTime(day);
                vir->SetDurationTime(duration_time);
                vir->SetUserPrice(user_price);
                vir_pool[id] = vir;
                Request *req = new Request(REQ_TYPE::ADD, vir);
                vct_req.push_back(req);
            }
        }
        m_requests.push_back(vct_req);
    };

    for (int i = 0; i < k; ++i) input_daily_req(i);

    Greedy *grd = new Greedy(m_servers, m_virtuals, t);

    for (int i = 0; i < t; ++i) {
        grd->Execute(m_requests[i], i, 1, 1);
        if (i < t - k) input_daily_req(i + k);
    }

    grd->debug();
    delete grd;
}

void Simulation::RunFrameWork() { this->read_data(); }