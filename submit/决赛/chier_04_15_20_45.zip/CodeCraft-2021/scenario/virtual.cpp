#include "virtual.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

void Virtual::debug() {
    log_debug(
        "vm: %s, id: %d, cpu: %d, ram: %d, double_deploy: %d, m_node: %d, create_t: %d, duration_t: %d, user_price: "
        "%d, weight: %d, unit_price: %d",
        m_name.c_str(), m_id, m_cpu, m_ram, m_double_deploy, m_node, m_create_time, m_duration_time, m_user_price,
        GetWeightedRest(), m_unit_price);
}

void Virtual::del_server() {
    if (m_svr == nullptr) return;
    m_svr->del_virtual(this, m_node);
}

void Virtual::add_server(Server *svr, int node) {
    m_svr = svr;
    m_node = node;
}

double Virtual::GetScore() {
    if (m_svr == nullptr) return 0;
    int cpu_a = m_svr->GetCpuA(), mem_a = m_svr->GetRamA();
    int cpu_b = m_svr->GetCpuB(), mem_b = m_svr->GetRamB();

    double inv_cpu = m_svr->GetInvCPU(), inv_mem = m_svr->GetInvMem();
    double cpu = (m_node == -1 ? (cpu_a + cpu_b) : m_node == 0 ? cpu_a : cpu_b);
    double mem = (m_node == -1 ? (mem_a + mem_b) : m_node == 0 ? mem_a : mem_b);
    double x = cpu * inv_cpu, y = mem * inv_mem;
    return (x * x + y * y) * sqrt(m_svr->GetEnergyCost());
}