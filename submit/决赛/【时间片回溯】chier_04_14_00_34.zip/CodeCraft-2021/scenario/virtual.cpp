#include "virtual.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

void Virtual::debug() {
    cout << "vm: (" << m_name << ", ";
    cout << "id: " << m_id << ", ";
    cout << "type_id: " << m_type_id << ", ";
    cout << "cpu: " << m_cpu << ", ";
    cout << "ram: " << m_ram << ", ";
    cout << "double_deploy: " << m_double_deploy << ", ";
    cout << "create_time: " << m_create_time << ", ";
    cout << "duration_time: " << m_duration_time << ", ";
    cout << "destory_time: " << m_destory_time << ", ";
    cout << "user_price: " << m_user_price << ", ";
    cout << "m_node: " << m_node << ", ";
    cout << "weighted: " << this->GetWeightedRest() << ", ";
    cout << "score: " << this->GetScore() << ")\n";
}

void Virtual::del_server() {
    if (m_svr == nullptr) return;
    m_svr->del_virtual(this, m_node);
}

void Virtual::add_server(Server *svr, int node) {
    m_svr = svr;
    m_node = node;
}

double Virtual::GetScore() {
    if (m_svr == nullptr) return 0;
    int cpu_a = m_svr->GetCpuA(), mem_a = m_svr->GetRamA();
    int cpu_b = m_svr->GetCpuB(), mem_b = m_svr->GetRamB();

    double inv_cpu = m_svr->GetInvCPU(), inv_mem = m_svr->GetInvMem();
    double cpu = (m_node == -1 ? (cpu_a + cpu_b) : m_node == 0 ? cpu_a : cpu_b);
    double mem = (m_node == -1 ? (mem_a + mem_b) : m_node == 0 ? mem_a : mem_b);
    double x = cpu * inv_cpu, y = mem * inv_mem;
    return (x * x + y * y) * sqrt(m_svr->GetEnergyCost());
}