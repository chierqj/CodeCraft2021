#ifndef SCENARIO_REQUEST_H
#define SCENARIO_REQUEST_H

#include <algorithm>
#include <cstring>
#include <iostream>
#include <vector>

#include "virtual.h"
using namespace std;

enum REQ_TYPE { ADD, DEL };

class Request {
   public:
    Request(enum REQ_TYPE type, Virtual *vir) : m_type(type), m_vir(vir) {}

   public:
    inline const REQ_TYPE &GetType() const { return m_type; }
    inline Virtual *GetVirtual() { return m_vir; }
    inline const Virtual *GetVirtual() const { return m_vir; }

   private:
    REQ_TYPE m_type;  // 请求类型
    Virtual *m_vir;   // 请求绑定的虚拟机实例，每次都new; Add和del是同一个指针
};

#endif