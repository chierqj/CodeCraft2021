#include "greedy.h"
#include "scenario/log.h"
#include "scenario/tools.h"

void Greedy::pre_solve() {
    vector<vector<Request*>> new_req_list;
    this->get_new_req_list(new_req_list);

    for (auto& block : new_req_list) {
        if (block.front()->GetType() == REQ_TYPE::DEL) {
            for (auto& req : block) {
                req->GetVirtual()->del_server();
            }
            continue;
        }
        for (auto& req : block) {
            Server* select_svr;
            int node = -1;
            select_svr = get_old_server(req->GetVirtual(), node);
            if (select_svr != nullptr) {
                do_match(select_svr, req->GetVirtual(), node);
                continue;
            }

            select_svr = get_new_server(req->GetVirtual(), node);
            Server* new_svr = new Server(select_svr);
            this->do_match(new_svr, req->GetVirtual(), node);
            new_svr->SetBuyTime(m_today_idx);
            m_buyed_svr_pool.push_back(new_svr);
        }
    }
}

void Greedy::offer_price(const vector<Request*>& input_requests) {
    int avg_svr_cost = 0, count = 0;
    for (auto& svr : m_buyed_svr_pool) {
        int cv = svr->GetHardwareCost();
        int ev = svr->GetEnergyCost();
        int days = svr->get_update_deltime() - svr->GetBuyTime() + 1;
        int cost = cv + ev * days - svr->GetEarnPrice();
        int proto_cpu = svr->GetProtoCpu(), proto_ram = svr->GetProtoRam();
        avg_svr_cost += cost / (proto_cpu * 2 + proto_ram);
        ++count;
    }
    avg_svr_cost = count == 0 ? avg_svr_cost : avg_svr_cost / count;

    m_requests.clear();
    vector<Request*> add_req;
    unordered_set<Request*> m_give_up_set;
    unordered_map<Request*, int> vm_offer_price_map;

    for (auto& req : input_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        add_req.push_back(req);

        auto vir = req->GetVirtual();
        int cpu = vir->GetCpu(), ram = vir->GetRam();
        int user_price = vir->GetUserPrice();
        int vm_cost = user_price / (cpu * 2 + ram);

        int offer_price = 0;

        if (vm_cost < avg_svr_cost) {
            offer_price = -1;
        } else {
            offer_price = user_price * (m_enemy_yesterday_discount - 0.01);
        }

        if (offer_price <= 0 || offer_price > user_price) {
            offer_price = -1;
            m_give_up_set.insert(req);
        }

        vm_offer_price_map[req] = offer_price;
        printf("%d\n", offer_price);
    }

    // this->recover_state(m_today_idx);

    double avr_dis_count = 0, suc_count = 0;
    for (auto& req : add_req) {
        int suc, enemy_price;
        m_getline("(%d, %d)", &suc, &enemy_price);

        auto vir = req->GetVirtual();

        if (suc == 1 && m_give_up_set.find(req) == m_give_up_set.end()) {
            m_global_obtain_vm_pool.insert(vir->GetID());
            vir->SetOfferPrice(vm_offer_price_map[req]);

            int unit_price = vir->GetOfferPrice() / vir->GetDurationTime();
            m_pre_earn_daily[m_today_idx] += unit_price;
            m_pre_earn_daily[vir->GetDestoryTime()] -= unit_price;
            if (vir->GetID() == 1003922874) {
                vir->debug();
                log_debug("unit_price: %d, earn[%d]: %d, del[%d]: %d", unit_price, m_today_idx,
                          m_pre_earn_daily[m_today_idx], vir->GetDestoryTime(),
                          m_pre_earn_daily[vir->GetDestoryTime()]);
            }
        }

        if (enemy_price != -1) {
            double discount = (double)enemy_price / (double)req->GetVirtual()->GetUserPrice();
            avr_dis_count += discount;
            ++suc_count;
        }
    }

    m_enemy_yesterday_discount = avr_dis_count / suc_count;

    for (auto& req : input_requests) {
        auto vir = req->GetVirtual();
        if (m_global_obtain_vm_pool.find(vir->GetID()) == m_global_obtain_vm_pool.end()) {
            continue;
        }
        m_requests.push_back(req);
    }
}
