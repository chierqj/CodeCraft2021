#ifndef SCENARIO_SERVER_H
#define SCENARIO_SERVER_H

#include <algorithm>
#include <array>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "virtual.h"
using namespace std;

class Virtual;

class Server {
   public:
    Server() {}
    Server(string name, int cpu, int ram, int hardware_cost, int energy_cost, int type_id) {
        m_name = name;
        m_cpu_a = m_cpu_b = cpu >> 1;
        m_ram_a = m_ram_b = ram >> 1;
        m_proto_cpu = cpu;
        m_proto_ram = ram;
        m_hardware_cost = hardware_cost;
        m_energy_cost = energy_cost;
        m_type_id = type_id;
        m_inv_cpu = 1.0 / (double)m_proto_cpu;
        m_inv_ram = 1.0 / (double)m_proto_ram;
    }
    Server(const Server *svr) {
        m_id = svr->m_id;
        m_name = svr->m_name;
        m_cpu_a = svr->m_cpu_a;
        m_ram_a = svr->m_ram_a;
        m_cpu_b = svr->m_cpu_b;
        m_ram_b = svr->m_ram_b;
        m_proto_cpu = svr->m_proto_cpu;
        m_proto_ram = svr->m_proto_ram;
        m_hardware_cost = svr->m_hardware_cost;
        m_energy_cost = svr->m_energy_cost;
        m_type_id = svr->m_type_id;
        m_inv_cpu = svr->m_inv_cpu;
        m_inv_ram = svr->m_inv_ram;
        m_vir_list = svr->m_vir_list;
    }

    Server *save_state() {
        Server *svr = new Server();
        svr->m_cpu_a = m_cpu_a;
        svr->m_cpu_b = m_cpu_b;
        svr->m_ram_a = m_ram_a;
        svr->m_ram_b = m_ram_b;
        svr->m_vir_list = m_vir_list;
        return svr;
    }
    void recover_state(const Server *svr) {
        m_cpu_a = svr->m_cpu_a;
        m_cpu_b = svr->m_cpu_b;
        m_ram_a = svr->m_ram_a;
        m_ram_b = svr->m_ram_b;
        m_vir_list = svr->m_vir_list;
        delete svr;
    }

    void debug() const;
    void add_virtual(Virtual *vir, int node, int day_idx);
    void del_virtual(Virtual *vir, int node);
    int get_update_deltime();

   public:
    inline const string &GetName() const { return m_name; }
    inline const int &GetCpuA() const { return m_cpu_a; }
    inline const int &GetCpuB() const { return m_cpu_b; }
    inline const int &GetRamA() const { return m_ram_a; }
    inline const int &GetRamB() const { return m_ram_b; }
    inline const int &GetProtoCpu() const { return m_proto_cpu; }
    inline const int &GetProtoRam() const { return m_proto_ram; }
    inline const int &GetHardwareCost() const { return m_hardware_cost; }
    inline const int &GetEnergyCost() const { return m_energy_cost; }
    inline const int &GetID() const { return m_id; }
    inline const unordered_set<Virtual *> &GetVirList() const { return m_vir_list; }
    inline const int GetRest() const { return m_cpu_a + m_cpu_b + m_ram_a + m_ram_b; }
    inline const int GetRestA() const { return m_cpu_a + m_ram_a; }
    inline const int GetRestB() const { return m_cpu_b + m_ram_b; }
    inline const int GetWeightedRest() const {
        int cpu = m_cpu_a + m_cpu_b;
        int ram = m_ram_a + m_ram_b;
        return cpu * 2 + ram;
    }
    inline const int GetWeightedRestA() const {
        int cpu = m_cpu_a, ram = m_ram_a;
        return cpu * 2 + ram;
    }
    inline const int GetWeightedRestB() const {
        int cpu = m_cpu_b, ram = m_ram_b;
        return cpu * 2 + ram;
    }
    inline const int GetTypeID() const { return m_type_id; }
    inline const double &GetInvCPU() const { return m_inv_cpu; }
    inline const double &GetInvMem() const { return m_inv_ram; }
    inline const int &GetBuyTime() const { return m_buy_time; }
    inline const int &GetEarnPrice() const { return m_earn_price; }
    inline const int &GetDelTime() const { return m_deltime; }

    inline void SetID(int id) { m_id = id; }
    inline void SetTypeID(int id) { m_type_id = id; }
    inline void SetBuyTime(int t) { m_buy_time = t; }
    inline void SetEarnPrice(int price) { m_earn_price = price; }

   private:
    int m_id = -1;                 // id
    int m_type_id;                 // 类型id
    string m_name;                 // 类型名
    int m_hardware_cost;           // 硬件成本
    int m_energy_cost;             // 能耗成本
    int m_cpu_a, m_ram_a;          // A 实时
    int m_cpu_b, m_ram_b;          // B 实时
    int m_proto_cpu, m_proto_ram;  // 读入
    int m_buy_time;
    int m_deltime = 0;

    unordered_set<Virtual *> m_vir_list;  // 当前server部署的虚拟机数量
    double m_inv_cpu, m_inv_ram;          // cpu, ram倒数
    int m_earn_price = 0;                 // 已经赚到的钱
};

#endif