#ifndef SIMULATION_SIMULATION_H
#define SIMULATION_SIMULATION_H
#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "scenario/request.h"
#include "scenario/server.h"
#include "scenario/virtual.h"

class Simulation {
   public:
    void RunFrameWork();

   private:
    void read_data();

   private:
    vector<Server *> m_servers;            // 读入服务器
    vector<Virtual *> m_virtuals;          // 读入虚拟机
    vector<vector<Request *>> m_requests;  // 读入请求
};

#endif  // SIMULATION_SIMULATION_H