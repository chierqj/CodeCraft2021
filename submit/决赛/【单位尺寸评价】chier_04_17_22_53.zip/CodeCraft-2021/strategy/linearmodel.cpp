#include "linearmodel.h"

void LinearModel::Train() {
    if (m_servers.size() == 80) {
        m_hv_a = 213.76807617;
        m_hv_b = 92.13639539;
        m_hv_c = 0;
        m_ev_a = 0.68287962;
        m_ev_b = 0.31061102;
        m_ev_c = 0;
    } else {
        m_hv_a = 208.76839036;
        m_hv_b = 97.34851414;
        m_hv_c = 0;
        m_ev_a = 0.55323421;
        m_ev_b = 0.24493506;
        m_ev_c = 0;
    }
}

pair<double, double> LinearModel::Predict(int cpu, int ram) {
    double hv = m_hv_a * (double)cpu + m_hv_b * (double)ram + m_hv_c;
    double ev = m_ev_a * (double)cpu + m_ev_b * (double)ram + m_ev_c;
    return {hv, ev};
}