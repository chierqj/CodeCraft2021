#ifndef STRATEGY_LINEAR_MODEL_H
#define STRATEGY_LINEAR_MODEL_H

#include <vector>

#include "scenario/server.h"
using namespace std;

class LinearModel {
   public:
    LinearModel(const vector<Server *> &servers) : m_servers(servers) {}

    void Train();
    pair<double, double> Predict(int cpu, int ram);

   private:
    const vector<Server *> &m_servers;

    const int EPOCH = 100;
    double m_hv_a = 1.06884038;
    double m_hv_b = 0.46068198;
    double m_hv_c = 0;

    double m_ev_a = 0.68287962;
    double m_ev_b = 0.31061102;
    double m_ev_c = 0;
};

#endif