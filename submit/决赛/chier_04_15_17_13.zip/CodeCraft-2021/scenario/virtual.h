#ifndef SCENARIO_VIRTUAL_H
#define SCENARIO_VIRTUAL_H

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "log.h"
#include "server.h"
using namespace std;
class Server;

class Virtual {
   public:
    Virtual() {}
    Virtual(string name, int cpu, int ram, int double_deploy, int type_id) {
        m_type_id = type_id;
        m_name = name;
        m_cpu = cpu;
        m_ram = ram;
        m_double_deploy = double_deploy;
        m_delta_cpu_ratio = (double)(m_cpu - m_ram) / (double)m_cpu;
        m_delta_ram_ratio = (double)(m_ram - m_cpu) / (double)m_ram;
        m_weighted_resource = m_cpu * 2 + m_ram;
    }

    Virtual(const Virtual *vir) {
        m_id = vir->m_id;
        m_type_id = vir->m_type_id;
        m_name = vir->m_name;
        m_cpu = vir->m_cpu;
        m_ram = vir->m_ram;
        m_double_deploy = vir->m_double_deploy;
        m_delta_cpu_ratio = vir->m_delta_cpu_ratio;
        m_delta_ram_ratio = vir->m_delta_ram_ratio;
        m_weighted_resource = vir->m_weighted_resource;
    }

    Virtual *save_state() {
        Virtual *vir = new Virtual();
        vir->m_node = m_node;
        vir->m_svr = m_svr;
        return vir;
    }
    void recover_state(const Virtual *vir) {
        m_node = vir->m_node;
        m_svr = vir->m_svr;
        delete vir;
    }

    void debug();
    void add_server(Server *svr, int node);
    void del_server();
    double GetScore();

   public:
    inline const int &GetID() const { return m_id; }
    inline const int GetTypeID() const { return m_type_id; }
    inline const string &GetName() const { return m_name; }
    inline const int &GetCpu() const { return m_cpu; }
    inline const int &GetRam() const { return m_ram; }
    inline const bool &DoubleDeploy() const { return m_double_deploy; }
    inline const int &GetNode() const { return m_node; }
    inline const int &GetCreateTime() const { return m_create_time; }
    inline const int &GetDurationTime() const { return m_duration_time; }
    inline Server *GetServer() const { return m_svr; }
    inline const double GetDeltaCpuRatio() const { return m_delta_cpu_ratio; }
    inline const double GetDeltaRamRatio() const { return m_delta_ram_ratio; }
    inline const int GetRest() const { return m_cpu + m_ram; }
    inline const int GetWeightedRest() const { return m_weighted_resource; }
    inline const int GetUserPrice() const { return m_user_price; }
    inline const int GetDestoryTime() const { return m_destory_time; }
    inline const int GetUnitPrice() const { return m_unit_price; }

    inline void SetID(int id) { m_id = id; }
    inline void SetCreateTime(int t) { m_create_time = t; }
    inline void SetNode(int node) { m_node = node; }
    inline void SetServer(Server *server) { m_svr = server; }
    inline void SetDurationTime(int duration_time) {
        m_duration_time = duration_time;
        m_destory_time = m_create_time + m_duration_time;
    }
    inline void SetUserPrice(int price) {
        m_user_price = price;
        m_unit_price = m_user_price / m_weighted_resource;
    }

   private:
    int m_id = -1;                 // 虚拟机id
    int m_type_id;                 // 类型id
    string m_name;                 // 类型名称
    int m_cpu;                     // cpu
    int m_ram;                     // memory
    bool m_double_deploy;          // 是否双点部署(false:单; true：双)
    int m_node = -1;               // 在服务器的哪个结点(0: A, 1: B, -1:双)
    int m_create_time;             // 创建时间
    int m_duration_time;           // 持续时间
    int m_destory_time;            // 销毁时间
    int m_user_price;              // 用户报价
    Server *m_svr = nullptr;       // 当前在哪台服务器上
    double m_delta_cpu_ratio = 0;  // cpu-mem/cpu
    double m_delta_ram_ratio = 0;  // mem-cpu/mem
    int m_weighted_resource = 0;   // size
    int m_unit_price = 0;          // 单位空间成本
};

#endif