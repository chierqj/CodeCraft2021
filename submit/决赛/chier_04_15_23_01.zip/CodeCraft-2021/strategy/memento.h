#ifndef STRATEGY_MEMENTO_H
#define STRATEGY_MEMENTO_H

#include <iostream>
#include <unordered_map>
#include <unordered_set>

#include "greedy.h"
#include "scenario/server.h"
#include "scenario/virtual.h"
using namespace std;

class Memento {
    friend class Greedy;

   public:
    Memento() {}

   private:
    unordered_map<Server *, Server *> m_svr_pool;
    unordered_map<Virtual *, Virtual *> m_vir_pool;
    int m_VirtualPoolSize = 0;                   // 当前已经虚拟机的总数
    int m_global_svr_id = 0;                     // 服务器全局id
    vector<Server *> m_buyed_svr_pool;           // 已经购买的svr
    unordered_set<int> m_global_obtain_vm_pool;  // 获取到的所有虚拟机的id集合
};

class CareTaker {
   public:
    void AddMemento(int key, Memento *memento) { m_memento_pool[key] = memento; }
    Memento *GetMemento(int key) { return m_memento_pool[key]; }

   private:
    unordered_map<int, Memento *> m_memento_pool;
};

#endif