#include <climits>
#include <cmath>

#include "greedy.h"
#include "scenario/log.h"
#include "scenario/tools.h"

void Greedy::pre_solve(const vector<Request*>& input_requests) {
    auto self_get_old_server = [&](Virtual* vir, int& local_node) {
        struct Node {
            double val;
            int node;
            Server* svr;
            bool operator<(const Node& r) const { return val < r.val; }
        };
        vector<Node> vct;
        double vm_cpu_ratio = vir->GetDeltaCpuRatio();
        double vm_mem_ratio = vir->GetDeltaRamRatio();
        for (const auto& svr : m_buyed_svr_pool) {
            double cpu_a = svr->GetCpuA(), mem_a = svr->GetRamA();
            double cpu_b = svr->GetCpuB(), mem_b = svr->GetRamB();
            double svr_ratio_cpu_a = (cpu_a - mem_a) / cpu_a, svr_ratio_mem_a = (mem_a - cpu_a) / mem_a;
            double svr_ratio_cpu_b = (cpu_b - mem_b) / cpu_b, svr_ratio_mem_b = (mem_b - cpu_b) / mem_b;
            if (vir->DoubleDeploy()) {
                if (match_double_node(svr, vir)) {
                    double val = fabs(svr_ratio_cpu_a - vm_cpu_ratio) + fabs(svr_ratio_mem_a - vm_mem_ratio) +
                                 fabs(svr_ratio_cpu_b - vm_cpu_ratio) + fabs(svr_ratio_mem_b - vm_mem_ratio);
                    vct.push_back(Node{val, -1, svr});
                }
                continue;
            }
            if (match_node_a(svr, vir)) {
                double val = fabs(svr_ratio_cpu_a - vm_cpu_ratio) + fabs(svr_ratio_mem_a - vm_mem_ratio);
                vct.push_back(Node{val, 0, svr});
            }
            if (match_node_b(svr, vir)) {
                double val = fabs(svr_ratio_cpu_b - vm_cpu_ratio) + fabs(svr_ratio_mem_b - vm_mem_ratio);
                vct.push_back(Node{val, 1, svr});
            }
        }
        stable_sort(vct.begin(), vct.end());
        int r = vct.size() * 0.4;
        Server* select_svr = nullptr;
        double select_value = 0;
        int select_env = 0;
        for (int i = 0; i < r; ++i) {
            const auto& svr = vct[i].svr;
            double val = this->get_used_rate(svr, vir, vct[i].node);
            if (select_svr == nullptr || val < select_value ||
                (val == select_value && svr->GetEnergyCost() < select_env)) {
                select_svr = svr;
                select_value = val;
                local_node = vct[i].node;
                select_env = svr->GetEnergyCost();
            }
        }
        return select_svr;
    };

    for (auto& req : input_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        auto vir = req->GetVirtual();
        Server* select_svr;
        int node = -1;
        select_svr = self_get_old_server(vir, node);
        if (select_svr != nullptr) {
            do_match(select_svr, vir, node);
            continue;
        }
    }
}

void Greedy::offer_price(const vector<Request*>& input_requests) {
    vector<Request*> add_req;
    unordered_set<Request*> m_give_up_set;
    unordered_map<Request*, int> vm_offer_price_map;

    auto cal_offer_price = [&](Virtual* vir) {
        int cpu = vir->GetCpu(), ram = vir->GetRam();
        int days = vir->GetDurationTime(), user_price = vir->GetUserPrice();
        auto predict = m_model->Predict(cpu, ram);
        double hv = predict.first, ev = predict.second;
        double discount = (double)days / (double)max(days, (m_tol_day - m_today_idx));
        int offer_price = hv * discount + ev * days;
        if (offer_price <= 0) offer_price = -1;
        if (offer_price > user_price) offer_price = user_price * max(0.6, m_enemy_yesterday_avg_discount * 0.99);
        return offer_price;
    };

    for (auto& req : input_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        add_req.push_back(req);

        auto vir = req->GetVirtual();
        int offer_price = cal_offer_price(req->GetVirtual());
        if (offer_price <= 0 || offer_price > vir->GetUserPrice()) {
            offer_price = -1;
            m_give_up_set.insert(req);
        }

        vm_offer_price_map[req] = offer_price;
        vir->SetOfferPrice(offer_price);
        printf("%d\n", offer_price);
    }

    m_enemy_yesterday_avg_discount = 0;
    double enemy_suc_count = 0;

    for (auto& req : add_req) {
        int suc, enemy_price;
        m_getline("(%d, %d)", &suc, &enemy_price);

        auto vir = req->GetVirtual();
        if (suc == 1 && m_give_up_set.find(req) == m_give_up_set.end()) {
            m_global_obtain_vm_pool.insert(vir->GetID());
        }

        if (enemy_price != -1) {
            int user_price = vir->GetUserPrice();
            double discount = (double)enemy_price / (double)user_price;
            m_enemy_discount_list[vir->GetName()].push_back(discount);
            m_enemy_yesterday_avg_discount += discount;
            ++enemy_suc_count;
        }

        // {
        //     int cpu = vir->GetCpu(), ram = vir->GetRam();
        //     auto ans = m_model->Predict(cpu, ram);
        //     double hv = ans.first, ev = ans.second;
        //     int days = vir->GetDurationTime();
        //     int user_price = vir->GetUserPrice();

        //     double discount = (double)enemy_price / (double)user_price;
        //     log_debug(
        //         "[vm_id: %d, duration_t: %d, cpu: %d, ram: %d] [user_price: %d] [enemy_price: %d, m_price: %d] "
        //         "[predict_hv: %.3f, predict_ev: %.3f] discount: %.3f",
        //         vir->GetID(), days, vir->GetCpu(), vir->GetRam(), user_price, enemy_price, vm_offer_price_map[req],
        //         hv, ev, discount);
        // }
    }
    if (enemy_suc_count > 0) m_enemy_yesterday_avg_discount /= enemy_suc_count;

    for (auto& req : input_requests) {
        auto vir = req->GetVirtual();
        if (m_global_obtain_vm_pool.find(vir->GetID()) == m_global_obtain_vm_pool.end()) {
            continue;
        }
        m_requests.push_back(req);
    }
}
