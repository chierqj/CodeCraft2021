#include "server.h"

#include <algorithm>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;

void Server::debug() const {
    cout << "(服务器: " << m_name;
    cout << "id: " << m_id << ", ";
    cout << "hv: " << m_hardware_cost << ", ";
    cout << "ev: " << m_energy_cost << ", ";
    cout << "proto: [" << m_proto_cpu << ", " << m_proto_ram << "], ";
    cout << "A: [" << m_cpu_a << ", " << m_ram_a << "], ";
    cout << "B: [" << m_cpu_b << ", " << m_ram_b << "], ";
    cout << "rest: " << this->GetRest() << ", ";
    cout << "weight: " << this->GetWeightedRest() << ")\n";
    for (auto& it : m_vir_list) {
        cout << "* 绑定: ";
        it->debug();
    }
}

void Server::add_virtual(Virtual* vir, int node, int day_idx) {
    int vir_cpu = vir->GetCpu(), vir_ram = vir->GetRam();
    if (vir->DoubleDeploy()) {
        vir_cpu >>= 1;
        vir_ram >>= 1;
        m_cpu_a -= vir_cpu;
        m_ram_a -= vir_ram;
        m_cpu_b -= vir_cpu;
        m_ram_b -= vir_ram;
    } else {
        if (node == 0) {
            m_cpu_a -= vir_cpu;
            m_ram_a -= vir_ram;
        } else {
            m_cpu_b -= vir_cpu;
            m_ram_b -= vir_ram;
        }
    }
    m_vir_list.insert(vir);
}

void Server::del_virtual(Virtual* vir, int node) {
    int vir_cpu = vir->GetCpu(), vir_ram = vir->GetRam();
    if (vir->DoubleDeploy()) {
        vir_cpu >>= 1;
        vir_ram >>= 1;
        m_cpu_a += vir_cpu;
        m_ram_a += vir_ram;
        m_cpu_b += vir_cpu;
        m_ram_b += vir_ram;
    } else {
        if (node == 0) {
            m_cpu_a += vir_cpu;
            m_ram_a += vir_ram;
        } else {
            m_cpu_b += vir_cpu;
            m_ram_b += vir_ram;
        }
    }
    m_vir_list.erase(vir);
}

int Server::get_deltime() {
    int ans = 0;
    for (auto& it : m_vir_list) {
        ans = max(ans, it->GetDestoryTime());
    }
    return ans;
}