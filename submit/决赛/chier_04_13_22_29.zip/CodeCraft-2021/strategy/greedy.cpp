#include "greedy.h"

#include <unistd.h>

#include <cmath>
#include <cstdio>
#include <queue>

#include "scenario/tools.h"

void Greedy::get_new_req_list(vector<vector<Request*>>& new_req_list) {
    if (m_requests.empty()) return;

    int add_sum = 0, del_sum = 0;
    for (auto& req : m_requests) {
        if (req->GetType() == REQ_TYPE::ADD) {
            add_sum += req->GetVirtual()->GetRest();
        } else {
            del_sum += req->GetVirtual()->GetRest();
        }
    }

    vector<Request*> m_requests_copy(m_requests.begin(), m_requests.end());
    bool sign = (add_sum > del_sum);
    if (sign) {
        stable_sort(m_requests_copy.begin(), m_requests_copy.end(), [&](const Request* req1, const Request* req2) {
            if (req1->GetType() == req2->GetType()) {
                return req1->GetVirtual()->GetRest() > req2->GetVirtual()->GetRest();
            }
            return req1->GetType() < req2->GetType();
        });
    }

    vector<vector<Request*>> vct_block;
    vector<Request*> tmp;
    auto type = m_requests_copy.front()->GetType();
    for (auto& req : m_requests_copy) {
        if (req->GetType() == type) {
            tmp.push_back(req);
            continue;
        }
        vct_block.push_back(tmp);
        type = req->GetType();
        tmp.clear();
        tmp.push_back(req);
    }
    vct_block.push_back(tmp);

    for (auto& block : vct_block) {
        if (sign) {
            new_req_list.push_back(block);
            continue;
        }
        if (block.front()->GetType() == REQ_TYPE::ADD) {
            stable_sort(block.begin(), block.end(), [&](const Request* req1, const Request* req2) {
                return req1->GetVirtual()->GetRest() > req2->GetVirtual()->GetRest();
            });
        }
        new_req_list.push_back(block);
    }
}

void Greedy::solve() {
    m_migra_count = m_VirtualPoolSize * 3 / 100;
    this->do_migration();

    unordered_map<string, vector<Server*>> index;
    vector<vector<Request*>> new_req_list;
    this->get_new_req_list(new_req_list);

    for (auto& block : new_req_list) {
        if (block.front()->GetType() == REQ_TYPE::DEL) {
            m_VirtualPoolSize -= block.size();
            for (auto& req : block) {
                req->GetVirtual()->del_server();
            }
            continue;
        }
        m_VirtualPoolSize += block.size();

        for (auto& req : block) {
            Server* select_svr;
            int node = -1;
            select_svr = get_old_server(req->GetVirtual(), node);
            if (select_svr != nullptr) {
                do_match(select_svr, req->GetVirtual(), node);
                continue;
            }

            select_svr = get_new_server(req->GetVirtual(), node);
            Server* new_svr = new Server(select_svr);
            this->do_match(new_svr, req->GetVirtual(), node);
            m_buyed_svr_pool.push_back(new_svr);
            index[new_svr->GetName()].push_back(new_svr);
        }
    }

    this->output_daily(index);
}

void Greedy::output_daily(const unordered_map<string, vector<Server*>>& tmp) {
    printf("(purchase, %d)\n", (int)tmp.size());
    for (auto& it : tmp) {
        for (auto& svr : it.second) {
            svr->SetID(m_global_svr_id++);
        }
        printf("(%s, %d)\n", it.first.c_str(), (int)it.second.size());
    }
    printf("(migration, %d)\n", (int)migration_result.size());
    for (auto& it : migration_result) {
        int vir_id = std::get<0>(it);
        Server* svr_to = std::get<1>(it);
        int node = std::get<2>(it);
        if (node == -1) {
            printf("(%d, %d)\n", vir_id, svr_to->GetID());
        } else {
            char c = 'A' + node;
            printf("(%d, %d, %c)\n", vir_id, svr_to->GetID(), c);
        }
    }

    for (auto& req : m_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        const auto& vir = req->GetVirtual();
        if (vir->DoubleDeploy()) {
            printf("(%d)\n", vir->GetServer()->GetID());
        } else {
            char c = vir->GetNode() + 'A';
            printf("(%d, %c)\n", vir->GetServer()->GetID(), c);
        }
    }
    fflush(stdout);
}

void Greedy::offer_price(const vector<Request*>& input_requests) {
    vector<Request*> add_req;
    for (auto& req : input_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        add_req.push_back(req);
        int user_price = req->GetVirtual()->GetUserPrice();
        printf("%d\n", (int)(user_price * 0.777));
    }
    for (auto& req : add_req) {
#ifdef LOCAL_TEST
        m_global_obtain_vm_pool.insert(req->GetVirtual()->GetID());
#else
        int suc, enemy_price;
        m_getline("(%d, %d)", &suc, &enemy_price);
        if (suc == 1) m_global_obtain_vm_pool.insert(req->GetVirtual()->GetID());
#endif
    }
    for (auto& req : input_requests) {
        if (m_global_obtain_vm_pool.find(req->GetVirtual()->GetID()) == m_global_obtain_vm_pool.end()) {
            continue;
        }
        m_requests.push_back(req);
    }
}

void Greedy::Execute(const vector<Request*>& input_requests, int day, int future_k_vm_cpu, int future_k_vm_mem) {
    m_future_k_vm_cpu = future_k_vm_cpu;
    m_future_k_vm_mem = future_k_vm_mem;
    m_today_idx = day;
    m_requests.clear();
    this->offer_price(input_requests);
    this->solve();
}
/*
2
(NV603, 92, 324, 53800, 500)
(NV604, 128, 512, 87800, 800)
2
(c3.large.4, 2, 8, 0)
(c3.8xlarge.2, 32, 64, 1)
3 2
2
(add, c3.large.4, 5, 3, 800)
(add, c3.large.4, 0, 1, 300)
2
(del, 0)
(add, c3.8xlarge.2, 1, 1, 2000)
(0, 790)
(1, 300)
3
(add, c3.large.4, 2, 0, 100)
(del, 1)
(del, 2)
(1, 2000)
(1, 100)
*/