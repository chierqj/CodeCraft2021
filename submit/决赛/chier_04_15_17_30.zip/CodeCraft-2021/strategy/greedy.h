#ifndef STRATEGY_GREEDY_H
#define STRATEGY_GREEDY_H

#include <fstream>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "memento.h"
#include "scenario/log.h"
#include "scenario/request.h"
#include "scenario/server.h"
#include "scenario/virtual.h"

class Memento;

class Greedy {
    friend class Memento;

   public:
    Greedy(const vector<Server *> &svrs, const vector<Virtual *> &virs, const int &tol_day)
        : m_servers(svrs), m_virtuals(virs), m_tol_day(tol_day) {
        this->pretreat();
    }
    void Execute(const vector<Request *> &input_requests, int day, int future_k_vm_cpu, int future_k_vm_mem);

   private:
    void pretreat();
    void solve();
    void pre_solve();

    bool match_double_node(Server *svr, Virtual *vir);
    bool match_node_a(Server *svr, Virtual *vir);
    bool match_node_b(Server *svr, Virtual *vir);

    void offer_price(const vector<Request *> &input_requests);

    double get_used_rate(Server *svr, Virtual *vir, int local_node);
    void do_match(Server *svr, Virtual *vir, int local_node);
    void do_migration();
    void do_migration_1(vector<Server *> &tol_svr_list);
    Server *get_old_server(Virtual *vir, int &local_node);
    Server *get_new_server(Virtual *vir, int &local_node);
    void get_new_req_list(vector<vector<Request *>> &new_req_list);
    void output_daily();
    int get_daily_cost_price();

   private:
    void save_state(int key) {
        Memento *memeto = new Memento();
        for (auto &svr : m_buyed_svr_pool) {
            memeto->m_svr_pool[svr] = svr->save_state();
            for (auto &vir : svr->GetVirList()) {
                memeto->m_vir_pool[vir] = vir->save_state();
            }
        }
        memeto->m_VirtualPoolSize = m_VirtualPoolSize;
        memeto->m_global_svr_id = m_global_svr_id;
        memeto->m_buyed_svr_pool = m_buyed_svr_pool;
        memeto->m_global_obtain_vm_pool = m_global_obtain_vm_pool;
        m_care_taker->AddMemento(key, memeto);
    }
    void recover_state(int key) {
        Memento *memento = m_care_taker->GetMemento(key);

        m_VirtualPoolSize = memento->m_VirtualPoolSize;
        m_global_svr_id = memento->m_global_svr_id;
        m_buyed_svr_pool = memento->m_buyed_svr_pool;
        m_global_obtain_vm_pool = memento->m_global_obtain_vm_pool;
        for (auto &svr : m_buyed_svr_pool) {
            svr->recover_state(memento->m_svr_pool[svr]);
            for (auto &vir : svr->GetVirList()) {
                vir->recover_state(memento->m_vir_pool[vir]);
            }
        }

        delete memento;
    }

   private:
    CareTaker *m_care_taker = new CareTaker();

    const vector<Server *> &m_servers;    // 读入服务器列表
    const vector<Virtual *> &m_virtuals;  // 读入虚拟机列表
    int m_tol_day = 0;                    // 总天数

    vector<Request *> m_requests;                                // 当天拿到的请求
    int m_today_idx = 0;                                         // 今天的id
    unordered_map<string, vector<Server *>> m_reset_svr_pool;    // 预处理
    unordered_map<string, unordered_set<int>> m_reset_svr_set;   // 预处理
    unordered_map<string, pair<int, int>> m_reset_svr_resource;  // 预处理
    int m_VirtualPoolSize = 0;                                   // 当前已经虚拟机的总数
    int m_global_svr_id = 0;                                     // 服务器全局id
    vector<tuple<int, Server *, int>> migration_result;          // vir->svr_to->localnode
    vector<Server *> m_buyed_svr_pool;                           // 已经购买的svr
    unordered_set<int> m_global_obtain_vm_pool;                  // 获取到的所有虚拟机的id集合
    unordered_map<string, vector<Server *>> m_svr_index;

    int m_migra_count = 0;                    // 迁移次数
    int m_future_k_vm_cpu = 0;                // 未来k天vm_cpu
    int m_future_k_vm_mem = 0;                // 未来k天vm_ram
    double m_enemy_yesterday_discount = 0.6;  // 对手昨天打折比率, 默认0.8折
    int m_tol_user_price = 0;                 // 截至现在为止所有订单price之和
};

#endif