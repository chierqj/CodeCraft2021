#include "greedy.h"
#include "scenario/log.h"
#include "scenario/tools.h"

int Greedy::get_daily_cost_price() {
    int ans = 0;
    for (auto& svr : m_buyed_svr_pool) {
        if (svr->GetVirList().empty()) continue;
        int cv = svr->GetHardwareCost();
        int ev = svr->GetEnergyCost();
        int days = svr->get_deltime() - m_today_idx;

        int cost = ev * days;
        if (svr->GetBuyTime() == m_today_idx) cost += cv;
        ans += cost;
    }
    return ans;
}

void Greedy::pre_solve() {
    vector<vector<Request*>> new_req_list;
    this->get_new_req_list(new_req_list);

    for (auto& block : new_req_list) {
        if (block.front()->GetType() == REQ_TYPE::DEL) {
            for (auto& req : block) {
                req->GetVirtual()->del_server();
            }
            continue;
        }
        for (auto& req : block) {
            Server* select_svr;
            int node = -1;
            select_svr = get_old_server(req->GetVirtual(), node);
            if (select_svr != nullptr) {
                do_match(select_svr, req->GetVirtual(), node);
                continue;
            }

            select_svr = get_new_server(req->GetVirtual(), node);
            Server* new_svr = new Server(select_svr);
            this->do_match(new_svr, req->GetVirtual(), node);
            new_svr->SetBuyTime(m_today_idx);
            m_buyed_svr_pool.push_back(new_svr);
        }
    }
}

void Greedy::offer_price(const vector<Request*>& input_requests) {
    this->save_state(m_today_idx);
    m_requests.insert(m_requests.end(), input_requests.begin(), input_requests.end());
    this->pre_solve();

    unordered_map<Server*, int> svr_cost_map;
    for (auto& svr : m_buyed_svr_pool) {
        if (svr->GetVirList().empty()) continue;
        int cv = svr->GetHardwareCost();
        int ev = svr->GetEnergyCost();
        int days = svr->get_deltime() - m_today_idx + 1;
        int cost = cv + ev * days;
        int proto_cpu = svr->GetProtoCpu(), proto_ram = svr->GetProtoRam();
        svr_cost_map[svr] = cost * 1.5 / (2 * proto_cpu + proto_ram);
    }

    m_requests.clear();

    vector<Request*> add_req;
    unordered_set<Request*> m_give_up_set;
    for (auto& req : input_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        add_req.push_back(req);

        auto vir = req->GetVirtual();
        int cpu = vir->GetCpu(), ram = vir->GetRam();
        int user_price = vir->GetUserPrice();
        int vm_cost = user_price / (2 * cpu + ram);
        int svr_cost = svr_cost_map[vir->GetServer()];

        int offer_price = 0;
        if (vm_cost < svr_cost) {
            offer_price = -1;
        } else {
            // offer_price = ((vm_cost * (m_enemy_yesterday_discount - 0.1) + svr_cost) / 2) * (2 * cpu + ram);
            offer_price = user_price * (m_enemy_yesterday_discount - 0.01);
        }

        if (offer_price <= 0 || offer_price > user_price) offer_price = -1;
        if (offer_price == -1) m_give_up_set.insert(req);

        printf("%d\n", offer_price);

        // log_info("--- svr_cost: %d, vm_offer_price: %d", svr_cost, offer_price);
        // vir->debug();
        // vir->GetServer()->debug();
    }

    this->recover_state(m_today_idx);

    double tol_eme_price = 0, tol_price = 0.1;
    for (auto& req : add_req) {
        int suc, enemy_price;
        m_getline("(%d, %d)", &suc, &enemy_price);
        m_tol_user_price += req->GetVirtual()->GetUserPrice();
        if (suc == 1 && m_give_up_set.find(req) == m_give_up_set.end()) {
            m_global_obtain_vm_pool.insert(req->GetVirtual()->GetID());
        }
        if (enemy_price != -1) {
            tol_eme_price += enemy_price;
            tol_price += req->GetVirtual()->GetUserPrice();
        }
    }

    m_enemy_yesterday_discount = tol_eme_price / tol_price;

    for (auto& req : input_requests) {
        if (m_global_obtain_vm_pool.find(req->GetVirtual()->GetID()) == m_global_obtain_vm_pool.end()) {
            continue;
        }
        m_requests.push_back(req);
    }

    // log_debug("day: %d, enemy_discount: %.3f", m_today_idx, m_enemy_yesterday_discount);
}
