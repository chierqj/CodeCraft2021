#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "greedy.h"

using namespace std;

bool Greedy::match_double_node(Server* svr, Virtual* vir) {
    int vm_cpu = vir->GetCpu() >> 1, vm_mem = vir->GetRam() >> 1;
    int cpu_a = svr->GetCpuA(), mem_a = svr->GetRamA();
    int cpu_b = svr->GetCpuB(), mem_b = svr->GetRamB();
    if (cpu_a >= vm_cpu && mem_a >= vm_mem && cpu_b >= vm_cpu && mem_b >= vm_mem) return true;
    return false;
}
bool Greedy::match_node_a(Server* svr, Virtual* vir) {
    int vm_cpu = vir->GetCpu(), vm_mem = vir->GetRam();
    int cpu_a = svr->GetCpuA(), mem_a = svr->GetRamA();
    if (cpu_a >= vm_cpu && mem_a >= vm_mem) return true;
    return false;
}
bool Greedy::match_node_b(Server* svr, Virtual* vir) {
    int vm_cpu = vir->GetCpu(), vm_mem = vir->GetRam();
    int cpu_b = svr->GetCpuB(), mem_b = svr->GetRamB();
    if (cpu_b >= vm_cpu && mem_b >= vm_mem) return true;
    return false;
}

void Greedy::do_match(Server* svr, Virtual* vir, int local_node) {
    svr->add_virtual(vir, local_node, m_today_idx);
    vir->add_server(svr, local_node);
}

Server* Greedy::get_old_server(Virtual* vir, int& local_node) {
    struct Node {
        double val;
        int node;
        Server* svr;
        bool operator<(const Node& r) const { return val < r.val; }
    };

    vector<Node> vct;
    double vm_cpu_ratio = vir->GetDeltaCpuRatio();
    double vm_mem_ratio = vir->GetDeltaRamRatio();

    for (const auto& svr : m_buyed_svr_pool) {
        double cpu_a = svr->GetCpuA(), mem_a = svr->GetRamA();
        double cpu_b = svr->GetCpuB(), mem_b = svr->GetRamB();
        double svr_ratio_cpu_a = (cpu_a - mem_a) / cpu_a, svr_ratio_mem_a = (mem_a - cpu_a) / mem_a;
        double svr_ratio_cpu_b = (cpu_b - mem_b) / cpu_b, svr_ratio_mem_b = (mem_b - cpu_b) / mem_b;

        if (vir->DoubleDeploy()) {
            if (match_double_node(svr, vir)) {
                double val = fabs(svr_ratio_cpu_a - vm_cpu_ratio) + fabs(svr_ratio_mem_a - vm_mem_ratio) +
                             fabs(svr_ratio_cpu_b - vm_cpu_ratio) + fabs(svr_ratio_mem_b - vm_mem_ratio);
                vct.push_back(Node{val, -1, svr});
            }
            continue;
        }
        if (match_node_a(svr, vir)) {
            double val = fabs(svr_ratio_cpu_a - vm_cpu_ratio) + fabs(svr_ratio_mem_a - vm_mem_ratio);
            vct.push_back(Node{val, 0, svr});
        }
        if (match_node_b(svr, vir)) {
            double val = fabs(svr_ratio_cpu_b - vm_cpu_ratio) + fabs(svr_ratio_mem_b - vm_mem_ratio);
            vct.push_back(Node{val, 1, svr});
        }
    }

    stable_sort(vct.begin(), vct.end());
    int r = vct.size() * 0.4;

    Server* select_svr = nullptr;
    double select_value = 0;
    int select_env = 0;

    for (int i = 0; i < r; ++i) {
        const auto& svr = vct[i].svr;
        double val = this->get_used_rate(svr, vir, vct[i].node);
        if (select_svr == nullptr || val < select_value || (val == select_value && svr->GetEnergyCost() < select_env)) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node;
            select_env = svr->GetEnergyCost();
        }
    }

    return select_svr;
}

void Greedy::pretreat() {
    for (auto& vir : m_virtuals) {
        vector<pair<double, Server*>> vct;
        double vm_cpu_ratio = vir->GetDeltaCpuRatio();
        double vm_mem_ratio = vir->GetDeltaRamRatio();

        for (const auto& svr : m_servers) {
            if (vir->DoubleDeploy() && !match_double_node(svr, vir)) continue;
            if (!vir->DoubleDeploy() && !match_node_a(svr, vir)) continue;

            double cpu_a = svr->GetCpuA(), mem_a = svr->GetRamA();
            double svr_ratio_cpu_a = (cpu_a - mem_a) / cpu_a, svr_ratio_mem_a = (mem_a - cpu_a) / mem_a;
            double ratio = fabs(svr_ratio_cpu_a - vm_cpu_ratio) + fabs(svr_ratio_mem_a - vm_mem_ratio);
            vct.push_back({ratio, svr});
        }

        stable_sort(vct.begin(), vct.end());

        int r = max(min(1, (int)vct.size()), (int)(vct.size() * 0.3));

        for (int i = 0; i < r; ++i) {
            const auto& svr = vct[i].second;
            m_reset_svr_pool[vir->GetName()].push_back(svr);
            m_reset_svr_set[vir->GetName()].insert(svr->GetTypeID());
        }
    }
}

Server* Greedy::get_new_server(Virtual* vir, int& local_node) {
    Server* select_svr = nullptr;
    int select_value = 0;
    int delta_day = m_tol_day - m_today_idx;

    double base = (double)m_future_k_vm_cpu / (double)m_future_k_vm_mem + 1.12;
    base = 2.0;

    for (auto& svr : m_reset_svr_pool[vir->GetName()]) {
        double hv = svr->GetHardwareCost();
        double ev = svr->GetEnergyCost() * delta_day;
        double cpu = svr->GetCpuA() + svr->GetCpuB();
        double mem = svr->GetRamA() + svr->GetRamB();
        int val = (hv + ev) / (cpu * base + mem);

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
        }
    }

    local_node = vir->DoubleDeploy() ? -1 : 0;
    return select_svr;
}
