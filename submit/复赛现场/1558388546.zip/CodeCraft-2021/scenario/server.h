#ifndef SCENARIO_SERVER_H
#define SCENARIO_SERVER_H

#include <algorithm>
#include <array>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "virtual.h"
using namespace std;

class Virtual;

// struct SvrNode {
//     int cpu;
//     int memory;
//     int read_cpu;
//     int read_memory;
//     string to_string() const {
//         string msg = "now: [";
//         msg += std::to_string(cpu) + ", ";
//         msg += std::to_string(memory) + "] read: [";
//         msg += std::to_string(read_cpu) + ", ";
//         msg += std::to_string(read_memory) + "]";
//         return msg;
//     }
// };

class Server {
   public:
    Server(string _name, int cpu, int memory, int hardware_cost, int energy_cost, int tp_id) {
        name = _name;
        id = -1;
        type_id = type_id;
        m_cpu_a = m_cpu_b = cpu >> 1;
        m_mem_a = m_mem_b = memory >> 1;
        m_proto_cpu = cpu;
        m_proto_mem = memory;
        m_hardware_cost = hardware_cost;
        m_energy_cost = energy_cost;
        m_inv_cpu = 1.0 / (double)m_proto_cpu;
        m_inv_mem = 1.0 / (double)m_proto_mem;
    }
    Server(const Server *svr) {
        type_id = svr->type_id;
        id = svr->id;
        name = svr->name;
        m_cpu_a = svr->m_cpu_a, m_cpu_b = svr->m_cpu_b;
        m_mem_a = svr->m_mem_a, m_mem_b = svr->m_mem_b;
        m_proto_cpu = svr->m_proto_cpu;
        m_proto_mem = svr->m_proto_mem;
        m_hardware_cost = svr->m_hardware_cost;
        m_energy_cost = svr->m_energy_cost;
        vir_list = svr->vir_list;
        m_inv_cpu = svr->m_inv_cpu;
        m_inv_mem = svr->m_inv_mem;
    }

    void debug() const;
    string to_string();
    void add_virtual(Virtual *vir, int node, int day_idx);
    void del_virtual(Virtual *vir, int node);

   public:
    inline const string &GetName() const { return name; }
    inline const int &GetCPUA() const { return m_cpu_a; }
    inline const int &GetCPUB() const { return m_cpu_b; }
    inline const int &GetMemA() const { return m_mem_a; }
    inline const int &GetMemB() const { return m_mem_b; }
    inline const int &GetProtoCPU() const { return m_proto_cpu; }
    inline const int &GetProtoMem() const { return m_proto_mem; }

    inline const int &GetHardwareCost() const { return m_hardware_cost; }
    inline const int &GetEnergyCost() const { return m_energy_cost; }
    inline const int &GetID() const { return id; }
    inline void SetID(int _id) { id = _id; }
    inline const int &GetAddTime() const { return add_time; }
    inline void SetAddTime(int t) { add_time = t; }
    inline const int &GetDelTime() const { return del_time; }
    inline void SetDelTime(int t) { del_time = t; }
    inline const unordered_set<Virtual *> &GetVirList() const { return vir_list; }
    void update_deltime();

    inline const int GetRest() const { return m_cpu_a + m_cpu_b + m_mem_a + m_mem_b; }
    inline const int GetRestA() const { return m_cpu_a + m_mem_a; }
    inline const int GetRestB() const { return m_cpu_b + m_mem_b; }
    inline const int GetWeightedRest() const {
        int cpu = m_cpu_a + m_cpu_b;
        int mem = m_mem_a + m_mem_b;
        return cpu * 2 + mem;
    }
    inline const int GetWeightedRestA() const {
        int cpu = m_cpu_a, mem = m_mem_a;
        return cpu * 2 + mem;
    }
    inline const int GetWeightedRestB() const {
        int cpu = m_cpu_b, mem = m_mem_b;
        return cpu * 2 + mem;
    }
    inline void SetTypeID(int id) { type_id = id; }
    inline const int GetTypeID() const { return type_id; }

    inline const double &GetInvCPU() const { return m_inv_cpu; }
    inline const double &GetInvMem() const { return m_inv_mem; }

   private:
    int id = -1;                        // id
    string name;                        // 类型名
    int m_cpu_a, m_mem_a;               // A 实时
    int m_cpu_b, m_mem_b;               // B 实时
    int m_proto_cpu, m_proto_mem;       // 读入
    int m_hardware_cost;                // 硬件成本
    int m_energy_cost;                  // 能耗成本
    int type_id;                        // 类型id
    int add_time = -1;                  // 创建时间,初始化为-1,创建之后不为-1
    int del_time = -1;                  // 删除时间,没有就是最后一天
    unordered_set<Virtual *> vir_list;  // 当前server部署的虚拟机数量
    double m_inv_cpu, m_inv_mem;        // cpu, mem倒数
};

#endif