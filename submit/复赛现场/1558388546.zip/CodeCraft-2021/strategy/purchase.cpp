#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "greedy.h"

using namespace std;

// bool Greedy::match_purchase(Server* svr, Virtual* vir, int& local_node) {
//     int vm_cpu = vir->GetCPU(), vm_mem = vir->GetMemory();
//     int cpu_a = svr->GetCPUA(), cpu_b = svr->GetCPUA();
//     int mem_a = svr->GetNodes()[0].memory, mem_b = svr->GetNodes()[1].memory;

//     if (vir->GetNodeCount() == 2) {
//         vm_cpu >>= 1;
//         vm_mem >>= 1;
//         if (cpu_a >= vm_cpu && mem_a >= vm_mem && cpu_b >= vm_cpu && mem_b >= vm_mem) {
//             local_node = -1;
//             return true;
//         }
//     } else {
//         bool ok_a = false, ok_b = false;
//         if (cpu_a >= vm_cpu && mem_a >= vm_mem) ok_a = true;
//         if (cpu_b >= vm_cpu && mem_b >= vm_mem) ok_b = true;
//         if (ok_a && ok_b) {
//             double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
//             double val_a = fabs((double)cpu_a / (double)mem_a - vir_value);
//             double val_b = fabs((double)cpu_b / (double)mem_b - vir_value);
//             local_node = val_a < val_b ? 0 : 1;
//             return true;
//         }
//         if (ok_a || ok_b) {
//             local_node = ok_a ? 0 : 1;
//             return true;
//         }
//     }
//     return false;
// }
bool Greedy::match_double_node(Server* svr, Virtual* vir) {
    int vm_cpu = vir->GetCPU() >> 1, vm_mem = vir->GetMem() >> 1;
    int cpu_a = svr->GetCPUA(), mem_a = svr->GetMemA();
    int cpu_b = svr->GetCPUB(), mem_b = svr->GetMemB();
    if (cpu_a >= vm_cpu && mem_a >= vm_mem && cpu_b >= vm_cpu && mem_b >= vm_mem) return true;
    return false;
}
bool Greedy::match_node_a(Server* svr, Virtual* vir) {
    int vm_cpu = vir->GetCPU(), vm_mem = vir->GetMem();
    int cpu_a = svr->GetCPUA(), mem_a = svr->GetMemA();
    if (cpu_a >= vm_cpu && mem_a >= vm_mem) return true;
    return false;
}
bool Greedy::match_node_b(Server* svr, Virtual* vir) {
    int vm_cpu = vir->GetCPU(), vm_mem = vir->GetMem();
    int cpu_b = svr->GetCPUB(), mem_b = svr->GetMemB();
    if (cpu_b >= vm_cpu && mem_b >= vm_mem) return true;
    return false;
}

void Greedy::do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

Server* Greedy::get_old_server(Virtual* vir, int day, int& local_node) {
    struct Node {
        double val;
        int node;
        Server* svr;
        bool operator<(const Node& r) const { return val < r.val; }
    };

    vector<Node> vct;
    double vm_cpu_ratio = vir->GetDeltaCPURatio();
    double vm_mem_ratio = vir->GetDeltaMEMRatio();

    for (const auto& svr : m_buyed_svr_pool) {
        double cpu_a = svr->GetCPUA(), mem_a = svr->GetMemA();
        double cpu_b = svr->GetCPUB(), mem_b = svr->GetMemB();
        double svr_ratio_cpu_a = (cpu_a - mem_a) / cpu_a, svr_ratio_mem_a = (mem_a - cpu_a) / mem_a;
        double svr_ratio_cpu_b = (cpu_b - mem_b) / cpu_b, svr_ratio_mem_b = (mem_b - cpu_b) / mem_b;

        if (vir->DoubleDeploy()) {
            if (match_double_node(svr, vir)) {
                double val = fabs(svr_ratio_cpu_a - vm_cpu_ratio) + fabs(svr_ratio_mem_a - vm_mem_ratio) +
                             fabs(svr_ratio_cpu_b - vm_cpu_ratio) + fabs(svr_ratio_mem_b - vm_mem_ratio);
                vct.push_back(Node{val, -1, svr});
            }
            continue;
        }
        if (match_node_a(svr, vir)) {
            double val = fabs(svr_ratio_cpu_a - vm_cpu_ratio) + fabs(svr_ratio_mem_a - vm_mem_ratio);
            vct.push_back(Node{val, 0, svr});
        }
        if (match_node_b(svr, vir)) {
            double val = fabs(svr_ratio_cpu_b - vm_cpu_ratio) + fabs(svr_ratio_mem_b - vm_mem_ratio);
            vct.push_back(Node{val, 1, svr});
        }
    }

    stable_sort(vct.begin(), vct.end());
    int r = vct.size() * 0.4;

    Server* select_svr = nullptr;
    double select_value = 0;
    int select_env = 0;

    for (int i = 0; i < r; ++i) {
        const auto& svr = vct[i].svr;
        // double val = this->get_used_rate(svr, vir, vct[i].node);
        int val = svr->GetWeightedRest();
        if (select_svr == nullptr || val < select_value || (val == select_value && svr->GetEnergyCost() < select_env)) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node;
            select_env = svr->GetEnergyCost();
        }
    }

    return select_svr;
}

void Greedy::pretreat() {
    for (auto& vir : m_virtuals) {
        vector<pair<double, Server*>> vct;
        double vm_cpu_ratio = vir->GetDeltaCPURatio();
        double vm_mem_ratio = vir->GetDeltaMEMRatio();

        for (const auto& svr : m_servers) {
            if (vir->DoubleDeploy() && !match_double_node(svr, vir)) continue;
            if (!vir->DoubleDeploy() && !match_node_a(svr, vir)) continue;

            double cpu_a = svr->GetCPUA(), mem_a = svr->GetMemA();
            double svr_ratio_cpu_a = (cpu_a - mem_a) / cpu_a, svr_ratio_mem_a = (mem_a - cpu_a) / mem_a;
            double ratio = fabs(svr_ratio_cpu_a - vm_cpu_ratio) + fabs(svr_ratio_mem_a - vm_mem_ratio);
            vct.push_back({ratio, svr});
        }

        stable_sort(vct.begin(), vct.end());

        int r = max(min(1, (int)vct.size()), (int)(vct.size() * 0.4));

        // double ratio = vct[r - 1].first;
        // for (; r < (int)vct.size(); ++r) {
        //     double v = (vct[r].first - ratio) / ratio;
        //     if (v > 0.2) break;
        // }

        for (int i = 0; i < r; ++i) {
            const auto& svr = vct[i].second;
            m_reset_svr_pool[vir->GetName()].push_back(svr);
            m_reset_svr_set[vir->GetName()].insert(svr->GetTypeID());
        }
    }
}

Server* Greedy::get_new_server(Virtual* vir, int day, int& local_node) {
    Server* select_svr = nullptr;
    int select_value = 0;
    int delta_day = m_tol_day - day;

    double base = (double)m_future_k_vm_cpu / (double)m_future_k_vm_mem + 1.12;
    base = 2.0;

    for (auto& svr : m_reset_svr_pool[vir->GetName()]) {
        double hv = svr->GetHardwareCost();
        double ev = svr->GetEnergyCost() * delta_day;
        double cpu = svr->GetCPUA() + svr->GetCPUB();
        double mem = svr->GetMemA() + svr->GetMemB();
        int val = (hv + ev) / (cpu * base + mem);

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
        }
    }

    local_node = vir->DoubleDeploy() ? -1 : 0;
    return select_svr;
}
