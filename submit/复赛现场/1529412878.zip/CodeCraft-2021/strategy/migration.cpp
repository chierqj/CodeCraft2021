#include <algorithm>
#include <cassert>
#include <climits>
#include <cmath>
#include <map>
#include <set>

#include "greedy.h"

double Greedy::get_used_rate(Server* svr, Virtual* vir, int node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();

    double ans = 0;
    double inv_cpu = 1.0 / (double)svr->GetNodes()[0].read_cpu;
    double inv_mem = 1.0 / (double)svr->GetNodes()[0].read_memory;

    if (node == -1) {
        double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu - vir_cpu;
        double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory - vir_mem;
        double x = cpu * inv_cpu, y = mem * inv_mem;
        ans = (x * x + y * y) * sqrt(svr->GetEnergyCost());
    } else {
        double cpu = svr->GetNodes()[node].cpu - vir_cpu;
        double mem = svr->GetNodes()[node].memory - vir_mem;
        double x = cpu * inv_cpu, y = mem * inv_mem;
        ans = (x * x + y * y) * sqrt(svr->GetEnergyCost());
    }

    return ans;
}

void Greedy::do_migration_1(int day, int& migra_count, vector<Server*>& tol_svr_list) {
    if (migra_count <= 0) return;

    map<int, unordered_set<Server*>> hash_svr_list;
    for (auto& svr : tol_svr_list) {
        if (svr->GetVirList().empty()) continue;
        hash_svr_list[svr->GetWeightedRestResource()].insert(svr);
    }

    auto action_move = [&](Virtual* vir, Server* svr_to, int node) {
        hash_svr_list[vir->GetServer()->GetWeightedRestResource()].erase(vir->GetServer());
        if (hash_svr_list[vir->GetServer()->GetWeightedRestResource()].empty()) {
            hash_svr_list.erase(vir->GetServer()->GetWeightedRestResource());
        }
        hash_svr_list[svr_to->GetWeightedRestResource()].erase(svr_to);
        if (hash_svr_list[svr_to->GetWeightedRestResource()].empty()) {
            hash_svr_list.erase(svr_to->GetWeightedRestResource());
        }

        vir->del_server();

        svr_to->add_virtual(vir, node, day);
        vir->add_server(svr_to, node);

        hash_svr_list[svr_to->GetWeightedRestResource()].insert(svr_to);
    };

    vector<Virtual*> vir_list;
    int max_migra_count = 2 * migra_count;
    // if (m_servers.size() == 100) max_migra_count = 3 * migra_count;
    if (dataset_model == 2) max_migra_count = 3 * migra_count;

    tol_svr_list.clear();

    for (auto it = hash_svr_list.rbegin(); it != hash_svr_list.rend(); it++) {
        for (auto svr : it->second) {
            tol_svr_list.push_back(svr);
            vir_list.insert(vir_list.end(), svr->GetVirList().begin(), svr->GetVirList().end());
        }
        if ((int)vir_list.size() >= max_migra_count) break;
    }

    stable_sort(vir_list.begin(), vir_list.end(), [&](const Virtual* vir1, const Virtual* vir2) {
        return vir1->GetWeightedRestResource() > vir2->GetWeightedRestResource();
    });

    vector<bool> suc_move_flag(1024, false);
    vector<bool> not_search_flag(1024, false);
    unordered_set<Server*> action_move_set;

    for (auto& vir : vir_list) {
        if (migra_count <= 0) return;
        if (not_search_flag[vir->GetTypeID()]) continue;
        if (vir->GetDelTime() == day) continue;
        if (action_move_set.find(vir->GetServer()) != action_move_set.end()) continue;

        Server* select_svr = nullptr;
        double select_value = vir->GetScore();
        int select_node = -1;
        int select_env = 0;

        auto iter = hash_svr_list.lower_bound(vir->GetWeightedRestResource());
        for (; iter != hash_svr_list.end(); ++iter) {
            const auto& svr_to_list = iter->second;
            for (auto svr_to : svr_to_list) {
                if (svr_to == vir->GetServer()) continue;
                if (svr_to->GetVirList().empty()) continue;

                int node = -1;
                if (!this->match_purchase(svr_to, vir, node)) continue;

                double val = this->get_used_rate(svr_to, vir, node);
                if (select_svr == nullptr || val < select_value ||
                    (val == select_value && svr_to->GetEnergyCost() < select_env)) {
                    select_svr = svr_to;
                    select_value = val;
                    select_node = node;
                    select_env = svr_to->GetEnergyCost();
                }
            }
        }

        if (select_svr != nullptr) {
            action_move_set.insert(select_svr);
            suc_move_flag[vir->GetTypeID()] = true;
            action_move(vir, select_svr, select_node);
            migration_result.push_back({vir->GetID(), select_svr, select_node});
            --migra_count;
        } else {
            if (suc_move_flag[vir->GetTypeID()]) not_search_flag[vir->GetTypeID()] = true;
        }
    }
}

void Greedy::do_migration_2(int day, int& migra_count, vector<Server*>& tol_svr_list) {
    if (migra_count <= 0) return;

    map<int, unordered_set<Server*>> hash_svr_list;
    for (auto& svr : tol_svr_list) {
        if (svr->GetVirList().empty()) continue;
        hash_svr_list[svr->GetWeightedRestResource()].insert(svr);
    }

    auto action_move = [&](Virtual* vir, Server* svr_to, int node) {
        hash_svr_list[vir->GetServer()->GetWeightedRestResource()].erase(vir->GetServer());
        if (hash_svr_list[vir->GetServer()->GetWeightedRestResource()].empty()) {
            hash_svr_list.erase(vir->GetServer()->GetWeightedRestResource());
        }
        hash_svr_list[svr_to->GetWeightedRestResource()].erase(svr_to);
        if (hash_svr_list[svr_to->GetWeightedRestResource()].empty()) {
            hash_svr_list.erase(svr_to->GetWeightedRestResource());
        }

        vir->del_server();

        svr_to->add_virtual(vir, node, day);
        vir->add_server(svr_to, node);

        hash_svr_list[svr_to->GetWeightedRestResource()].insert(svr_to);
    };

    vector<Virtual*> vir_list;
    int max_migra_count = 5 * migra_count;

    for (auto it = hash_svr_list.rbegin(); it != hash_svr_list.rend(); it++) {
        for (auto svr : it->second) {
            vir_list.insert(vir_list.end(), svr->GetVirList().begin(), svr->GetVirList().end());
        }
        if ((int)vir_list.size() >= max_migra_count) break;
    }

    stable_sort(vir_list.begin(), vir_list.end(), [&](const Virtual* vir1, const Virtual* vir2) {
        return vir1->GetWeightedRestResource() > vir2->GetWeightedRestResource();
    });

    vector<bool> not_search_flag(1024, false);
    unordered_set<Server*> action_move_set;

    for (auto& vir : vir_list) {
        if (migra_count <= 0) return;
        if (not_search_flag[vir->GetTypeID()]) continue;
        if (vir->GetDelTime() == day) continue;
        if (action_move_set.find(vir->GetServer()) != action_move_set.end()) continue;

        Server* select_svr = nullptr;
        double select_value = vir->GetScore();
        int select_node = -1;
        int select_env = 0;

        auto iter = hash_svr_list.lower_bound(vir->GetWeightedRestResource());
        for (; iter != hash_svr_list.end(); ++iter) {
            const auto& svr_to_list = iter->second;
            for (auto svr_to : svr_to_list) {
                if (svr_to == vir->GetServer()) continue;
                if (svr_to->GetVirList().empty()) continue;

                int node = -1;
                if (!this->match_purchase(svr_to, vir, node)) continue;

                double val = this->get_used_rate(svr_to, vir, -1);
                if (val < select_value || (val == select_value && svr_to->GetEnergyCost() < select_env)) {
                    select_svr = svr_to;
                    select_value = val;
                    select_node = node;
                    select_env = svr_to->GetEnergyCost();
                    action_move_set.insert(select_svr);
                    action_move(vir, select_svr, select_node);
                    migration_result.push_back({vir->GetID(), select_svr, select_node});
                    --migra_count;
                    goto END;
                }
            }
        }
    END:
        continue;
        // if (select_svr != nullptr) {
        //     // cout << "-----------------------------------------------\n";
        //     // vir->debug();
        //     // vir->GetServer()->debug();
        //     // select_svr->debug();

        //     action_move_set.insert(select_svr);
        //     action_move(vir, select_svr, select_node);
        //     migration_result.push_back({vir->GetID(), select_svr, select_node});
        //     --migra_count;
        // } else {
        //     not_search_flag[vir->GetTypeID()] = true;
        // }
    }
}

void Greedy::do_migration(int day) {
    migration_result.clear();
    int migra_count = m_VirtualPoolSize * 3 / 100;
    if (day == (int)(m_tol_day * 0.8)) {
        migra_count = m_VirtualPoolSize;
    }
    // int migra_count = m_VirtualPoolSize * 5 / 1000;
    if (migra_count <= 0) return;
    int loop = -1;

    vector<Server*> svr_pool;
    for (auto& svr : m_buyed_svr_pool) {
        if (svr->GetVirList().empty()) continue;
        svr_pool.push_back(svr);
    }
    while (true) {
        ++loop;
        int count = migra_count;
        this->do_migration_1(day, migra_count, svr_pool);
        // if (m_servers.size() == 80) {
        //     this->do_migration_2(day, migra_count, m_buyed_svr_pool);
        // } else if (loop <= 3) {
        //     this->do_migration_2(day, migra_count, m_buyed_svr_pool);
        // }
        // if (dataset_model == 1) {
        //     this->do_migration_2(day, migra_count, m_buyed_svr_pool);
        // } else if (loop <= 3) {
        if (loop <= 3) this->do_migration_2(day, migra_count, m_buyed_svr_pool);
        // }

        if (count == migra_count || migra_count <= 0) break;
    }
}
