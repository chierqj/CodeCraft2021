#include "server.h"

#include <algorithm>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;

void Server::debug() const {
    printf(
        "(服务器: %s, id: %d, proto: [%d, %d], node_a: [%d, %d], node_b: [%d, %d], hv: %d, ev: %d, rest: %d, weight: "
        "%d)\n",
        name.c_str(), id, m_proto_cpu, m_proto_mem, m_cpu_a, m_mem_a, m_cpu_b, m_mem_b, m_hardware_cost, m_energy_cost,
        this->GetRest(), this->GetWeightedRest());
    for (auto& it : vir_list) {
        cout << "* 当前绑定: ";
        it->debug();
    }
}

string Server::to_string() {
    string msg = "服务器: (";
    // msg += name + ", ";
    // msg += std::to_string(m_cpu) + ", ";
    // msg += std::to_string(m_memory) + ", ";
    // msg += std::to_string(m_hardware_cost) + ", ";
    // msg += std::to_string(m_energy_cost) + ")";
    return msg;
}

void Server::add_virtual(Virtual* vir, int node, int day_idx) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMem();
    if (vir->DoubleDeploy()) {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        m_cpu_a -= vir_cpu;
        m_mem_a -= vir_mem;
        m_cpu_b -= vir_cpu;
        m_mem_b -= vir_mem;
    } else {
        if (node == 0) {
            m_cpu_a -= vir_cpu;
            m_mem_a -= vir_mem;
        } else {
            m_cpu_b -= vir_cpu;
            m_mem_b -= vir_mem;
        }
    }
    if (add_time == -1) add_time = day_idx;
    del_time = max(del_time, vir->GetDelTime());
    vir_list.insert(vir);
}

void Server::del_virtual(Virtual* vir, int node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMem();
    if (vir->DoubleDeploy()) {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        m_cpu_a += vir_cpu;
        m_mem_a += vir_mem;
        m_cpu_b += vir_cpu;
        m_mem_b += vir_mem;
    } else {
        if (node == 0) {
            m_cpu_a += vir_cpu;
            m_mem_a += vir_mem;
        } else {
            m_cpu_b += vir_cpu;
            m_mem_b += vir_mem;
        }
    }
    vir_list.erase(vir);
}

void Server::update_deltime() {
    del_time = 0;
    for (auto& it : vir_list) {
        del_time = max(del_time, it->GetDelTime());
    }
}