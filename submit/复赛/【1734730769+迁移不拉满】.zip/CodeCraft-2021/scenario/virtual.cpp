#include "virtual.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

void Virtual::debug() {
    cout << "虚拟机: (" << name << ", ";
    cout << "id: " << id << ", ";
    cout << "type_id: " << type_id << ", ";
    cout << "cpu: " << m_cpu << ", ";
    cout << "mem: " << m_memory << ", ";
    cout << "double_deploy: " << m_double_deploy << ", ";
    cout << "local_node: " << local_node << ", ";
    cout << "weighted: " << this->GetWeightedRest() << ", ";
    cout << "score: " << this->GetScore() << ")\n";
}

string Virtual::to_string() {
    string msg = "虚拟机: (" + name + ", ";
    msg += "cpu: " + std::to_string(m_cpu) + ", ";
    msg += "mem: " + std::to_string(m_memory) + ", ";
    msg += "double_deploy: " + std::to_string(m_double_deploy) + ", ";
    msg += "local_node: " + std::to_string(local_node) + ", ";
    msg += "add_time: " + std::to_string(add_time) + ", ";
    msg += "del_time: " + std::to_string(del_time) + ")";
    return msg;
}

void Virtual::del_server() {
    m_svr->del_virtual(this, local_node);
    // m_svr = nullptr;
}

void Virtual::add_server(Server *svr, int node) {
    m_svr = svr;
    local_node = node;
}

const double Virtual::GetScore() const {
    if (m_svr == nullptr) return 0;
    int cpu_a = m_svr->GetCPUA(), mem_a = m_svr->GetMemA();
    int cpu_b = m_svr->GetCPUB(), mem_b = m_svr->GetMemB();

    double inv_cpu = m_svr->GetInvCPU(), inv_mem = m_svr->GetInvMem();
    double cpu = (local_node == -1 ? (cpu_a + cpu_b) : local_node == 0 ? cpu_a : cpu_b);
    double mem = (local_node == -1 ? (mem_a + mem_b) : local_node == 0 ? mem_a : mem_b);
    double x = cpu * inv_cpu, y = mem * inv_mem;
    return (x * x + y * y) * sqrt(m_svr->GetEnergyCost());
}