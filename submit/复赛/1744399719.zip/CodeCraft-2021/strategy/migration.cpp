#include <algorithm>
#include <cassert>
#include <climits>
#include <map>
#include <set>

#include "greedy.h"

double Greedy::get_used_rate(Server* svr, Virtual* vir, int local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();

    double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu - vir_cpu;
    double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory - vir_mem;
    double read_cpu = svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu;
    double read_mem = svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory;

    return 1.0 - (cpu + mem) / (read_cpu + read_mem);
}

void Greedy::do_migration(int day) {
    migration_result.clear();
    int migra_count = m_VirtualPoolSize * 3 / 100;
    if (migra_count <= 0) return;

    while (true) {
        int count = migra_count;
        if (migra_count <= 0) return;
        vector<Virtual*> virs;
        map<int, unordered_set<Server*>> servers;
        for (auto& svr : m_buyed_svr_pool) {
            if (svr->GetVirList().empty()) continue;
            auto& svrs = servers[svr->GetRestResource()];
            svrs.insert(svr);
        }
        for (auto it = servers.rbegin(); it != servers.rend(); it++) {
            auto& svrs = it->second;
            bool brk = false;
            for (auto svr : svrs) {
                if (virs.size() + svr->GetVirList().size() > 1.3 * migra_count) {
                    brk = true;
                    break;
                }
                vector<Virtual*> tmp(svr->GetVirList().begin(), svr->GetVirList().end());
                virs.insert(virs.end(), tmp.begin(), tmp.end());
            }
            if (brk) break;
        }
        sort(virs.begin(), virs.end(), [&](const Virtual* vir1, const Virtual* vir2) {
            return vir1->GetCPU() + vir1->GetMemory() / 2 > vir2->GetCPU() + vir2->GetMemory() / 2;
        });

        for (auto& vir : virs) {
            if (migra_count <= 0) return;
            auto iter = servers.lower_bound(vir->GetRestResource());

            for (; iter != servers.end(); ++iter) {
                auto& svrs = iter->second;
                bool brk = false;
                for (auto svr : svrs) {
                    auto oldSvr = vir->GetServer();
                    if (oldSvr == svr) {
                        brk = true;
                        break;
                    }
                    if (svr->GetVirList().empty()) continue;

                    int node = -1;
                    if (!this->match_purchase(svr, vir, node)) continue;

                    servers[oldSvr->GetRestResource()].erase(oldSvr);

                    vir->del_server();
                    svr->add_virtual(vir, node, 0);
                    vir->add_server(svr, node);

                    svrs.erase(svr);
                    if (!svr->GetVirList().empty()) servers[svr->GetRestResource()].insert(svr);

                    migration_result.push_back({vir->GetID(), svr, node});
                    --migra_count;
                    brk = true;
                    break;
                }
                if (brk) break;
            }
        }

        if (count == migra_count) return;
    }
}
