#ifndef SIMULATION_SIMULATION_H
#define SIMULATION_SIMULATION_H
#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

class Simulation {
   public:
    void RunFrameWork();
};

#endif  // SIMULATION_SIMULATION_H