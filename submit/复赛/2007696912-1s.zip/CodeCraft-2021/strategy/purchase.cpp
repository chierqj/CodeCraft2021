#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "greedy.h"

using namespace std;

bool Greedy::match_purchase(Server* svr, Virtual* vir, int& local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();
    int cpu1 = svr_nodes[0].cpu;
    int mem1 = svr_nodes[0].memory;
    int cpu2 = svr_nodes[1].cpu;
    int mem2 = svr_nodes[1].memory;

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem) {
            ok1 = true;
        }
        if (cpu2 >= vir_cpu && mem2 >= vir_mem) {
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)cpu1 / (double)mem1 - vir_value);
            double valB = fabs((double)cpu2 / (double)mem2 - vir_value);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem && cpu2 >= vir_cpu && mem2 >= vir_mem) {
            return true;
        }
    }
    return false;
}

void Greedy::do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

Server* Greedy::get_old_server(Virtual* vir, int day, int& local_node) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    double vir_value = ((double)vir->GetCPU() - (double)vir->GetMemory()) / (double)vir->GetCPU();
    vector<Node> vct;

    for (const auto& svr : m_buyed_svr_pool) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;

        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs(((double)svr_nodes[0].cpu - (double)svr_nodes[0].memory) / (double)svr_nodes[0].cpu - vir_value);
            val +=
                fabs(((double)svr_nodes[1].cpu - (double)svr_nodes[1].memory) / (double)svr_nodes[1].cpu - vir_value);
            // val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs(((double)svr_nodes[pid].cpu - (double)svr_nodes[pid].memory) / (double)svr_nodes[pid].cpu -
                       vir_value);

            // val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 1000), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.2; ++i) {
        // for (int i = 0; i < (int)vct.size(); ++i) {
        // if (i != 0) {
        //     double tmp_val = (double)vct[i].val / (vir_value * 1000);
        //     if (tmp_val > 0.3) break;
        // }
        const auto& svr = vct[i].svr;
        int val = 0;
        int max_time = 0;
        for (auto& it : svr->GetVirList()) max_time = max(max_time, it->GetDelTime());

        if (vir->GetNodeCount() == 2) {
            val = svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory / 2;
            val += svr->GetNodes()[1].cpu + svr->GetNodes()[1].memory / 2;
        } else {
            int pid = vct[i].node_idx;
            val = svr->GetNodes()[pid].cpu + svr->GetNodes()[pid].memory / 2;
        }

        if (vir->GetDelTime() > max_time) {
            val += (vir->GetDelTime() - max_time) * svr->GetEnergyCost();
        }

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node_idx;
        }
    }

    return select_svr;
}

Server* Greedy::get_new_server(Virtual* vir, int day, int& local_node) {
    struct Node {
        int val;
        int node_idx;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    // double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
    double vir_value = ((double)vir->GetCPU() - (double)vir->GetMemory()) / (double)vir->GetCPU();

    vector<Node> vct;

    for (const auto& svr : m_servers) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;
        double val = 0;
        const auto& svr_nodes = svr->GetNodes();
        if (vir->GetNodeCount() == 2) {
            val = fabs(((double)svr_nodes[0].cpu - (double)svr_nodes[0].memory) / (double)svr_nodes[0].cpu - vir_value);
            val +=
                fabs(((double)svr_nodes[1].cpu - (double)svr_nodes[1].memory) / (double)svr_nodes[1].cpu - vir_value);
            // val += fabs((double)svr_nodes[1].cpu / (double)svr_nodes[1].memory - vir_value);
        } else {
            int pid = node;
            val = fabs(((double)svr_nodes[pid].cpu - (double)svr_nodes[pid].memory) / (double)svr_nodes[pid].cpu -
                       vir_value);

            // val = fabs((double)(svr_nodes[pid].cpu) / double(svr_nodes[pid].memory) - vir_value);
        }

        vct.push_back(Node{(int)(val * 100), node, svr});
    }

    sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;
    int delta_day = vir->GetDelTime() - day;

    for (int i = 0; i < (int)vct.size() * 0.4; ++i) {
        const auto& svr = vct[i].svr;
        int val = (svr->GetHardwareCost() / 5 + svr->GetEnergyCost() * delta_day) /
                  (svr->GetNodes()[0].cpu + svr->GetNodes()[0].memory / 2);
        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node_idx;
        }
    }

    return select_svr;
}
