#include <algorithm>
#include <cassert>
#include <climits>
#include <map>
#include <set>

#include "greedy.h"

double Greedy::get_used_rate(Server* svr, Virtual* vir, int local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();

    double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu - vir_cpu;
    double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory - vir_mem;
    double read_cpu = svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu;
    double read_mem = svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory;

    return 1.0 - (cpu + mem) / (read_cpu + read_mem);
}

// // void Greedy::do_migration(int day) {
// //     migration_result.clear();
// //     int migra_count = m_VirtualPoolSize * 3 / 100;
// //     if (migra_count <= 0) return;

// //     vector<int> svr_idx_list;
// //     unordered_map<Server *, int> svr_hash_id;
// //     for (int i = 0; i < (int)m_buyed_svr_pool.size(); ++i) {
// //         svr_idx_list.push_back(i);
// //         svr_hash_id[m_buyed_svr_pool[i]] = i;
// //         m_buyed_svr_pool[i]->update_deltime();
// //     }

// //     sort(svr_idx_list.begin(), svr_idx_list.end(), [&](const int &x, const int &y) {
// //         const auto &svr1 = m_buyed_svr_pool[x];
// //         const auto &svr2 = m_buyed_svr_pool[y];
// //         int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu;
// //         int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory;
// //         int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu;
// //         int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory;
// //         int t1 = svr1->GetDelTime(), t2 = svr2->GetDelTime();
// //         int val1 = cpu1 + mem1 / 2, val2 = cpu2 + mem2 / 2;
// //         // if (abs(val1 - val2) <= 10) return t1 < t2;
// //         return val1 < val2;
// //     });

// //     int sz = svr_idx_list.size();
// //     for (int i = sz - 1; i >= 0; --i) {
// //         if (migra_count <= 0) return;

// //         auto &svr_from = m_buyed_svr_pool[svr_idx_list[i]];
// //         vector<Virtual *> vir_list(svr_from->GetVirList().begin(), svr_from->GetVirList().end());

// //         for (auto &vir : vir_list) {
// //             if (migra_count <= 0) return;

// //             int vir_val = vir->GetCPU() + vir->GetMemory();
// //             auto pos = lower_bound(svr_idx_list.begin(), svr_idx_list.begin() + i, vir_val,
// //                                    [&](const int &p, const int &pval) {
// //                                        const auto &svr = m_buyed_svr_pool[p];
// //                                        int cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
// //                                        int mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;
// //                                        int nv = cpu + mem;
// //                                        return pval > nv;
// //                                    });
// //             if (pos == svr_idx_list.begin() + i) continue;

// //             int up = min(i, (int)(pos - svr_idx_list.begin()));

// //             for (int j = 0; j < up; ++j) {
// //                 const auto &svr_to = m_buyed_svr_pool[svr_idx_list[j]];
// //                 int node = -1;
// //                 if (!this->match_purchase(svr_to, vir, node)) continue;

// //                 int from_cpu = svr_from->GetNodes()[0].cpu + svr_from->GetNodes()[1].cpu;
// //                 int from_mem = svr_from->GetNodes()[0].memory + svr_from->GetNodes()[1].memory;

// //                 int from_val = from_cpu + from_mem;
// //                 auto p1 =
// //                     lower_bound(svr_idx_list.begin(), svr_idx_list.end(), from_val, [&](const int &p, const int
// //                     &pval) {
// //                         const auto &svr = m_buyed_svr_pool[p];
// //                         int cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
// //                         int mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;
// //                         int nv = cpu + mem;
// //                         return pval > nv;
// //                     });
// //                 svr_idx_list.erase(p1);

// //                 int to_cpu = svr_to->GetNodes()[0].cpu + svr_to->GetNodes()[1].cpu;
// //                 int to_mem = svr_to->GetNodes()[0].memory + svr_to->GetNodes()[1].memory;
// //                 int to_val = to_cpu + to_mem;
// //                 auto p2 =
// //                     lower_bound(svr_idx_list.begin(), svr_idx_list.end(), to_val, [&](const int &p, const int
// &pval)
// //                     {
// //                         const auto &svr = m_buyed_svr_pool[p];
// //                         int cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
// //                         int mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;
// //                         int nv = cpu + mem;
// //                         return pval > nv;
// //                     });
// //                 svr_idx_list.erase(p2);

// //                 vir->del_server();
// //                 svr_to->add_virtual(vir, node, 0);
// //                 vir->add_server(svr_to, node);
// //                 migration_result.push_back({vir->GetID(), svr_to, node});
// //                 --migra_count;

// //                 // from_cpu = svr_from->GetNodes()[0].cpu + svr_from->GetNodes()[1].cpu;
// //                 // from_mem = svr_from->GetNodes()[0].memory + svr_from->GetNodes()[1].memory;
// //                 // from_val = from_cpu + from_mem;
// //                 // auto p3 =
// //                 //     upper_bound(svr_idx_list.begin(), svr_idx_list.end(), from_val, [&](const int &p, const int
// //                 //     &pval) {
// //                 //         const auto &svr = m_buyed_svr_pool[p];
// //                 //         int cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
// //                 //         int mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;
// //                 //         int nv = cpu + mem;
// //                 //         return pval > nv;
// //                 //     });
// //                 // svr_idx_list.insert(p3 - 1, svr_hash_id[svr_from]);

// //                 // to_cpu = svr_to->GetNodes()[0].cpu + svr_to->GetNodes()[1].cpu;
// //                 // to_mem = svr_to->GetNodes()[0].memory + svr_to->GetNodes()[1].memory;
// //                 // to_val = to_cpu + to_mem;
// //                 // auto p4 =
// //                 //     upper_bound(svr_idx_list.begin(), svr_idx_list.end(), to_val, [&](const int &p, const int
// //                 &pval)
// //                 //     {
// //                 //         const auto &svr = m_buyed_svr_pool[p];
// //                 //         int cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
// //                 //         int mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;
// //                 //         int nv = cpu + mem;
// //                 //         return pval > nv;
// //                 //     });
// //                 // svr_idx_list.insert(p4 - 1, svr_hash_id[svr_to]);

// //                 break;
// //             }
// //         }
// //     }
// // }

// void Greedy::do_migration(int day) {
//     return;
//     migration_result.clear();
//     int migra_count = m_VirtualPoolSize * 3 / 100;
//     if (migra_count <= 0) return;

//     for (auto &svr : m_buyed_svr_pool) svr->update_deltime();

//     sort(m_buyed_svr_pool.begin(), m_buyed_svr_pool.end(), [&](const Server *svr1, const Server *svr2) {
//         int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu;
//         int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory;
//         int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu;
//         int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory;
//         int t1 = svr1->GetDelTime(), t2 = svr2->GetDelTime();
//         int val1 = cpu1 + mem1 / 2, val2 = cpu2 + mem2 / 2;
//         if (abs(val1 - val2) <= 10) return t1 < t2;
//         return val1 > val2;
//     });

//     int sz = m_buyed_svr_pool.size();
//     vector<int> max_a(sz + 1, INT_MAX), max_b(sz + 1, INT_MAX);

//     int up = sz - 1;
//     for (int i = 0; i < sz; ++i) {
//         if (migra_count <= 0) return;
//         // continue;
//         auto &svr_from = m_buyed_svr_pool[i];
//         int cpu = svr_from->GetNodes()[0].cpu + svr_from->GetNodes()[1].cpu;
//         int mem = svr_from->GetNodes()[0].memory + svr_from->GetNodes()[1].memory;
//         if (cpu + mem <= 20) continue;

//         vector<Virtual *> vir_list(svr_from->GetVirList().begin(), svr_from->GetVirList().end());
//         // Virtual *select_vir = nullptr;
//         // int select_val = 0;
//         // for (auto &vir : vir_list) {
//         //     if (select_vir == nullptr || vir->GetAddTime() < select_val) {
//         //         select_vir = vir;
//         //         select_val = vir->GetAddTime();
//         //     }
//         // }

//         // if (select_vir == nullptr) continue;

//         for (auto &vir : vir_list) {
//             if (migra_count <= 0) return;

//             int na = max_a[i + 1], nb = max_b[i + 1];
//             int vir_val = vir->GetCPU() + vir->GetMemory();
//             if (vir->GetNodeCount() == 1) {
//                 if (na < vir_val && nb < vir_val) continue;
//             } else {
//                 vir_val >>= 1;
//                 if (na < vir_val || nb < vir_val) continue;
//             }

//             for (int j = up; j > i; --j) {
//                 const auto &svr_to = m_buyed_svr_pool[j];
//                 int node = -1;
//                 if (!this->match_purchase(svr_to, vir, node)) continue;
//                 vir->del_server();
//                 svr_to->add_virtual(vir, node, 0);
//                 vir->add_server(svr_to, node);
//                 migration_result.push_back({vir->GetID(), svr_to, node});
//                 --migra_count;
//                 break;
//             }

//             while (min(m_buyed_svr_pool[up]->GetNodes()[0].cpu, m_buyed_svr_pool[up]->GetNodes()[0].memory) <= 0 &&
//                    min(m_buyed_svr_pool[up]->GetNodes()[1].cpu, m_buyed_svr_pool[up]->GetNodes()[1].memory) <= 0) {
//                 --up;
//             }
//             max_a[sz] = max_b[sz] = 0;
//             for (int j = sz - 1; j > i; --j) {
//                 const auto &svr_to = m_buyed_svr_pool[j];
//                 int va = svr_to->GetNodes()[0].cpu + svr_to->GetNodes()[0].memory;
//                 int vb = svr_to->GetNodes()[1].cpu + svr_to->GetNodes()[1].memory;
//                 max_a[j] = max(max_a[j + 1], va);
//                 max_b[j] = max(max_b[j + 1], vb);
//             }
//         }
//     }
// }

void Greedy::do_migration(int day) {
    migration_result.clear();
    int migra_count = m_VirtualPoolSize * 3 / 100;
    if (migra_count <= 0) return;

    vector<Virtual*> virs;
    map<int, unordered_set<Server*>> servers;
    for (auto& svr : m_buyed_svr_pool) {
        auto& svrs = servers[svr->GetRestResource()];
        svrs.insert(svr);
    }
    for (auto it = servers.rbegin(); it != servers.rend(); it++) {
        auto& svrs = it->second;
        bool brk = false;
        for (auto svr : svrs) {
            virs.insert(virs.end(), svr->GetVirList().begin(), svr->GetVirList().end());
            if (virs.size() > 1.05 * migra_count) {
                brk = true;
                break;
            }
        }
        if (brk) break;
    }
    sort(virs.begin(), virs.end(),
         [&](Virtual* v1, Virtual* v2) { return v1->GetCPU() + v1->GetMemory() > v2->GetCPU() + v2->GetMemory(); });

    for (auto& vir : virs) {
        if (migra_count <= 0) return;
        auto iter = servers.lower_bound(vir->GetCPU() + vir->GetMemory());
        for (; iter != servers.end(); ++iter) {
            // auto rs = iter->first;
            auto& svrs = iter->second;

            bool brk = false;
            for (auto svr : svrs) {
                auto oldSvr = vir->GetServer();
                if (oldSvr == svr) {
                    brk = true;
                    break;
                }

                // DeployType tmpType;
                // if (!svr->TryDeploy(vir, tmpType)) continue;
                // servers[oldSvr->GetRestResource()].erase(oldSvr);
                // vir->DelServer();
                // servers[oldSvr->GetRestResource()].insert(oldSvr);
                // svr->DeployVirtual(vir, tmpType);
                // svrs.erase(svr);
                // servers[svr->GetRestResource()].insert(svr);
                // string migration;
                // switch (tmpType) {
                //     case DeployType::A:
                //         migration = "(" + to_string(vir->GetID()) + ", " + to_string(svr->GetID()) + ", A)\n";
                //         break;
                //     case DeployType::B:
                //         migration = "(" + to_string(vir->GetID()) + ", " + to_string(svr->GetID()) + ", B)\n";
                //         break;
                //     case DeployType::TWO:
                //         migration = "(" + to_string(vir->GetID()) + ", " + to_string(svr->GetID()) + ")\n";
                //         break;
                //     default:
                //         break;
                // }
                // // migrationResult.push_back(migration);
                // migration_result.push_back({vir->GetID(), svr, node});
                // migra_count--;

                int node = -1;
                if (!this->match_purchase(svr, vir, node)) continue;

                servers[oldSvr->GetRestResource()].erase(oldSvr);
                vir->del_server();
                servers[oldSvr->GetRestResource()].insert(oldSvr);
                svr->add_virtual(vir, node, 0);
                vir->add_server(svr, node);
                svrs.erase(svr);
                servers[svr->GetRestResource()].insert(svr);
                migration_result.push_back({vir->GetID(), svr, node});
                --migra_count;
                brk = true;
                break;
            }
            if (brk) break;
        }
    }
}