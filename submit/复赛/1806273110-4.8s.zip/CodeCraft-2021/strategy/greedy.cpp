#include "greedy.h"

#include <cmath>
#include <cstdio>

void Greedy::solve(const vector<Request*>& m_requests, int day) {
    this->do_migration(day);

    unordered_map<string, vector<Server*>> tmp;

    vector<Request*> tmp_req_list;
    vector<vector<Request*>> vct_block;
    auto type = m_requests.front()->GetType();
    for (auto& req : m_requests) {
        if (req->GetType() == type) {
            tmp_req_list.push_back(req);
            continue;
        }
        vct_block.push_back(tmp_req_list);
        type = req->GetType();
        tmp_req_list.clear();
        tmp_req_list.push_back(req);
    }
    vct_block.push_back(tmp_req_list);

    for (auto& block : vct_block) {
        if (block.front()->GetType() == REQ_TYPE::ADD) {
            sort(block.begin(), block.end(), [&](const Request* req1, const Request* req2) {
                double cpu1 = req1->GetVirtual()->GetCPU(), mem1 = req1->GetVirtual()->GetMemory();
                double cpu2 = req2->GetVirtual()->GetCPU(), mem2 = req2->GetVirtual()->GetMemory();
                int del_time1 = req1->GetVirtual()->GetDelTime(), del_time2 = req2->GetVirtual()->GetDelTime();
                if (del_time1 == del_time2) {
                    double val1 = cpu1 / mem1 - 1.0;
                    double val2 = cpu2 / mem2 - 1.0;
                    return val1 > val2;
                }
                return del_time1 > del_time2;
            });
        }
    }

    for (auto& block : vct_block) {
        vector<Request*> left;
        for (auto& req : block) {
            if (req->GetType() == REQ_TYPE::ADD) {
                ++m_VirtualPoolSize;
                Server* select_svr;
                int node = -1;

                select_svr = get_old_server(req->GetVirtual(), day, node);
                if (select_svr != nullptr) {
                    do_match(select_svr, req->GetVirtual(), day, node);
                    continue;
                }
                left.push_back(req);

                select_svr = get_new_server(req->GetVirtual(), day, node);
                Server* new_svr = new Server(select_svr);
                do_match(new_svr, req->GetVirtual(), day, node);
                m_assigned_vir_pool.push_back(req->GetVirtual());
                m_buyed_svr_pool.push_back(new_svr);
                tmp[new_svr->GetName()].push_back(new_svr);
            } else {
                auto vir = req->GetVirtual();
                vir->del_server();
                --m_VirtualPoolSize;
            }
        }
    }

    cout << "(purchase, " << tmp.size() << ")\n";
    for (auto& it : tmp) {
        for (auto& svr : it.second) {
            svr->SetID(m_global_svr_id++);
        }
        cout << "(" << it.first << ", " << it.second.size() << ")\n";
    }

    cout << "(migration, " << migration_result.size() << ")\n";
    for (auto& it : migration_result) {
        int vir_id = std::get<0>(it);
        Server* svr_to = std::get<1>(it);
        int node = std::get<2>(it);
        if (node == -1) {
            cout << "(" << vir_id << ", " << std::to_string(svr_to->GetID()) << ")\n";
        } else {
            cout << "(" << vir_id << ", " << std::to_string(svr_to->GetID()) << ", " << (node == 0 ? "A" : "B")
                 << ")\n";
        }
    }

    for (auto& req : m_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        const auto& vir = req->GetVirtual();
        if (vir->GetNodeCount() == 2) {
            cout << "(" << vir->GetServer()->GetID() << ")\n";
        } else {
            cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
        }
    }
    fflush(stdout);
}

void Greedy::Execute(const vector<Request*>& m_requests, int day) {
    // return;
    this->solve(m_requests, day);
}

void Greedy::pretreat() {
    return;
    vector<pair<double, Server*>> vt1;
    for (auto& it : m_servers) {
        double val = ((double)it->GetNodes()[0].cpu - (double)it->GetNodes()[0].memory) / (double)it->GetNodes()[0].cpu;
        vt1.push_back({val, it});
    }
    sort(vt1.begin(), vt1.end());
    for (auto& it : vt1) {
        cout << "val: " << it.first << "; ";
        it.second->debug();
    }

    vector<vector<pair<double, Server*>>> gr_svr;
    double val = vt1.front().first;
    vector<pair<double, Server*>> tmp;
    for (auto& it : vt1) {
        double x = (it.first - val) / val;
        if (x > 0.1) {
            val = it.first;
            gr_svr.push_back(tmp);
            tmp.clear();
        } else {
            tmp.push_back(it);
        }
    }

    gr_svr.push_back(tmp);

    for (auto& it : gr_svr) {
        cout << "------------------------------------------------------\n";
        for (auto& svr : it) {
            cout << "val: " << svr.first << "; ";
            svr.second->debug();
        }
    }

    vector<pair<double, Virtual*>> vt2;
    for (auto& it : m_virtuals) {
        double val = ((double)it->GetCPU() - (double)it->GetMemory()) / (double)it->GetCPU();
        vt2.push_back({val, it});
    }
    sort(vt2.begin(), vt2.end());
    // for (auto& it : vt2) {
    //     cout << "val: " << it.first << "; ";
    //     it.second->debug();
    // }

    vector<vector<pair<double, Virtual*>>> gr_svr2;
    double val2 = vt2.front().first;
    vector<pair<double, Virtual*>> tmp2;
    for (auto& it : vt2) {
        double x = (it.first - val) / val;
        if (x > 0.1) {
            val = it.first;
            gr_svr2.push_back(tmp2);
            tmp.clear();
        } else {
            tmp2.push_back(it);
        }
    }

    gr_svr2.push_back(tmp2);

    for (auto& it : gr_svr2) {
        cout << "------------------------------------------------------\n";
        for (auto& svr : it) {
            cout << "val: " << svr.first << "; ";
            svr.second->debug();
        }
    }
}