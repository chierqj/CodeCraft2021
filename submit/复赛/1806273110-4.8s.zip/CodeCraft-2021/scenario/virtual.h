#ifndef SCENARIO_VIRTUAL_H
#define SCENARIO_VIRTUAL_H

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "server.h"

using namespace std;
class Server;

class Virtual {
   public:
    Virtual(string name, int cpu, int memory, int node)
        : name(name), m_cpu(cpu), m_memory(memory), m_node_count(node) {}
    Virtual(const Virtual *vir) {
        id = vir->id;
        name = vir->name;
        m_cpu = vir->m_cpu;
        m_memory = vir->m_memory;
        m_node_count = vir->m_node_count;
    }
    void debug();
    string to_string();
    void add_server(Server *svr, int node);
    void del_server();

   public:
    inline const string &GetName() const { return name; }
    inline const int &GetCPU() const { return m_cpu; }
    inline const int &GetMemory() const { return m_memory; }
    inline const int &GetNodeCount() const { return m_node_count; }
    inline const int &GetID() const { return id; }
    inline void SetID(int _id) { id = _id; }
    inline const int &GetLocalNode() const { return local_node; }
    inline void SetLocalNode(int _node) { local_node = _node; }
    inline Server *GetServer() const { return m_svr; }
    inline void SetServer(Server *_server) { m_svr = _server; }
    inline const int &GetAddTime() const { return add_time; }
    inline void SetAddTime(int t) { add_time = t; }
    inline const int &GetDelTime() const { return del_time; }
    inline void SetDelTime(int t) { del_time = t; }

   private:
    int id = 0;          // 虚拟机id
    string name;         // 类型名称
    int m_cpu;           // cpu
    int m_memory;        // memory
    int m_node_count;    // 几个结点部署(1:单; 2：双)
    int local_node = 0;  // 在服务器的哪个结点(0: A, 1: B, -1:双)
    int add_time = 0;    // 创建时间
    int del_time = 0;    // 删除时间，最后一天
    Server *m_svr;       // 当前在哪台服务器上
};

#endif