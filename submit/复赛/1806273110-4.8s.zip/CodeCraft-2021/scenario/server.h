#ifndef SCENARIO_SERVER_H
#define SCENARIO_SERVER_H

#include <algorithm>
#include <array>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "virtual.h"
using namespace std;

class Virtual;

struct SvrNode {
    int cpu;
    int memory;
    int read_cpu;
    int read_memory;
    string to_string() const {
        string msg = "now: [";
        msg += std::to_string(cpu) + ", ";
        msg += std::to_string(memory) + "] read: [";
        msg += std::to_string(read_cpu) + ", ";
        msg += std::to_string(read_memory) + "]";
        return msg;
    }
};

class Server {
   public:
    Server(string _name, int cpu, int memory, int hardware_cost, int energy_cost) {
        name = _name;
        m_nodes[0] = {cpu >> 1, memory >> 1, cpu >> 1, memory >> 1};
        m_nodes[1] = {cpu >> 1, memory >> 1, cpu >> 1, memory >> 1};
        m_hardware_cost = hardware_cost;
        m_energy_cost = energy_cost;
        id = -1;
    }
    Server(const Server *svr) {
        id = svr->GetID();
        name = svr->GetName();
        m_nodes = svr->GetNodes();
        m_hardware_cost = svr->GetHardwareCost();
        m_energy_cost = svr->GetEnergyCost();
    }

    void debug() const;
    string to_string();
    void add_virtual(Virtual *vir, int node, int day_idx);
    void del_virtual(Virtual *vir, int node);

   public:
    inline const string &GetName() const { return name; }
    inline const array<SvrNode, 2> &GetNodes() const { return m_nodes; }
    inline void SetNodeByID(SvrNode node, int id) {
        m_nodes[id].cpu = node.cpu;
        m_nodes[id].memory = node.memory;
    }
    inline void SetNodeByID(SvrNode node, string name) {
        if (name == "A") {
            m_nodes[0].cpu = node.cpu;
            m_nodes[0].memory = node.memory;
        } else {
            m_nodes[1].cpu = node.cpu;
            m_nodes[1].memory = node.memory;
        }
    }
    inline const int &GetHardwareCost() const { return m_hardware_cost; }
    inline const int &GetEnergyCost() const { return m_energy_cost; }
    inline const int &GetID() const { return id; }
    inline void SetID(int _id) { id = _id; }
    inline const int &GetAddTime() const { return add_time; }
    inline void SetAddTime(int t) { add_time = t; }
    inline const int &GetDelTime() const { return del_time; }
    inline void SetDelTime(int t) { del_time = t; }
    inline const unordered_set<Virtual *> &GetVirList() const { return vir_list; }
    void update_deltime();
    inline int GetRestResource() { return m_nodes[0].cpu + m_nodes[1].cpu + m_nodes[0].memory + m_nodes[1].memory; }

   private:
    int id = -1;                        // id
    string name;                        // 类型名
    array<SvrNode, 2> m_nodes;          // 双节点
    int m_hardware_cost;                // 硬件成本
    int m_energy_cost;                  // 能耗成本
    int add_time = -1;                  // 创建时间,初始化为-1,创建之后不为-1
    int del_time = -1;                  // 删除时间,没有就是最后一天
    unordered_set<Virtual *> vir_list;  // 当前server部署的虚拟机数量
};

#endif