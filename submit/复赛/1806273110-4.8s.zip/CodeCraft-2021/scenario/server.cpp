#include "server.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;

void Server::debug() const {
    cout << "(服务器: " << name << ", ";
    cout << id << ", A:";
    cout << m_nodes[0].to_string() << ", B:";
    cout << m_nodes[1].to_string() << ", ";
    cout << m_hardware_cost << ", ";
    cout << m_energy_cost << ")\n";
    for (auto& it : vir_list) {
        cout << "* 当前绑定: ";
        it->debug();
    }
}

string Server::to_string() {
    string msg = "服务器: (";
    // msg += name + ", ";
    // msg += std::to_string(m_cpu) + ", ";
    // msg += std::to_string(m_memory) + ", ";
    // msg += std::to_string(m_hardware_cost) + ", ";
    // msg += std::to_string(m_energy_cost) + ")";
    return msg;
}

void Server::add_virtual(Virtual* vir, int node, int day_idx) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    if (vir->GetNodeCount() == 1) {
        m_nodes[node].cpu -= vir_cpu;
        m_nodes[node].memory -= vir_mem;
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        m_nodes[0].cpu -= vir_cpu;
        m_nodes[0].memory -= vir_mem;
        m_nodes[1].cpu -= vir_cpu;
        m_nodes[1].memory -= vir_mem;
    }
    if (add_time == -1) add_time = day_idx;
    del_time = max(del_time, vir->GetDelTime());
    vir_list.insert(vir);
}

void Server::del_virtual(Virtual* vir, int node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    if (vir->GetNodeCount() == 1) {
        m_nodes[node].cpu += vir_cpu;
        m_nodes[node].memory += vir_mem;
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        m_nodes[0].cpu += vir_cpu;
        m_nodes[0].memory += vir_mem;
        m_nodes[1].cpu += vir_cpu;
        m_nodes[1].memory += vir_mem;
    }
    vir_list.erase(vir);
}

void Server::update_deltime() {
    del_time = 0;
    for (auto& it : vir_list) {
        del_time = max(del_time, it->GetDelTime());
    }
}