#include "virtual.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

void Virtual::debug() {
    cout << "虚拟机: (" << name << ", ";
    cout << "id: " << id << ", ";
    cout << "type_id: " << type_id << ", ";
    cout << "cpu: " << m_cpu << ", ";
    cout << "mem: " << m_memory << ", ";
    cout << "node_count: " << m_node_count << ", ";
    cout << "local_node: " << local_node << ", ";
    cout << "add_time: " << add_time << ", ";
    cout << "del_time: " << del_time << ")\n";
}

string Virtual::to_string() {
    string msg = "虚拟机: (" + name + ", ";
    msg += "cpu: " + std::to_string(m_cpu) + ", ";
    msg += "mem: " + std::to_string(m_memory) + ", ";
    msg += "node_count: " + std::to_string(m_node_count) + ", ";
    msg += "local_node: " + std::to_string(local_node) + ", ";
    msg += "add_time: " + std::to_string(add_time) + ", ";
    msg += "del_time: " + std::to_string(del_time) + ")";
    return msg;
}

void Virtual::del_server() {
    m_svr->del_virtual(this, local_node);
    // m_svr = nullptr;
}

void Virtual::add_server(Server *svr, int node) {
    m_svr = svr;
    local_node = node;
}

const double Virtual::GetScore() const {
    double x = 0, y = 0;
    double inv_cpu = 1.0 / (double)m_svr->GetNodes()[0].read_cpu;
    double inv_mem = 1.0 / (double)m_svr->GetNodes()[0].read_memory;

    if (local_node == -1) {
        x = (m_svr->GetNodes()[0].cpu + m_svr->GetNodes()[1].cpu) * inv_cpu;
        y = (m_svr->GetNodes()[0].memory + m_svr->GetNodes()[1].memory) * inv_mem;
    } else {
        x = m_svr->GetNodes()[local_node].cpu * inv_cpu;
        y = m_svr->GetNodes()[local_node].memory * inv_mem;
    }
    return (x * x + y * y) * sqrt(m_svr->GetEnergyCost());
}