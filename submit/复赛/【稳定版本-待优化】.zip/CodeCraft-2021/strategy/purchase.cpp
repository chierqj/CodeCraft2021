#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "greedy.h"

using namespace std;

bool Greedy::match_purchase(Server* svr, Virtual* vir, int& local_node) {
    int vm_cpu = vir->GetCPU(), vm_mem = vir->GetMemory();
    int cpu_a = svr->GetNodes()[0].cpu, cpu_b = svr->GetNodes()[1].cpu;
    int mem_a = svr->GetNodes()[0].memory, mem_b = svr->GetNodes()[1].memory;

    if (vir->GetNodeCount() == 2) {
        vm_cpu >>= 1;
        vm_mem >>= 1;
        if (cpu_a >= vm_cpu && mem_a >= vm_mem && cpu_b >= vm_cpu && mem_b >= vm_mem) {
            local_node = -1;
            return true;
        }
    } else {
        bool ok_a = false, ok_b = false;
        if (cpu_a >= vm_cpu && mem_a >= vm_mem) ok_a = true;
        if (cpu_b >= vm_cpu && mem_b >= vm_mem) ok_b = true;

        if (ok_a && ok_b) {
            // double vm_cpu_ratio = vir->GetDeltaCPURatio();
            // double vm_mem_ratio = vir->GetDeltaMEMRatio();
            // double val_a = abs(svr->GetDeltaCPURatio(0) - vm_cpu_ratio) + abs(svr->GetDeltaMEMRatio(0) -
            // vm_mem_ratio); double val_b = abs(svr->GetDeltaCPURatio(1) - vm_cpu_ratio) + abs(svr->GetDeltaMEMRatio(1)
            // - vm_mem_ratio);

            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double val_a = fabs((double)cpu_a / (double)mem_a - vir_value);
            double val_b = fabs((double)cpu_b / (double)mem_b - vir_value);

            local_node = val_a < val_b ? 0 : 1;
            return true;
        }
        if (ok_a || ok_b) {
            local_node = ok_a ? 0 : 1;
            return true;
        }
    }
    return false;
}

void Greedy::do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

Server* Greedy::get_old_server(Virtual* vir, int day, int& local_node) {
    struct Node {
        double val;
        int node;
        Server* svr;
        bool operator<(const Node& r) const { return val < r.val; }
    };

    vector<Node> vct;
    double vm_cpu_ratio = vir->GetDeltaCPURatio();
    double vm_mem_ratio = vir->GetDeltaMEMRatio();

    for (const auto& svr : m_buyed_svr_pool) {
        int node = -1;
        if (!this->match_purchase(svr, vir, node)) continue;

        double val = 0;
        if (vir->GetNodeCount() == 2) {
            val = fabs(svr->GetDeltaCPURatio(0) - vm_cpu_ratio) + fabs(svr->GetDeltaMEMRatio(0) - vm_mem_ratio);
            val += fabs(svr->GetDeltaCPURatio(1) - vm_cpu_ratio) + fabs(svr->GetDeltaMEMRatio(1) - vm_mem_ratio);
        } else {
            val = fabs(svr->GetDeltaCPURatio(node) - vm_cpu_ratio) + fabs(svr->GetDeltaMEMRatio(node) - vm_mem_ratio);
        }

        vct.push_back(Node{val, node, svr});
    }

    stable_sort(vct.begin(), vct.end());

    if (vct.empty()) return nullptr;

    int r = vct.size() * 0.2;

    Server* select_svr = nullptr;
    int select_value = 0;
    int select_env = 0;

    for (int i = 0; i < r; ++i) {
        const auto& svr = vct[i].svr;
        int val = vir->GetNodeCount() == 2 ? svr->GetWeightedRestResource() : svr->GetWeightedRestResource(vct[i].node);
        if (select_svr == nullptr || val < select_value || (val == select_value && svr->GetEnergyCost() < select_env)) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node;
            select_env = svr->GetEnergyCost();
        }
    }

    return select_svr;
}

void Greedy::pretreat() {
    for (auto& vir : m_virtuals) {
        vector<pair<double, Server*>> vct;

        for (const auto& svr : m_servers) {
            int node = -1;
            if (!this->match_purchase(svr, vir, node)) continue;
            double ratio = fabs(svr->GetDeltaCPURatio(0) - vir->GetDeltaCPURatio());
            vct.push_back({ratio, svr});
        }

        stable_sort(vct.begin(), vct.end());

        int r = max(min(1, (int)vct.size()), (int)(vct.size() * 0.4));

        for (int i = 0; i < r; ++i) {
            const auto& svr = vct[i].second;
            m_reset_svr_pool[vir->GetName()].push_back(svr);
            m_reset_svr_resource[vir->GetName()].first += svr->GetNodes()[0].cpu;
            m_reset_svr_resource[vir->GetName()].second += svr->GetNodes()[0].memory;
            m_selected_svr_cpu += (svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu);
            m_selected_svr_mem += (svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory);
        }
    }
}

Server* Greedy::get_new_server(Virtual* vir, int day, int& local_node) {
    Server* select_svr = nullptr;
    double select_value = 0;
    double delta_day = vir->GetDelTime() - day;

    double select_sum_cpu = m_reset_svr_resource[vir->GetName()].first;
    double select_sum_mem = m_reset_svr_resource[vir->GetName()].second;
    double base = select_sum_cpu / select_sum_mem + 1.0;
    base = 2.0;

    for (auto& svr : m_reset_svr_pool[vir->GetName()]) {
        double hv = svr->GetHardwareCost();
        double ev = svr->GetEnergyCost() * delta_day;
        double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
        double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;

        double val = (hv + ev) / (cpu * base + mem);

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
        }
    }

    local_node = vir->GetNodeCount() == 2 ? -1 : 0;
    return select_svr;
}
