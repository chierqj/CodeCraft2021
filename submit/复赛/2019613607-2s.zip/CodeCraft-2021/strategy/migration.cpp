#include <algorithm>
#include <cassert>
#include <climits>

#include "greedy.h"

double Greedy::get_used_rate(Server *svr, Virtual *vir, int local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();

    double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu - vir_cpu;
    double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory - vir_mem;
    double read_cpu = svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu;
    double read_mem = svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory;

    return 1.0 - (cpu + mem) / (read_cpu + read_mem);
}

void Greedy::do_migration(int day) {
    return;
    migration_result.clear();
    int migra_count = m_VirtualPoolSize * 3 / 100;
    if (migra_count <= 0) return;

    for (auto &svr : m_buyed_svr_pool) svr->update_deltime();

    sort(m_buyed_svr_pool.begin(), m_buyed_svr_pool.end(), [&](const Server *svr1, const Server *svr2) {
        int cpu1 = svr1->GetNodes()[0].cpu + svr1->GetNodes()[1].cpu;
        int mem1 = svr1->GetNodes()[0].memory + svr1->GetNodes()[1].memory;
        int cpu2 = svr2->GetNodes()[0].cpu + svr2->GetNodes()[1].cpu;
        int mem2 = svr2->GetNodes()[0].memory + svr2->GetNodes()[1].memory;
        int t1 = svr1->GetDelTime(), t2 = svr2->GetDelTime();
        int val1 = cpu1 + mem1 / 2, val2 = cpu2 + mem2 / 2;
        if (abs(val1 - val2) <= 10) return t1 < t2;
        return val1 > val2;
    });

    int sz = m_buyed_svr_pool.size();
    vector<int> max_a(sz + 1, INT_MAX), max_b(sz + 1, INT_MAX);

    int up = sz - 1;
    for (int i = 0; i < sz; ++i) {
        if (migra_count <= 0) return;
        // continue;
        auto &svr_from = m_buyed_svr_pool[i];
        int cpu = svr_from->GetNodes()[0].cpu + svr_from->GetNodes()[1].cpu;
        int mem = svr_from->GetNodes()[0].memory + svr_from->GetNodes()[1].memory;

        vector<Virtual *> vir_list(svr_from->GetVirList().begin(), svr_from->GetVirList().end());

        for (auto &vir : vir_list) {
            if (migra_count <= 0) return;

            int na = max_a[i + 1], nb = max_b[i + 1];
            int vir_val = vir->GetCPU() + vir->GetMemory();
            if (vir->GetNodeCount() == 1) {
                if (na < vir_val && nb < vir_val) continue;
            } else {
                vir_val >>= 1;
                if (na < vir_val || nb < vir_val) continue;
            }

            for (int j = up; j > i; --j) {
                const auto &svr_to = m_buyed_svr_pool[j];
                int node = -1;
                if (!this->match_purchase(svr_to, vir, node)) continue;
                vir->del_server();
                svr_to->add_virtual(vir, node, 0);
                vir->add_server(svr_to, node);
                migration_result.push_back({vir->GetID(), svr_to, node});
                --migra_count;
                break;
            }

            while (min(m_buyed_svr_pool[up]->GetNodes()[0].cpu, m_buyed_svr_pool[up]->GetNodes()[0].memory) <= 0 &&
                   min(m_buyed_svr_pool[up]->GetNodes()[1].cpu, m_buyed_svr_pool[up]->GetNodes()[1].memory) <= 0) {
                --up;
            }
            max_a[sz] = max_b[sz] = 0;
            for (int j = sz - 1; j > i; --j) {
                const auto &svr_to = m_buyed_svr_pool[j];
                int va = svr_to->GetNodes()[0].cpu + svr_to->GetNodes()[0].memory;
                int vb = svr_to->GetNodes()[1].cpu + svr_to->GetNodes()[1].memory;
                max_a[j] = max(max_a[j + 1], va);
                max_b[j] = max(max_b[j + 1], vb);
            }
        }
    }
}
