#ifndef STRATEGY_GA_H
#define STRATEGY_GA_H

#include <algorithm>
#include <bitset>
#include <cassert>
#include <cstdio>
#include <iostream>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "scenario/request.h"
#include "scenario/scenario.h"
#include "scenario/server.h"
#include "scenario/virtual.h"

#define EPOCH (100)
#define POPU_SIZE (200)
#define TOPK (10)
#define CROSS_RATE (0.8)
#define MUTATION_RATE (0.2)
using namespace std;

struct Unit {
    Unit() {}
    Unit(Unit *u) {
        code = u->code;
        cpuA = 0;
        memA = 0;
        cpuB = 0;
        memB = 0;
        fitness = 0;
    };
    void debug() {
        printf("[cpuA: %.3f, memA: %.3f] [cpuB: %.3f, memB: %.3f] [fitness: %.3f]\n", cpuA, memA, cpuB, memB, fitness);
    }

    vector<bitset<1>> code;
    double cpuA, memA, cpuB, memB;
    double fitness;
};

class Ga {
   public:
    Ga() {}
    void Execute(const Server *svr, const unordered_set<Virtual *> &virtuals, vector<pair<Virtual *, int>> &ans);

   private:
    void init();
    void calfitness(Unit &u);
    void cross();
    void mutation(Unit &u);
    void select();

   private:
    int m_tol = 0;
    Server *m_server;
    vector<Virtual *> m_virtuals;
    vector<Unit> m_popu;
};

#endif