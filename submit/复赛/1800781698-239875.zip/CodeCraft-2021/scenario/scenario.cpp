#include "scenario.h"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <unordered_set>
#include <vector>

using namespace std;
Scenario *Scenario::Instance = nullptr;

Scenario *Scenario::GetInstance() {
    if (Instance == nullptr) {
        Instance = new Scenario();
    }
    return Instance;
}

void Scenario::debug() {}

std::vector<std::string> Split(std::string str, std::string pattern) {
    std::string::size_type pos;
    std::vector<std::string> result;
    str += pattern;  //扩展字符串以方便操作
    size_t size = str.size();
    for (size_t i = 0; i < size; i++) {
        pos = str.find(pattern, i);
        if (pos < size) {
            std::string s = str.substr(i, pos - i);
            result.push_back(s);
            i = pos + pattern.size() - 1;
        }
    }
    return result;
}

void Scenario::read_data() {
    string line;
    getline(cin, line);
    int n = std::stoi(line);
    m_TolSvr = n;
    for (int i = 0; i < n; ++i) {
        getline(cin, line);
        line = line.substr(1, line.size() - 2);
        auto s = Split(line, ", ");
        Server *server = new Server(s[0], std::stoi(s[1]), std::stoi(s[2]), std::stoi(s[3]), std::stoi(s[4]));
        m_servers.push_back(server);
    }
    getline(cin, line);
    int m = std::stoi(line);
    m_TolVir = m;

    unordered_map<string, Virtual *> hash_virtual;

    for (int i = 0; i < m; ++i) {
        getline(cin, line);
        line = line.substr(1, line.size() - 2);
        auto s = Split(line, ", ");
        Virtual *vir = new Virtual(s[0], std::stoi(s[1]), std::stoi(s[2]), std::stoi(s[3]) + 1);
        m_virtuals.push_back(vir);
        hash_virtual[s[0]] = vir;
    }
    getline(cin, line);
    auto s = Split(line, " ");

    int t = std::stoi(s[0]);
    // int k = std::stoi(s[1]);
    m_TolDay = t;

    unordered_map<int, Virtual *> vir_pool;

    Greedy *grd = new Greedy(m_servers, m_virtuals);

    for (int i = 0; i < t; ++i) {
        getline(cin, line);
        int r = std::stoi(line);
        vector<Request *> reqs;
        for (int j = 0; j < r; ++j) {
            getline(cin, line);
            line = line.substr(1, line.size() - 2);
            auto s = Split(line, ", ");
            if (s.size() == 3) {
                Virtual *new_vir = new Virtual(hash_virtual[s[1]]);
                new_vir->SetID(std::stoi(s[2]));
                vir_pool[std::stoi(s[2])] = new_vir;
                new_vir->SetAddTime(i);
                new_vir->SetDelTime(m_TolDay);
                Request *req = new Request("ADD", s[1], std::stoi(s[2]), new_vir);
                reqs.push_back(req);
            } else {
                Virtual *new_vir = vir_pool[std::stoi(s[1])];
                new_vir->SetDelTime(i);
                Request *req = new Request("DEL", std::stoi(s[1]), new_vir);
                reqs.push_back(req);
            }
        }
        m_requests.push_back(reqs);
        grd->Execute(m_requests[i], i);
    }

    // for (int i = 0; i < t; ++i) {
    //     grd->Execute(m_requests[i], i);

    //     if (i < t - k) {
    //         getline(cin, line);
    //         int r = std::stoi(line);
    //         vector<Request *> reqs;
    //         for (int j = 0; j < r; ++j) {
    //             getline(cin, line);
    //             line = line.substr(1, line.size() - 2);
    //             auto s = Split(line, ", ");
    //             if (s.size() == 3) {
    //                 Virtual *new_vir = new Virtual(hash_virtual[s[1]]);
    //                 new_vir->SetID(std::stoi(s[2]));
    //                 vir_pool[std::stoi(s[2])] = new_vir;
    //                 new_vir->SetAddTime(i + t);
    //                 new_vir->SetDelTime(m_TolDay);
    //                 Request *req = new Request("ADD", s[1], std::stoi(s[2]), new_vir);
    //                 reqs.push_back(req);
    //             } else {
    //                 Virtual *new_vir = vir_pool[std::stoi(s[1])];
    //                 new_vir->SetDelTime(i + t);
    //                 Request *req = new Request("DEL", std::stoi(s[1]), new_vir);
    //                 reqs.push_back(req);
    //             }
    //         }
    //         m_requests.push_back(reqs);
    //     }
    // }

    delete grd;
}

void Scenario::analysis_data() {
    // unordered_map<string, int> ump_add, ump_del;
    // unordered_map<string, Virtual *> hash_vir;

    // for (auto &vir : m_virtuals) hash_vir[vir->GetName()] = vir;

    // for (auto &reqs : m_requests) {
    //     for (auto &req : reqs) {
    //         if (req->GetType() == REQ_TYPE::ADD) {
    //             ump_add[req->GetVirtual()->GetName()]++;
    //         } else {
    //             ump_del[req->GetVirtual()->GetName()]++;
    //         }
    //     }
    // }
    // cout << "----------------------- reset_svr_list -------------------------\n";
    // for (auto &it : m_reset_svr_list) {
    //     hash_vir[it.first]->debug();
    //     for (auto &svr : it.second) {
    //         cout << "* ";
    //         svr->debug();
    //     }
    // }

    // cout << "------------------------ add --------------------------\n";
    // for (auto &it : ump_add) {
    //     cout << "count: " << it.second << ", ";
    //     cout << "cpu: " << it.second * hash_vir[it.first]->GetCPU() << ", ";
    //     cout << "mem: " << it.second * hash_vir[it.first]->GetMemory() << ", ";
    //     hash_vir[it.first]->debug();
    // }
    // cout << "------------------------ del --------------------------\n";
    // for (auto &it : ump_del) {
    //     cout << "count: " << it.second << ", ";
    //     cout << "cpu: " << it.second * hash_vir[it.first]->GetCPU() << ", ";
    //     cout << "mem: " << it.second * hash_vir[it.first]->GetMemory() << ", ";
    //     hash_vir[it.first]->debug();
    // }
}

void Scenario::Execute() {
    this->read_data();
    this->analysis_data();
}
