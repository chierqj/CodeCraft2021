#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "greedy.h"

using namespace std;
bool Greedy::match_purchase(Server* svr, Virtual* vir, int& local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();
    int cpu1 = svr_nodes[0].cpu;
    int mem1 = svr_nodes[0].memory;
    int cpu2 = svr_nodes[1].cpu;
    int mem2 = svr_nodes[1].memory;

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem) {
            ok1 = true;
        }
        if (cpu2 >= vir_cpu && mem2 >= vir_mem) {
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)cpu1 / (double)mem1 - vir_value);
            double valB = fabs((double)cpu2 / (double)mem2 - vir_value);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem && cpu2 >= vir_cpu && mem2 >= vir_mem) {
            return true;
        }
    }
    return false;
}

void Greedy::do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

Server* Greedy::get_old_server(Virtual* vir, int day, int& local_node) {
    struct Node {
        double val;
        int node;
        Server* svr;
        bool operator<(const Node& r) const { return val < r.val; }
    };

    double vm_cpu_ratio = vir->GetDeltaCPURatio();
    double vm_mem_ratio = vir->GetDeltaMEMRatio();
    vector<Node> vct;

    for (const auto& svr : m_buyed_svr_pool) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;

        double val = 0;
        if (vir->GetNodeCount() == 2) {
            val = abs(svr->GetDeltaCPURatio(0) - vm_cpu_ratio) + abs(svr->GetDeltaCPURatio(1) - vm_cpu_ratio);
            val += abs(svr->GetDeltaMEMRatio(0) - vm_mem_ratio) + abs(svr->GetDeltaMEMRatio(1) - vm_mem_ratio);

        } else {
            val = abs(svr->GetDeltaCPURatio(node) - vm_cpu_ratio);
            val += abs(svr->GetDeltaMEMRatio(node) - vm_mem_ratio);
        }
        vct.push_back(Node{val, node, svr});
    }

    stable_sort(vct.begin(), vct.end());

    if (vct.empty()) return nullptr;

    int r = vct.size() * 0.2;

    Server* select_svr = nullptr;
    int select_value = 0;
    int select_env = 0;

    for (int i = 0; i < r; ++i) {
        const auto& svr = vct[i].svr;
        int val = vir->GetNodeCount() == 2 ? svr->GetWeightedRestResource() : svr->GetWeightedRestResource(vct[i].node);
        if (select_svr == nullptr || val < select_value || (val == select_value && svr->GetEnergyCost() < select_env)) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node;
            select_env = svr->GetEnergyCost();
        }
    }

    return select_svr;
}

void Greedy::pretreat() {
    struct Node {
        double ratio;
        int node;
        Server* svr;
    };

    for (auto& vir : m_virtuals) {
        double vm_cpu_ratio = vir->GetDeltaCPURatio();

        vector<Node> vct;
        for (const auto& svr : m_servers) {
            int node = -1;
            if (!this->match_purchase(svr, vir, node)) continue;
            double ratio = 0;
            if (vir->GetNodeCount() == 2) {
                ratio = abs(svr->GetDeltaCPURatio(0) - vm_cpu_ratio) + abs(svr->GetDeltaCPURatio(1) - vm_cpu_ratio);
            } else {
                ratio = abs(svr->GetDeltaCPURatio(node) - vm_cpu_ratio);
            }
            vct.push_back(Node{ratio, node, svr});
        }

        stable_sort(vct.begin(), vct.end(), [&](const Node& n1, const Node& n2) { return n1.ratio < n2.ratio; });

        int r = vct.size() * 0.4;
        // double avg_delta = 0;
        // for (int i = 1; i < r; ++i) {
        //     avg_delta += (vct[i].ratio - vct[i - 1].ratio);
        // }
        // avg_delta /= (r - 1);

        // double ratio = vct[r - 1].ratio;
        // for (; r < (int)vct.size(); ++r) {
        //     double v = (vct[r].ratio - ratio) / ratio;
        //     if (v > avg_delta) break;
        // }
        double ratio = vct[r - 1].ratio;
        for (; r < (int)vct.size(); ++r) {
            double v = (vct[r].ratio - ratio) / ratio;
            if (v > 0.2) break;
        }

        for (int i = 0; i < r; ++i) {
            const auto& svr = vct[i].svr;
            m_reset_svr_pool[vir->GetName()].push_back({vct[i].node, svr});
            m_selected_svr_cpu += (svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu);
            m_selected_svr_mem += (svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory);
        }
    }

    if (m_selected_svr_cpu > m_selected_svr_mem) {
        m_CPU_WEIGHT = 1.0;
        m_MEM_WEIGHT = 2.0;
    } else {
        m_CPU_WEIGHT = 2.0;
        m_MEM_WEIGHT = 1.0;
    }
}

Server* Greedy::get_new_server(Virtual* vir, int day, int& local_node) {
    Server* select_svr = nullptr;
    double select_value = 0;
    double delta_day = vir->GetDelTime() - day;

    double base = (double)m_future_k_vm_cpu / (double)m_future_k_vm_mem + 1.12;
    m_CPU_WEIGHT = base;
    // base = 2;
    // if (m_selected_svr_cpu > m_selected_svr_mem) base = 1.0 / base;

    for (auto& it : m_reset_svr_pool[vir->GetName()]) {
        int node = it.first;
        const auto& svr = it.second;

        double hv = svr->GetHardwareCost();
        double ev = svr->GetEnergyCost() * delta_day;
        double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu;
        double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory;

        double val = (hv + ev) / (cpu * m_CPU_WEIGHT + mem * m_MEM_WEIGHT);

        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = node;
        }
    }
    return select_svr;
}
