#include "ga.h"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <queue>
#include <unordered_map>
#include <unordered_set>

#include "tools.h"

bool match_purchase(Server *svr, Virtual *vir, int &local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto &svr_nodes = svr->GetNodes();
    int cpu1 = svr_nodes[0].cpu;
    int mem1 = svr_nodes[0].memory;
    int cpu2 = svr_nodes[1].cpu;
    int mem2 = svr_nodes[1].memory;

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem) {
            ok1 = true;
        }
        if (cpu2 >= vir_cpu && mem2 >= vir_mem) {
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)cpu1 / (double)mem1 - vir_value);
            double valB = fabs((double)cpu2 / (double)mem2 - vir_value);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem && cpu2 >= vir_cpu && mem2 >= vir_mem) {
            return true;
        }
    }
    return false;
}

void Ga::calfitness(Unit &u) {
    Server *new_svr = new Server(m_server);

    for (size_t i = 0; i < u.code.size(); ++i) {
        if (u.code[i] == 0) continue;
        int node = -1;
        if (match_purchase(new_svr, m_virtuals[i], node)) {
            new_svr->add_virtual(m_virtuals[i], node, 0);
        }
    }

    u.cpuA = (double)(new_svr->GetNodes()[0].cpu) / (double)(new_svr->GetNodes()[0].read_cpu + 1.0);
    u.memA = (double)(new_svr->GetNodes()[0].memory) / (double)(new_svr->GetNodes()[0].read_memory + 1.0);
    u.cpuB = (double)(new_svr->GetNodes()[1].cpu) / (double)(new_svr->GetNodes()[1].read_cpu + 1.0);
    u.memB = (double)(new_svr->GetNodes()[1].memory) / (double)(new_svr->GetNodes()[1].read_memory + 1.0);
    u.fitness = u.cpuA + u.memA + u.cpuB + u.memB;

    delete new_svr;
}

void Ga::init() {
    int dep_block = 10;
    m_popu.clear();

    for (int i = 0; i < POPU_SIZE / dep_block; ++i) {
        int rd = Tools::RandomInt(0, (int)m_virtuals.size() - 1);
        for (int dep = 1; dep <= dep_block; ++dep) {
            Unit u;
            u.code = vector<bitset<1>>(m_virtuals.size(), 0);
            for (int j = rd; j < (int)m_virtuals.size(); j += dep) {
                u.code[j] = 1;
            }
            m_popu.push_back(u);
        }
    }
    int sz = m_popu.size();
    for (int i = 0; i < POPU_SIZE - sz; ++i) {
        Unit u;
        u.code = vector<bitset<1>>(m_virtuals.size(), 0);
        for (int j = 0; j < (int)m_virtuals.size(); ++j) {
            u.code[j] = Tools::RandomInt(0, 1);
        }
        m_popu.push_back(u);
    }
    for (auto &it : m_popu) {
        this->calfitness(it);
    }
    assert((int)m_popu.size() == POPU_SIZE);
}

void Ga::cross() {
    for (int i = 0; i < POPU_SIZE; ++i) {
        double rd = Tools::RandomDouble(0, 1);
        if (rd > CROSS_RATE) continue;

        int l = Tools::RandomInt(0, POPU_SIZE - 1);
        int r = Tools::RandomInt(0, POPU_SIZE - 1);

        int p1 = Tools::RandomInt(0, (int)m_virtuals.size() - 1);
        int p2 = Tools::RandomInt(0, (int)m_virtuals.size() - 1);

        Unit nu1 = Unit(m_popu[l]), nu2 = Unit(m_popu[r]);
        for (int j = p1; j <= p2; ++j) {
            nu1.code[j] = m_popu[r].code[j];
            nu2.code[j] = m_popu[l].code[j];
        }

        this->mutation(nu1);
        this->mutation(nu2);

        this->calfitness(nu1);
        this->calfitness(nu2);

        m_popu.push_back(nu1);
        m_popu.push_back(nu2);
    }
}

void Ga::mutation(Unit &u) {
    double rd = Tools::RandomDouble(0, 1);
    if (rd > MUTATION_RATE) return;
    int p = Tools::RandomInt(0, (int)m_virtuals.size() - 1);
    assert(p >= 0 && p <= (int)u.code.size());
    u.code[p] ^= 1;
}

void Ga::select() {
    struct Node {
        int idx;
        double val;
        bool operator<(const Node &r) const { return val < r.val; }
    };

    priority_queue<Node> pq;
    double sum_fitness = 0.00001;

    for (int i = 0; i < (int)m_popu.size(); ++i) {
        sum_fitness += m_popu[i].fitness;
        if ((int)pq.size() < TOPK) {
            pq.push(Node{i, m_popu[i].fitness});
            continue;
        }
        if (m_popu[i].fitness < pq.top().val) {
            pq.pop();
            pq.push(Node{i, m_popu[i].fitness});
        }
    }
    vector<Unit> sons;

    while (!pq.empty()) {
        sons.push_back(m_popu[pq.top().idx]);
        pq.pop();
    }

    vector<double> select_rate;
    double rate = 0.0;
    for (auto &it : m_popu) {
        rate += it.fitness / sum_fitness;
        select_rate.push_back(rate);
    }
    select_rate.back() = 1.0;

    for (int i = 0; i < POPU_SIZE - TOPK; ++i) {
        double rd = Tools::RandomDouble(0, 1);
        auto pos = lower_bound(select_rate.begin(), select_rate.end(), rd) - select_rate.begin();
        assert(pos >= 0 && pos <= (int)m_popu.size());
        sons.push_back(m_popu[pos]);
    }

    m_popu = sons;
}

void Ga::Execute(const Server *svr, const unordered_set<Virtual *> &vir_list, vector<pair<Virtual *, int>> &ans) {
    if (vir_list.empty() || m_tol++ > 2) return;

    m_server = new Server(svr);
    m_virtuals.clear();
    m_virtuals.insert(m_virtuals.end(), vir_list.begin(), vir_list.end());

    this->init();
    for (int epoch = 0; epoch < EPOCH; ++epoch) {
        this->cross();
        this->select();
        if (m_popu.front().fitness < 0.05) break;
    }

    auto &best = m_popu.front();
    Server *new_svr = new Server(m_server);

    ans.clear();
    for (size_t i = 0; i < best.code.size(); ++i) {
        if (best.code[i] == 0) continue;
        auto &vir = m_virtuals[i];
        int node = -1;
        if (!match_purchase(new_svr, vir, node)) continue;
        new_svr->add_virtual(vir, node, 0);
        ans.push_back({vir, node});
    }

    delete new_svr;
    delete m_server;
}