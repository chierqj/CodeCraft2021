#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>

#include "greedy.h"

using namespace std;

bool Greedy::match_purchase(Server* svr, Virtual* vir, int& local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();
    const auto& svr_nodes = svr->GetNodes();
    int cpu1 = svr_nodes[0].cpu;
    int mem1 = svr_nodes[0].memory;
    int cpu2 = svr_nodes[1].cpu;
    int mem2 = svr_nodes[1].memory;

    if (vir->GetNodeCount() == 1) {
        bool ok1 = false, ok2 = false;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem) {
            ok1 = true;
        }
        if (cpu2 >= vir_cpu && mem2 >= vir_mem) {
            ok2 = true;
        }

        if (ok1 && ok2) {
            double vir_value = (double)(vir->GetCPU()) / (double)(vir->GetMemory());
            double valA = fabs((double)cpu1 / (double)mem1 - vir_value);
            double valB = fabs((double)cpu2 / (double)mem2 - vir_value);
            local_node = valA < valB ? 0 : 1;
            return true;
        }
        if (ok1 || ok2) {
            local_node = ok1 ? 0 : 1;
            return true;
        }
    } else {
        vir_cpu >>= 1;
        vir_mem >>= 1;
        if (cpu1 >= vir_cpu && mem1 >= vir_mem && cpu2 >= vir_cpu && mem2 >= vir_mem) {
            return true;
        }
    }
    return false;
}

void Greedy::do_match(Server* svr, Virtual* vir, int day_idx, int local_node) {
    svr->add_virtual(vir, local_node, day_idx);
    vir->add_server(svr, local_node);
}

Server* Greedy::get_old_server(Virtual* vir, int day, int& local_node) {
    struct Node {
        double val;
        int node;
        Server* svr;
        bool operator<(const Node& r) const { return val < r.val; }
    };

    double vir_value = vir->GetDeltaRatio();
    vector<Node> vct;

    for (const auto& svr : m_buyed_svr_pool) {
        int node = 0;
        if (!this->match_purchase(svr, vir, node)) continue;

        double val = 0;
        if (vir->GetNodeCount() == 2) {
            val = abs(svr->GetDeltaRatio(0) - vir_value) + abs(svr->GetDeltaRatio(1) - vir_value);
        } else {
            val = abs(svr->GetDeltaRatio(node) - vir_value);
        }
        vct.push_back(Node{val, node, svr});
    }

    stable_sort(vct.begin(), vct.end());

    Server* select_svr = nullptr;
    int select_value = 0;

    for (int i = 0; i < (int)vct.size() * 0.2; ++i) {
        const auto& svr = vct[i].svr;
        int val = vir->GetNodeCount() == 2 ? svr->GetRestResource() : svr->GetRestResource(vct[i].node);
        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = vct[i].node;
        }
    }

    return select_svr;
}

Server* Greedy::get_new_server(Virtual* vir, int day, int& local_node) {
    Server* select_svr = nullptr;
    double select_value = 0;
    int delta_day = vir->GetDelTime() - day;
    // if (delta_day >= 900) delta_day = 950;
    // if (delta_day >= 800 && delta_day < 900) delta_day = 850;
    // if (delta_day >= 700 && delta_day < 800) delta_day = 750;
    // if (delta_day >= 600 && delta_day < 700) delta_day = 650;
    // if (delta_day >= 500 && delta_day < 600) delta_day = 550;
    // if (delta_day >= 400 && delta_day < 500) delta_day = 450;
    // if (delta_day >= 300 && delta_day < 400) delta_day = 350;
    // if (delta_day >= 200 && delta_day < 300) delta_day = 250;
    // if (delta_day >= 100 && delta_day < 200) delta_day = 150;
    // if (delta_day < 100) delta_day = 50;

    for (auto& it : m_reset_svr_pool[vir->GetName()]) {
        int node = it.first;
        const auto& svr = it.second;
        int val = (svr->GetHardwareCost() + svr->GetEnergyCost() * delta_day) / svr->GetRestResource(0);
        if (select_svr == nullptr || val < select_value) {
            select_svr = svr;
            select_value = val;
            local_node = node;
        }
    }
    return select_svr;
}
