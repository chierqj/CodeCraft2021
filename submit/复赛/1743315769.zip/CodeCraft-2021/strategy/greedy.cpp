#include "greedy.h"

#include <unistd.h>

#include <cmath>
#include <cstdio>

void Greedy::solve(const vector<Request*>& m_requests, int day) {
    this->do_migration(day);

    unordered_map<string, vector<Server*>> tmp;

    vector<Request*> tmp_req_list;
    vector<vector<Request*>> vct_block;
    auto type = m_requests.front()->GetType();
    for (auto& req : m_requests) {
        if (req->GetType() == type) {
            tmp_req_list.push_back(req);
            continue;
        }
        vct_block.push_back(tmp_req_list);
        type = req->GetType();
        tmp_req_list.clear();
        tmp_req_list.push_back(req);
    }
    vct_block.push_back(tmp_req_list);

    for (auto& block : vct_block) {
        if (block.front()->GetType() == REQ_TYPE::ADD) {
            stable_sort(block.begin(), block.end(), [&](const Request* req1, const Request* req2) {
                double cpu1 = req1->GetVirtual()->GetCPU(), mem1 = req1->GetVirtual()->GetMemory();
                double cpu2 = req2->GetVirtual()->GetCPU(), mem2 = req2->GetVirtual()->GetMemory();
                int del_time1 = req1->GetVirtual()->GetDelTime(), del_time2 = req2->GetVirtual()->GetDelTime();
                if (del_time1 == del_time2) {
                    double val1 = cpu1 / mem1 - 1.0;
                    double val2 = cpu2 / mem2 - 1.0;
                    return val1 > val2;
                }
                return del_time1 < del_time2;
            });
        }
    }

    for (auto& block : vct_block) {
        auto type = block.front()->GetType();
        if (type == REQ_TYPE::DEL) {
            for (auto& req : block) {
                auto vir = req->GetVirtual();
                vir->del_server();
                --m_VirtualPoolSize;
            }
            continue;
        }

        for (auto& req : block) {
            ++m_VirtualPoolSize;
            Server* select_svr;
            int node = -1;
            select_svr = get_old_server(req->GetVirtual(), day, node);
            if (select_svr != nullptr) {
                do_match(select_svr, req->GetVirtual(), day, node);
                continue;
            }
            select_svr = get_new_server(req->GetVirtual(), day, node);
            Server* new_svr = new Server(select_svr);
            do_match(new_svr, req->GetVirtual(), day, node);
            m_assigned_vir_pool.push_back(req->GetVirtual());
            m_buyed_svr_pool.push_back(new_svr);
            tmp[new_svr->GetName()].push_back(new_svr);
        }
    }

    cout << "(purchase, " << tmp.size() << ")\n";
    for (auto& it : tmp) {
        for (auto& svr : it.second) {
            svr->SetID(m_global_svr_id++);
        }
        cout << "(" << it.first << ", " << it.second.size() << ")\n";
    }

    cout << "(migration, " << migration_result.size() << ")\n";
    for (auto& it : migration_result) {
        int vir_id = std::get<0>(it);
        Server* svr_to = std::get<1>(it);
        int node = std::get<2>(it);
        if (node == -1) {
            cout << "(" << vir_id << ", " << std::to_string(svr_to->GetID()) << ")\n";
        } else {
            cout << "(" << vir_id << ", " << std::to_string(svr_to->GetID()) << ", " << (node == 0 ? "A" : "B")
                 << ")\n";
        }
    }

    for (auto& req : m_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        const auto& vir = req->GetVirtual();
        if (vir->GetNodeCount() == 2) {
            cout << "(" << vir->GetServer()->GetID() << ")\n";
        } else {
            cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
        }
    }
    usleep(70000);
    fflush(stdout);
}

void Greedy::Execute(const vector<Request*>& m_requests, int day) {
    // return;
    this->solve(m_requests, day);
}

void Greedy::pretreat() {
    struct Node {
        double val;
        int node;
        Server* svr;
        bool operator<(const Node& r) const {
            if (val == r.val) return false;
            return val < r.val;
        }
    };

    for (auto& vir : m_virtuals) {
        double vir_value = vir->GetDeltaRatio();
        vector<Node> vct;
        for (const auto& svr : m_servers) {
            int node = 0;
            if (!this->match_purchase(svr, vir, node)) continue;
            double val = 0;
            if (vir->GetNodeCount() == 2) {
                val = abs(svr->GetDeltaRatio(0) - vir_value) + abs(svr->GetDeltaRatio(1) - vir_value);
            } else {
                val = abs(svr->GetDeltaRatio(node) - vir_value);
            }
            vct.push_back(Node{val, node, svr});
        }
        stable_sort(vct.begin(), vct.end());
        for (int i = 0; i < (int)vct.size() * 0.4; ++i) {
            m_reset_svr_pool[vir->GetName()].push_back({vct[i].node, vct[i].svr});
        }
    }
}