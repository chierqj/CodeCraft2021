#ifndef STRATEGY_GREEDY_H
#define STRATEGY_GREEDY_H

#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "scenario/request.h"
#include "scenario/scenario.h"
#include "scenario/server.h"
#include "scenario/virtual.h"

class Greedy {
   public:
    Greedy(const vector<Server *> &svrs, const vector<Virtual *> &virs, const int &tol_day)
        : m_servers(svrs), m_virtuals(virs), m_tol_day(tol_day) {
        this->pretreat();
    }
    void Execute(const vector<Request *> &m_requests, int day, int future_k_vm_cpu, int future_k_vm_mem);

   private:
    void pretreat();
    void solve(const vector<Request *> &m_requests, int day);
    double get_used_rate(Server *svr, Virtual *vir, int local_node);
    void do_match(Server *svr, Virtual *vir, int day_idx, int local_node);
    void do_migration(int day);
    void do_migration_1(int day, int &migra_count);
    void do_migration_2(int day, int &migra_count);
    bool match_purchase(Server *svr, Virtual *vir, int &local_node);
    Server *get_old_server(Virtual *vir, int day, int &local_node);
    Server *get_new_server(Virtual *vir, int day, int &local_node);
    void get_new_req_list(const vector<Request *> &m_requests, vector<vector<Request *>> &new_req_list, int day);

   private:
    const vector<Server *> &m_servers;    // 读入服务器列表
    const vector<Virtual *> &m_virtuals;  // 读入虚拟机列表
    int m_tol_day = 0;

    int m_VirtualPoolSize = 0;                                   // 当前已经虚拟机的总数
    int m_global_svr_id = 0;                                     // 服务器全局id
    vector<tuple<int, Server *, int>> migration_result;          // vir->svr_to->localnode
    vector<Server *> m_buyed_svr_pool;                           // 已经购买的svr
    unordered_map<string, vector<Server *>> m_reset_svr_pool;    // 预处理
    unordered_map<string, pair<int, int>> m_reset_svr_resource;  // 预处理

    int m_future_k_vm_cpu = 0;
    int m_future_k_vm_mem = 0;
    int m_selected_svr_cpu = 0;
    int m_selected_svr_mem = 0;
};

#endif