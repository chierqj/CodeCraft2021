#include <algorithm>
#include <cassert>
#include <climits>
#include <cmath>
#include <map>
#include <set>

#include "greedy.h"

double Greedy::get_used_rate(Server* svr, Virtual* vir, int local_node) {
    int vir_cpu = vir->GetCPU(), vir_mem = vir->GetMemory();

    double cpu = svr->GetNodes()[0].cpu + svr->GetNodes()[1].cpu - vir_cpu;
    double mem = svr->GetNodes()[0].memory + svr->GetNodes()[1].memory - vir_mem;
    double read_cpu = svr->GetNodes()[0].read_cpu + svr->GetNodes()[1].read_cpu;
    double read_mem = svr->GetNodes()[0].read_memory + svr->GetNodes()[1].read_memory;

    return 1.0 - (cpu + mem) / (read_cpu + read_mem);
}

struct cmp {
    bool operator()(const Server* svr1, const Server* svr2) const {
        return svr1->GetWeightedRestResource() < svr2->GetWeightedRestResource();
    }
};

void Greedy::do_migration(int day) {
    migration_result.clear();
    int migra_count = m_VirtualPoolSize * 3 / 100;
    if (migra_count <= 0) return;

    while (true) {
        int count = migra_count;
        if (migra_count <= 0) return;

        set<Server*, cmp> hash_svr_list;
        auto action_move = [&](Virtual* vir, Server* svr_to, int node) {
            hash_svr_list.erase(vir->GetServer());
            hash_svr_list.erase(svr_to);
            vir->del_server();
            this->do_match(svr_to, vir, day, node);
            hash_svr_list.insert(svr_to);
        };

        for (auto& svr : m_buyed_svr_pool) {
            if (svr->GetVirList().empty()) continue;
            hash_svr_list.insert(svr);
        }

        vector<Virtual*> vir_list;
        int last_weight = 0;
        for (auto it = hash_svr_list.rbegin(); it != hash_svr_list.rend(); it++) {
            const auto& svr = *it;
            vir_list.insert(vir_list.end(), svr->GetVirList().begin(), svr->GetVirList().end());
            if (vir_list.size() > 1.6 * migra_count && svr->GetWeightedRestResource() != last_weight) break;
            last_weight = svr->GetWeightedRestResource();
        }

        stable_sort(vir_list.begin(), vir_list.end(), [&](const Virtual* vir1, const Virtual* vir2) {
            return vir1->GetWeightedRestResource() > vir2->GetWeightedRestResource();
        });

        vector<Server*> suc;
        for (auto& vir : vir_list) {
            if (migra_count <= 0) return;

            Server* select_svr = nullptr;
            double select_value = 0;
            int select_node = -1;
            int select_env = 0;

            auto iter = lower_bound(hash_svr_list.begin(), hash_svr_list.end(), vir->GetWeightedRestResource(),
                                    [&](const Server* svr, int pval) { return svr->GetWeightedRestResource() < pval; });

            for (; iter != hash_svr_list.end(); ++iter) {
                const auto& svr_to = *iter;
                if (svr_to == vir->GetServer()) break;

                int node = -1;
                if (!this->match_purchase(svr_to, vir, node)) continue;

                int val = vir->GetNodeCount() == 2 ? svr_to->GetWeightedRestResource()
                                                   : svr_to->GetWeightedRestResource(node);
                if (select_svr == nullptr || val < select_value ||
                    (val == select_value && svr_to->GetEnergyCost() < select_env)) {
                    select_svr = svr_to;
                    select_value = val;
                    select_node = node;
                    select_env = svr_to->GetEnergyCost();
                }
            }

            if (select_svr != nullptr) {
                suc.push_back(vir->GetServer());
                action_move(vir, select_svr, select_node);
                migration_result.emplace_back(std::make_tuple(vir->GetID(), select_svr, select_node));
                --migra_count;
            }
        }
        if (count == migra_count) return;
    }
}

// void Greedy::do_migration(int day) {
//     migration_result.clear();
//     int migra_count = m_VirtualPoolSize * 3 / 100;
//     if (migra_count <= 0) return;

//     map<int, unordered_set<Server*>> hash_svr_list;

//     for (auto& svr : m_buyed_svr_pool) {
//         if (svr->GetVirList().empty()) continue;
//         hash_svr_list[svr->GetRestResource()].insert(svr);
//     }

//     sort(m_buyed_svr_pool.begin(), m_buyed_svr_pool.end(),
//          [&](const Server* svr1, const Server* svr2) { return svr1->GetRestResource() > svr2->GetRestResource(); });

//     auto action_move = [&](Virtual* vir, Server* svr_to, int node) {
//         hash_svr_list[vir->GetServer()->GetRestResource()].erase(vir->GetServer());
//         hash_svr_list[svr_to->GetRestResource()].erase(svr_to);
//         vir->del_server();
//         // hash_svr_list[vir->GetServer()->GetWeightedRestResource()].insert(vir->GetServer());
//         this->do_match(svr_to, vir, day, node);
//         hash_svr_list[svr_to->GetRestResource()].insert(svr_to);
//     };

//     for (auto& svr_from : m_buyed_svr_pool) {
//         if (migra_count <= 0) return;

//         vector<Virtual*> vir_list(svr_from->GetVirList().begin(), svr_from->GetVirList().end());
//         for (auto& vir : vir_list) {
//             if (migra_count <= 0) return;

//             Server* select_svr = nullptr;
//             double select_value = 0;
//             int select_node = -1;
//             int select_env = 0;
//             bool ok = false;
//             auto iter = hash_svr_list.lower_bound(vir->GetRestResource());
//             for (; iter != hash_svr_list.end(); ++iter) {
//                 const auto& svr_to_list = iter->second;
//                 for (auto svr_to : svr_to_list) {
//                     if (svr_to == vir->GetServer()) break;
//                     if (svr_to->GetVirList().empty()) continue;
//                     if (svr_to->GetRestResource() < svr_from->GetRestResource()) break;

//                     int node = -1;
//                     if (!this->match_purchase(svr_to, vir, node)) continue;

//                     int val = vir->GetNodeCount() == 2 ? svr_to->GetWeightedRestResource()
//                                                        : svr_to->GetWeightedRestResource(node);
//                     if (select_svr == nullptr || val < select_value ||
//                         (val == select_value && svr_to->GetEnergyCost() < select_env)) {
//                         select_svr = svr_to;
//                         select_value = val;
//                         select_node = node;
//                         select_env = svr_to->GetEnergyCost();
//                     }
//                     action_move(vir, select_svr, select_node);
//                     migration_result.emplace_back(std::make_tuple(vir->GetID(), select_svr, select_node));
//                     --migra_count;
//                     ok = true;
//                     break;
//                 }
//                 if (ok) break;
//             }
//             if (ok) break;
//         }
//     }
// }
