#include "request.h"

#include <algorithm>
#include <cstring>
#include <iostream>
#include <vector>

void Request::debug() {
    cout << "请求: (" << (type == REQ_TYPE::ADD ? "ADD, " : "DEL, ");
    cout << vir_name << ", ";
    cout << vir_id << ") ";
    cout << m_vir->to_string() << "\n";
}

string Request::to_string() {
    string msg = "请求: (";
    msg += (type == REQ_TYPE::ADD ? "ADD" : "DEL");
    msg += ", ";
    msg += vir_name + ", ";
    msg += std::to_string(vir_id) + ") ";
    return msg;
}