#include "greedy.h"

#include <unistd.h>

#include <cmath>
#include <cstdio>
#include <queue>

#include "ga.h"

void Greedy::get_new_req_list(const vector<Request*>& m_requests, vector<vector<Request*>>& new_req_list, int day) {
    int add_sum = 0, del_sum = 0;
    for (auto& req : m_requests) {
        if (req->GetType() == REQ_TYPE::ADD) {
            add_sum += req->GetVirtual()->GetRestResource();
        } else {
            del_sum += req->GetVirtual()->GetRestResource();
        }
    }

    vector<Request*> m_requests_copy(m_requests.begin(), m_requests.end());
    if (del_sum < add_sum) {
        stable_sort(m_requests_copy.begin(), m_requests_copy.end(), [&](const Request* req1, const Request* req2) {
            if (req1->GetType() == req2->GetType()) {
                return req1->GetVirtual()->GetRestResource() > req2->GetVirtual()->GetRestResource();
            }
            return req1->GetType() < req2->GetType();
        });
    }

    vector<vector<Request*>> vct_block;
    vector<Request*> tmp;
    auto type = m_requests_copy.front()->GetType();
    for (auto& req : m_requests_copy) {
        if (req->GetType() == type) {
            tmp.push_back(req);
            continue;
        }
        vct_block.push_back(tmp);
        type = req->GetType();
        tmp.clear();
        tmp.push_back(req);
    }
    vct_block.push_back(tmp);

    for (auto& block : vct_block) {
        if (del_sum < add_sum) {
            new_req_list.push_back(block);
            continue;
        }
        if (block.front()->GetType() == REQ_TYPE::ADD) {
            stable_sort(block.begin(), block.end(), [&](const Request* req1, const Request* req2) {
                double cpu1 = req1->GetVirtual()->GetCPU(), mem1 = req1->GetVirtual()->GetMemory();
                double cpu2 = req2->GetVirtual()->GetCPU(), mem2 = req2->GetVirtual()->GetMemory();
                double val1 = fabs(cpu1 / mem1 - 1.0);
                double val2 = fabs(cpu2 / mem2 - 1.0);
                return val1 > val2;
            });
        }
        new_req_list.push_back(block);
    }
}

void Greedy::solve(const vector<Request*>& m_requests, int day) {
    this->do_migration(day);

    unordered_map<string, vector<Server*>> tmp;

    vector<vector<Request*>> new_req_list;
    this->get_new_req_list(m_requests, new_req_list, day);

    for (auto& block : new_req_list) {
        if (block.front()->GetType() == REQ_TYPE::DEL) {
            m_VirtualPoolSize -= block.size();
            for (auto& req : block) {
                req->GetVirtual()->del_server();
            }
            continue;
        }
        m_VirtualPoolSize += block.size();
        for (auto& req : block) {
            Server* select_svr;
            int node = -1;
            select_svr = get_old_server(req->GetVirtual(), day, node);
            if (select_svr != nullptr) {
                do_match(select_svr, req->GetVirtual(), day, node);
                continue;
            }

            select_svr = get_new_server(req->GetVirtual(), day, node);
            Server* new_svr = new Server(select_svr);

            do_match(new_svr, req->GetVirtual(), day, node);
            m_buyed_svr_pool.push_back(new_svr);

            tmp[new_svr->GetName()].push_back(new_svr);
        }
    }

    cout << "(purchase, " << tmp.size() << ")\n";
    for (auto& it : tmp) {
        for (auto& svr : it.second) {
            svr->SetID(m_global_svr_id++);
        }
        cout << "(" << it.first << ", " << it.second.size() << ")\n";
    }

    cout << "(migration, " << migration_result.size() << ")\n";
    for (auto& it : migration_result) {
        int vir_id = std::get<0>(it);
        Server* svr_to = std::get<1>(it);
        int node = std::get<2>(it);
        if (node == -1) {
            cout << "(" << vir_id << ", " << std::to_string(svr_to->GetID()) << ")\n";
        } else {
            cout << "(" << vir_id << ", " << std::to_string(svr_to->GetID()) << ", " << (node == 0 ? "A" : "B")
                 << ")\n";
        }
    }

    for (auto& req : m_requests) {
        if (req->GetType() == REQ_TYPE::DEL) continue;
        const auto& vir = req->GetVirtual();
        if (vir->GetNodeCount() == 2) {
            cout << "(" << vir->GetServer()->GetID() << ")\n";
        } else {
            cout << "(" << vir->GetServer()->GetID() << ", " << (vir->GetLocalNode() == 0 ? "A" : "B") << ")\n";
        }
    }
    // usleep(50000);
    fflush(stdout);
}

void Greedy::Execute(const vector<Request*>& m_requests, int day, int future_k_vm_cpu, int future_k_vm_mem) {
    m_future_k_vm_cpu = future_k_vm_cpu;
    m_future_k_vm_mem = future_k_vm_mem;
    this->solve(m_requests, day);
}