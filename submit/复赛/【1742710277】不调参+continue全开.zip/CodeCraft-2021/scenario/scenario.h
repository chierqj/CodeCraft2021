#ifndef SCENARIO_SCENARIO_H
#define SCENARIO_SCENARIO_H

#include <algorithm>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>

#include "request.h"
#include "server.h"
#include "strategy/greedy.h"
#include "virtual.h"
using namespace std;

class Greedy;

class Scenario {
   public:
    static Scenario *GetInstance();
    void Execute();
    void debug();

   public:
    inline vector<Server *> &GetServers();
    inline vector<Virtual *> &GetVirtuals();
    inline vector<vector<Request *>> &GetRequests();

   private:
    Scenario(){};
    Scenario(const Scenario &) = delete;
    Scenario &operator=(const Scenario &) = delete;

    void read_data();
    void analysis_data();

   private:
    static Scenario *Instance;
    vector<Server *> m_servers;            // 读入服务器
    vector<Virtual *> m_virtuals;          // 读入虚拟机
    vector<vector<Request *>> m_requests;  // 读入请求
};

inline vector<Server *> &Scenario::GetServers() { return m_servers; }
inline vector<Virtual *> &Scenario::GetVirtuals() { return m_virtuals; }
inline vector<vector<Request *>> &Scenario::GetRequests() { return m_requests; }

#endif  // SCENARIO_SCENARIO_H